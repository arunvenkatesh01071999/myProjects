const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const CountryMaster = require('../../MastersApp/models/CountryModel');


const State = sequelize.define("states", {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "state_name is required"
            }
        }
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "country_id is required"
            }
        }
    },
    // active: {
    //     type: DataTypes.BOOLEAN,
    //     allowNull: true,
    //     defaultValue: 1,
    // },
    // created_at:{
    //     type:DataTypes.DATE,
    //     allowNull: true,
    // },
    // updated_at:{
    //     type:DataTypes.STRING,
    //     allowNull: true,
    // },
    // created_by:{
    //     type:DataTypes.INTEGER,
    //     allowNull: false,
    // },
    // updated_by:{
    //     type:DataTypes.INTEGER,
    //     allowNull: false,
    // }
}, { freezeTableName: true });

State.belongsTo(CountryMaster, { foreignKey: 'country_id' })

State.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'states',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

State.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'states',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = State;