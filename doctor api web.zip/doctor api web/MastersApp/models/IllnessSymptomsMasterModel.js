const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const IllnessTypes = require('../models/IllnessTypesModel');
const IllnessSymptoms = require('../models/IllnessSymptomsModel');

const IllnessSymptomsMaster = sequelize.define("illness_symptoms_master", {
    illness_symptom_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "illness_symptom_name is required"
            }
        }
    },
    logo_image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

IllnessSymptomsMaster.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'illness_symptoms_master',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

IllnessSymptomsMaster.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'illness_symptoms_master',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

// IllnessSymptomsMaster.hasMany(IllnessSymptoms, { foreignKey: 'illness_symptom_id' });

// // Define the association between IllnessSymptoms and IllnessTypes
IllnessSymptomsMaster.hasMany(IllnessSymptoms, {
    foreignKey: 'illness_symptom_id', // Foreign key in IllnessTypes model that references IllnessSymptoms
    as: 'IllnessSymptoms' // Alias to be used for the association
});

module.exports = IllnessSymptomsMaster;