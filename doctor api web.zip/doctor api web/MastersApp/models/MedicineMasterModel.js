const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const MedicineIllnessMapping = require('../models/MedicineIllnessMappingModel');

const MedicineMaster = sequelize.define("medicine_master", {
    medicine_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "medicine_name is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    brand_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "medicine_name is required"
            }
        }
    },
    is_allopathy: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: 0,
    },
    is_ayurvedic: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: 0,
    },
}, { freezeTableName: true });

MedicineMaster.hasMany(MedicineIllnessMapping, {
    foreignKey: 'medicine_master_id', // Foreign key in IllnessTypes model that references IllnessSymptoms
    as: 'a' // Alias to be used for the association
});

MedicineMaster.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'medicine_master',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

MedicineMaster.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'medicine_master',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = MedicineMaster;