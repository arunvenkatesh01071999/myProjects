const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const IllnessTypes = require('../models/IllnessTypesModel');

const MedicineIllnessMapping = sequelize.define("medicine_illness_mapping", {
    medicine_master_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "medicine_id is required"
            }
        }
    },
    illness_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "illness_type_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

}, { freezeTableName: true });

MedicineIllnessMapping.belongsTo(IllnessTypes, { foreignKey: 'illness_type_id' });

MedicineIllnessMapping.addHook('afterUpdate', (data, options) => {
    let resp = JSON.stringify({
        action: 'create',
        table_name: 'medicine_illness_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

MedicineIllnessMapping.addHook('afterDestroy', (data, options) => {
    let resp = JSON.stringify({
        action: 'delete',
        table_name: 'medicine_illness_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = MedicineIllnessMapping;