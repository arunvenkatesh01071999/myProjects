const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const Services = require('../../models/ServiceModel');
const logger = require('../../config/activity_logger');


const PrivacyPolicy = sequelize.define("privacy_policy", {
    privacy_policy: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "privacy_policy is required"
            }
        }
    },
    privacy_policy_title: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "privacy_policy_title is required"
            }
        }
    },
    is_for: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 0,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

PrivacyPolicy.belongsTo(Services, { foreignKey: 'is_for' });

PrivacyPolicy.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'privacy_policy',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

PrivacyPolicy.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'privacy_policy',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = PrivacyPolicy;