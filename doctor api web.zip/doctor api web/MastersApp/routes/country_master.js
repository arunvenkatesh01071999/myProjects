const express = require('express');
const router = express();
const CountryMasterController = require('../controller/CountryMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, CountryMasterController.FetchCountry);
router.get('/:id', verify_token, CountryMasterController.FetchCountry);


module.exports = router;