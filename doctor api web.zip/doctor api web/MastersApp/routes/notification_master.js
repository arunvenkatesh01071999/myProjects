const express = require('express');
const router = express();
const NotificationMasterController = require('../controller/NotificationMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, NotificationMasterController.FetchNotificationMasters);
router.get('/:id', verify_token, NotificationMasterController.FetchNotificationMasters);
router.post('/', verify_token, NotificationMasterController.NewNotificationMaster);
router.put('/:id', verify_token, NotificationMasterController.UpdateNotificationMaster);
router.delete('/:id', verify_token, NotificationMasterController.DeleteNotificationMaster);

module.exports = router;