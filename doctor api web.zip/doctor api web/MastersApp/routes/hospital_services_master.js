const express = require('express');
const router = express();
const HospitalServicesMasterController = require('../controller/HospitalServicesMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, HospitalServicesMasterController.FetchHospitalServices);
router.get('/:id', verify_token, HospitalServicesMasterController.FetchHospitalServices);
router.post('/', verify_token, HospitalServicesMasterController.NewHospitalService);
router.put('/:id', verify_token, HospitalServicesMasterController.UpdateHospitalService);
router.delete('/:id', verify_token, HospitalServicesMasterController.DeleteHospitalService);

module.exports = router;