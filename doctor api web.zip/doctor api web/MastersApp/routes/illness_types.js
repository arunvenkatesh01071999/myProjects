const express = require('express');
const router = express();
const IllnessTypesController = require('../controller/IllnessTypesController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, IllnessTypesController.FetchIllnessTypes);
router.get('/:id', verify_token, IllnessTypesController.FetchIllnessTypes);
router.post('/', verify_token, IllnessTypesController.NewIllnessType);
router.put('/:id', verify_token, IllnessTypesController.UpdateIllnessType);
router.delete('/:id', verify_token, IllnessTypesController.DeleteIllnessType);

module.exports = router;