const express = require('express');
const router = express();
const HospitalTypeMasterController = require('../controller/HospitalTypeMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, HospitalTypeMasterController.FetchHospitalTypes);
router.get('/:id', verify_token, HospitalTypeMasterController.FetchHospitalTypes);
router.post('/', verify_token, HospitalTypeMasterController.NewHospitalType);
router.put('/:id', verify_token, HospitalTypeMasterController.UpdateHospitalType);
router.delete('/:id', verify_token, HospitalTypeMasterController.DeleteHospitalType);

module.exports = router;