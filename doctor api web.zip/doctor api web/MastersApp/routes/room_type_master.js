const express = require('express');
const router = express();
const RoomTypeController = require('../controller/RoomTypeMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, RoomTypeController.FetchRoomTypeMaster);
router.get('/:id', verify_token, RoomTypeController.FetchRoomTypeMaster);
router.post('/', verify_token, RoomTypeController.NewRoomTypeMaster);
router.put('/:id', verify_token, RoomTypeController.UpdateRoomTypeMaster);
router.delete('/:id', verify_token, RoomTypeController.DeleteRoomTypeMaster);

module.exports = router;