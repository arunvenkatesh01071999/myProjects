const express = require('express');
const router = express();
const IllnessSymptomsMasterController = require('../controller/IllnessSymptomsMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, IllnessSymptomsMasterController.FetchIllnessSymptomsMasters);
router.get('/:id', verify_token, IllnessSymptomsMasterController.FetchIllnessSymptomsMasters);
router.post('/', verify_token, IllnessSymptomsMasterController.NewIllnessSymptomsMaster);
router.put('/:id', verify_token, IllnessSymptomsMasterController.UpdateIllnessSymptomsMaster);
router.delete('/:id', verify_token, IllnessSymptomsMasterController.DeleteIllnessSymptomsMaster);

module.exports = router;