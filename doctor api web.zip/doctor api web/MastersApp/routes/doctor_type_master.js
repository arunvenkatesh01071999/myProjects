const express = require('express');
const router = express();
const DoctorTypeMasterController = require('../controller/DoctorTypeMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, DoctorTypeMasterController.FetchDoctorTypes);
router.get('/:id', verify_token, DoctorTypeMasterController.FetchDoctorTypes);
router.post('/', verify_token, DoctorTypeMasterController.NewDoctorType);
router.put('/:id', verify_token, DoctorTypeMasterController.UpdateDoctorType);
router.delete('/:id', verify_token, DoctorTypeMasterController.DeleteDoctorType);

module.exports = router;