const express = require('express');
const router = express();
const ParentModuleController = require('../controller/ParentModuleController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ParentModuleController.FetchParentModules);
router.get('/:id', verify_token, ParentModuleController.FetchParentModules);
router.post('/', verify_token, ParentModuleController.NewParentModule);
router.put('/:id', verify_token, ParentModuleController.UpdateParentModule);
router.delete('/:id', verify_token, ParentModuleController.DeleteParentModule);

module.exports = router;