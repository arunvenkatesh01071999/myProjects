const express = require('express');
const router = express();
const LabTestController = require('../controller/LabTestcontroller');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabTestController.FetchLabType);
router.get('/:id', verify_token, LabTestController.FetchLabType);
router.post('/', verify_token, LabTestController.NewLabTest);
router.put('/:id', verify_token, LabTestController.UpdateLabType);
router.delete('/:id', verify_token, LabTestController.DeleteLabType);

module.exports = router;