const express = require('express');
const router = express();
const DepartmentMasterController = require('../controller/DepartmentMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, DepartmentMasterController.FetchDepartmentMasters);
router.get('/:id', verify_token, DepartmentMasterController.FetchDepartmentMasters);
router.post('/', verify_token, DepartmentMasterController.NewDepartmentMaster);
router.put('/:id', verify_token, DepartmentMasterController.UpdateDepartmentMaster);
router.delete('/:id', verify_token, DepartmentMasterController.DeleteDepartmentMaster);


module.exports = router;