const express = require('express');
const router = express();
const LabTypeMasterController = require('../controller/LabTypeMaster');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabTypeMasterController.FetchLabType);
router.get('/:id', verify_token, LabTypeMasterController.FetchLabType);
router.post('/', verify_token, LabTypeMasterController.NewLabType);
router.put('/:id', verify_token, LabTypeMasterController.UpdateLabType);
router.delete('/:id', verify_token, LabTypeMasterController.DeleteLabType);

module.exports = router;