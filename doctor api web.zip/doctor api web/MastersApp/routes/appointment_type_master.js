const express = require('express');
const router = express();
const AppointmentTypeMasterController = require('../controller/AppointmentTypeMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, AppointmentTypeMasterController.FetchAppointmentTypes);
router.get('/:id', verify_token, AppointmentTypeMasterController.FetchAppointmentTypes);
router.post('/', verify_token, AppointmentTypeMasterController.NewAppointmentType);
router.put('/:id', verify_token, AppointmentTypeMasterController.UpdateAppointmentType);
router.delete('/:id', verify_token, AppointmentTypeMasterController.DeleteAppointmentType);

module.exports = router;