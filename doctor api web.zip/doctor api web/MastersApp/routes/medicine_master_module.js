const express = require('express');
const router = express();
const MedicineMasterController = require('../controller/MedicineMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, MedicineMasterController.FetchMedicines);
router.get('/:id', verify_token, MedicineMasterController.FetchMedicines);
router.post('/', verify_token, MedicineMasterController.NewMedicine);
router.put('/:id', verify_token, MedicineMasterController.UpdateMedicine);
router.delete('/:id', verify_token, MedicineMasterController.DeleteMedicine);

module.exports = router;