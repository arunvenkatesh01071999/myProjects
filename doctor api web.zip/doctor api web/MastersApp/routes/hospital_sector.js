const express = require('express');
const router = express();
const HospitalSectorController = require('../controller/HospitalSectorController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, HospitalSectorController.FetchHospitalSector);
router.get('/:id', verify_token, HospitalSectorController.FetchHospitalSector);
router.post('/', verify_token, HospitalSectorController.NewHospitalSector);
router.put('/:id', verify_token, HospitalSectorController.UpdateHospitalSector);
router.delete('/:id', verify_token, HospitalSectorController.DeleteHospitalSector);

module.exports = router;