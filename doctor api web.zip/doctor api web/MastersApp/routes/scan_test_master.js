const express = require('express');
const router = express();
const ScanTestMasterController = require('../controller/ScanTestMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ScanTestMasterController.FetchScanTests);
router.get('/:id', verify_token, ScanTestMasterController.FetchScanTests);
router.post('/', verify_token, ScanTestMasterController.NewScanTest);
router.put('/:id', verify_token, ScanTestMasterController.UpdateScanTest);
router.delete('/:id', verify_token, ScanTestMasterController.DeleteScanTest);

module.exports = router;