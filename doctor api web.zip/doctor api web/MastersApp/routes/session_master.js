const express = require('express');
const router = express();
const SessionMasterController = require('../controller/SessionMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SessionMasterController.FetchSession);
router.get('/:id', verify_token, SessionMasterController.FetchSession);
router.post('/', verify_token, SessionMasterController.NewSession);

module.exports = router;