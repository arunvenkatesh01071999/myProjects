const SpecialityIllnessMapping = require('../models/SpecialityIllnessMappingModel');
const IllnessTypes = require('../models/IllnessTypesModel');
const Specialities = require('../models/SpecialitiesModel');

const Get = async () => {
    await SpecialityIllnessMapping.findAll({ include: [IllnessTypes, Specialities] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await SpecialityIllnessMapping.findAll({ where: { id: id }, include: [IllnessTypes, Specialities] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSpecialityIllnessMapping = async (sm_data) => {
    await SpecialityIllnessMapping.create(sm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateSpecialityIllnessMapping = async (id, sm_data) => {
    await SpecialityIllnessMapping.update(sm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroySpecialityIllnessMapping = async (id) => {
    await SpecialityIllnessMapping.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const DestroySpecialityIllnessMappingbySpeciality = async (id) => {
    await SpecialityIllnessMapping.destroy({ where: { speciality_id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await RoomTypeMaster.findAll({ where: { speciality_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateSpecialityIllnessMapping,
    UpdateSpecialityIllnessMapping,
    DestroySpecialityIllnessMapping,
    DestroySpecialityIllnessMappingbySpeciality
};
