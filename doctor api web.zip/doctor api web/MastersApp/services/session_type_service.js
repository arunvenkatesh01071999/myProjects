const SessionType = require('../models/SessionTypeModel');

const Get = async () => {
    await SessionType.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await SessionType.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSession = async (sl_data) => {
    await SessionType.create(sl_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateSession
};
