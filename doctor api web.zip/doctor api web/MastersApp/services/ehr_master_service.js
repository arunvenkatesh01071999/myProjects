const EhrMaster = require('../models/EhrMasterModel');

const Get = async () => {
    await EhrMaster.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await EhrMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

// const GetbyName = async (name) => {
//     await EhrMaster.findAll({ where: { doctor_type_name: doctor_type_name }, raw: true })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

const CreateEhr = async (ht_data) => {
    await EhrMaster.create(ht_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateEhr = async (id, ht_data) => {
    await EhrMaster.update(ht_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryEhr = async (id) => {
    await EhrMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    // GetbyName,
    CreateEhr,
    UpdateEhr,
    DestoryEhr
};