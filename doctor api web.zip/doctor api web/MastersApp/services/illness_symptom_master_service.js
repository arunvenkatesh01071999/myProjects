const IllnessSymptomsMaster = require('../models/IllnessSymptomsMasterModel');
const IllnessSymptoms = require('../models/IllnessSymptomsModel');
const IllnessTypes = require('../models/IllnessTypesModel');

const Get = async () => {
    await IllnessSymptomsMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await IllnessSymptomsMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyRelations = async (id) => {
    let res;
    await IllnessSymptomsMaster.findAll({

        include: [{
            model: IllnessSymptoms,
            as: 'IllnessSymptoms',
            include: IllnessTypes
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}
const GetbyRelationsId = async (id) => {
    let res;
    await IllnessSymptomsMaster.findAll({
        where: {
            id: id
        },
        include: [{
            model: IllnessSymptoms,
            as: 'IllnessSymptoms',
            include: IllnessTypes
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}


const GetbyRelations1 = async (id) => {
    await IllnessSymptoms.findAll({
        include: [
            {
                model: IllnessTypes,
                attributes: ['id', 'illness_type_name'],
                required: true
            },
            {
                model: IllnessSymptomsMaster,
                attributes: ['id', 'illness_symptom_name'],
                required: true
            }
        ],
        attributes: ['id', 'active', 'created_at', 'updated_at', 'created_by', 'updated_by']
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyName = async (name) => {
    let res;
    await IllnessSymptomsMaster.findAll({ where: { illness_symptom_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateIllnessSymptomsMaster = async (sm_data) => {
    await IllnessSymptomsMaster.create(sm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateIllnessSymptomsMaster = async (id, sm_data) => {
    await IllnessSymptomsMaster.update(sm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyIllnessSymptomsMaster = async (id) => {

    await IllnessSymptoms.destroy({ where: { illness_symptom_id: id } })
    await IllnessSymptomsMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateIllnessSymptomsMaster,
    UpdateIllnessSymptomsMaster,
    DestroyIllnessSymptomsMaster,
    GetbyName,
    GetbyRelations,
    GetbyRelationsId

};
