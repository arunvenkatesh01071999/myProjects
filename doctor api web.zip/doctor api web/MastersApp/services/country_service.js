const Country = require('../models/CountryModel');

const Get = async () => {
    await Country.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Country.findAll({ where: { id: id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateCountry = async (c_data) => {
    await Country.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateCountry = async (id, c_data) => {
    await Country.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyCountry = async (id) => {
    await Country.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateCountry,
    UpdateCountry,
    DestroyCountry
};
