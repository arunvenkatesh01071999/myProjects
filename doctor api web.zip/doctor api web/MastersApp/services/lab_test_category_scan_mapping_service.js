const LabTestsCategoryScanMapping = require('../models/LabTestsCategoryScanMappingModel');
const LabTestCategory = require('../models/LabTestCategoryModel');
const ScanTestMaster = require('../models/ScanTestMasterModel');

const Get = async () => {
    await LabTestsCategoryScanMapping.findAll({ include: [LabTestCategory, ScanTestMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (lab_test_category_id) => {
    await LabTestsCategoryScanMapping.findAll({ include: [LabTestCategory, ScanTestMaster], where: { lab_test_category_id: lab_test_category_id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabTestsCategoryScanMapping = async (cs_data) => {
    await LabTestsCategoryScanMapping.create(cs_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabTestsCategoryScanMapping = async (id, cs_data) => {
    await LabTestsCategoryScanMapping.update(cs_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabTestsCategoryScanMapping = async (id) => {
    await LabTestsCategoryScanMapping.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateLabTestsCategoryScanMapping,
    UpdateLabTestsCategoryScanMapping,
    DestroyLabTestsCategoryScanMapping
};
