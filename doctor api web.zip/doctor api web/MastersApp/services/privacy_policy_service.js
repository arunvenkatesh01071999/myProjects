const Services = require('../../models/ServiceModel');
const PrivacyPolicy = require('../models/PrivacyPolicyModel');

const Get = async () => {
    await PrivacyPolicy.findAll({ include: [Services] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await PrivacyPolicy.findAll({ where: { id: id }, include: [Services] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreatePrivacyPolicy = async (pp_data) => {
    await PrivacyPolicy.create(pp_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdatePrivacyPolicy = async (id, pp_data) => {
    await PrivacyPolicy.update(pp_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyPrivacyPolicy = async (id) => {
    await PrivacyPolicy.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreatePrivacyPolicy,
    UpdatePrivacyPolicy,
    DestroyPrivacyPolicy
};
