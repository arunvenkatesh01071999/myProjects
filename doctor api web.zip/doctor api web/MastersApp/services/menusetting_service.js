const MenuSettingModel = require('../models/MenuSettingModel');
const RoleModel = require('../../models/RoleModel');
const UserModel = require('../../models/UserModel');
const Menu = require('../models/MenuModel');
const SubMenuModel = require('../models/SubMenuModel');
const db1 = require('../../config/db1');
const { log } = require('winston');



const Get = async () => {
    await MenuSettingModel.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await RoleModel.findAll({ where: { service_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyUserId = async (id) => {

    await UserModel.findAll({ where: { roles_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyAllData = async (role_id, user_id) => {
    var result = [];
    const query = `select * from m_menu where active=1`;
    var customerFeedback = await db1.query(query);
    var menu_data = customerFeedback.flat();

    for (let i = 0; i < menu_data.length - 1; i++) {
        const query1 = `select * from m_submenu where active=1 and menu_id= '${menu_data[i]['id']}'`;
        var submenu_list = await db1.query(query1);
        var submenu_list_flat = submenu_list.flat();


        const menuexist = `select * from m_menusettings 
        where menu_id= '${menu_data[i]['id']}' and user_id='${user_id}' and role_id='${role_id}' `;
        const rows = await db1.query(menuexist);
        rows_count = rows.flat();
        const check_count = rows_count[0];
        if (check_count > 0) {
            var checkmenu = 1;
        } else {
            var checkmenu = 0;
        }
        var submenulist = [];

        for (let j = 0; j < submenu_list_flat.length - 1; j++) {
            const submenuexist = `select * from m_menusettings 
            where menu_id= ${menu_data[i]['id']} and user_id=${user_id} and role_id=${role_id} 
            and submenu_id= ${submenu_list_flat[j]['id']}  `;

            const rows1 = await db1.query(submenuexist);
            rows_submenu_count = rows1.flat();
            console.log('rows_submenu_count', rows_submenu_count);
            const check_sub_menu_count = rows_submenu_count[0];
            const length_data = rows_submenu_count.length - 1;

            if (length_data > 0) {
                var checksubMenu = 1;
            } else {
                var checksubMenu = 0;
            }


            submenulist.push({
                submenu_id: submenu_list_flat[j]['id'],
                submenu_name: submenu_list_flat[j]['submenu_name'],
                submenu_url: submenu_list_flat[j]['submenu_url'],
                submenu_active: submenu_list_flat[j]['active'],
                submenu_check: checksubMenu,
            });
        }
        result.push({
            menuId: menu_data[i]['id'],
            userId: user_id,
            menuName: menu_data[i]['menu_name'],
            menu_icon: menu_data[i]['menu_icon'],
            sub_icon: menu_data[i]['sub_icon'],
            menu_url: menu_data[i]['menu_url'],
            menuCheck: checkmenu,
            SubmenuList: submenulist,
        });
    }
    return result;
}

const updatemenu = async (roll_id, user_id, id, m_id, module_id) => {

    const query1 = `select * from m_menusettings 
    where menu_id= ${m_id} and  submenu_id= ${id} and user_id= ${user_id} and module_id= ${module_id} 
    and role_id= ${roll_id}`;
    var data = await db1.query(query1);
    return data[0]
}

const destroymenu = async (roll_id, user_id, id, m_id, module_id) => {
    await MenuSettingModel.destroy({
        where: {
            submenu_id: parseInt(id),
            menu_id: parseInt(m_id),
            user_id: parseInt(user_id),
            role_id: parseInt(roll_id),
            module_id: parseInt(module_id)

        }
    })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const GetbyName = async (name) => {
    await MenuSettingModel.findAll({ where: { submenu_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSubmenu = async (a_data) => {
    await MenuSettingModel.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateSubMenu = async (id, a_data) => {
    await MenuSettingModel.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroySubMenu = async (id) => {
    await MenuSettingModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const Createmenu = async (insertData) => {
    await MenuSettingModel.create(insertData)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const loaddashboardservices = async (role_id, user_id) => {
    var result = [];
    const query = `select * from m_menu where active=1`;
    var customerFeedback = await db1.query(query);
    var menu_data = customerFeedback.flat();

    for (let i = 0; i < menu_data.length - 1; i++) {
        const query1 = `select * from m_submenu where active=1 and menu_id= '${menu_data[i]['id']}'`;
        var submenu_list = await db1.query(query1);
        var submenu_list_flat = submenu_list.flat();


        const menuexist = `select * from m_menusettings 
        where menu_id= ${menu_data[i]['id']} and user_id=${user_id} and role_id=${role_id}  `;
        const rows = await db1.query(menuexist);
        rows_count = rows.flat();
        const check_count = rows_count[0];

        if (check_count > 0) {
            var checkmenu = 1;
        } else {
            var checkmenu = 0;
        }
        var submenulist = [];

        for (let j = 0; j < submenu_list_flat.length - 1; j++) {
            const submenuexist = `select * from m_menusettings 
            where menu_id= ${menu_data[i]['id']} and user_id=${user_id} and role_id=${role_id}
             and submenu_id= ${submenu_list_flat[j]['id']} `;

            const rows1 = await db1.query(submenuexist);
            rows_submenu_count = rows1.flat();
            const check_sub_menu_count = rows_submenu_count[0];
            const length_data = rows_submenu_count.length - 1;

            if (length_data > 0) {
                var checksubMenu = 1;
            } else {
                var checksubMenu = 0;
            }


            submenulist.push({
                submenu_id: submenu_list_flat[j]['id'],
                submenu_name: submenu_list_flat[j]['submenu_name'],
                submenu_url: submenu_list_flat[j]['submenu_url'],
                submenu_active: submenu_list_flat[j]['active'],
                submenu_check: checksubMenu,
            });
        }
        result.push({
            menuId: menu_data[i]['id'],
            userId: user_id,
            menuName: menu_data[i]['menu_name'],
            menu_icon: menu_data[i]['menu_icon'],
            sub_icon: menu_data[i]['sub_icon'],
            menu_url: menu_data[i]['menu_url'],
            menuCheck: checkmenu,
            SubmenuList: submenulist,
        });

    }

    result.forEach((item) => {
        // Check if any SubmenuList item has submenu_check === 1
        const hasSubmenuCheck = item.SubmenuList.some((submenu) => submenu.submenu_check === 1);

        // Set the menuCheck property accordingly
        item.menuCheck = hasSubmenuCheck ? 1 : 0;
    });


    return result;
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateSubmenu,
    UpdateSubMenu,
    DestroySubMenu,
    GetbyAllData,
    GetbyUserId,
    updatemenu,
    destroymenu,
    loaddashboardservices,
    Createmenu
};