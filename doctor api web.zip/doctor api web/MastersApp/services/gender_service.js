const Gender = require('../models/GenderModel');

const Get = async () => {
    await Gender.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Gender.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateGender = async (h_data) => {
    await Gender.create(h_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateGender = async (id, h_data) => {
    await Gender.update(h_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyGender = async (id) => {
    await Gender.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await Gender.findAll({ where: { gender_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateGender,
    UpdateGender,
    DestroyGender
};
