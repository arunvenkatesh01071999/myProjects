const LabSector = require('../models/LabSectorModel');

const Get = async () => {
    await LabSector.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await LabSector.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await LabSector.findAll({ where: { lab_sector_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabSector = async (l_data) => {
    await LabSector.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabSector = async (id, h_data) => {
    await LabSector.update(h_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabSector = async (id) => {
    await LabSector.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateLabSector,
    UpdateLabSector,
    DestroyLabSector
};
