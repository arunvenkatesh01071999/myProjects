const LabTestModelId = require('../models/LabtestIdModel');

const CreateLabTestId = async (lt_data) => {
    await LabTestModelId.create(lt_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabTypeId = async (id) => {
    await LabTestModelId.destroy({ where: { test_name_id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateLabTestId,
    DestroyLabTypeId
};