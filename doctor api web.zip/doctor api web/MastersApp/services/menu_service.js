const MenuModel = require('../models/MenuModel');
const service_master = require('../../models/ServiceModel')

const Get = async () => {
    await MenuModel.findAll({ include: service_master })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await MenuModel.findAll({ where: { id: id }, include: service_master })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await MenuModel.findAll({ where: { submenu_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const Createmenu = async (a_data) => {
    await MenuModel.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateMenu = async (id, a_data) => {
    await MenuModel.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyMenu = async (id) => {
    await MenuModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    Createmenu,
    UpdateMenu,
    DestroyMenu
};