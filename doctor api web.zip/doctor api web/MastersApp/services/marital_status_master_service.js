const MaritalStatusMasterModel = require('../models/MaritalStatusMasterModel');

const Get = async () => {
    await MaritalStatusMasterModel.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await MaritalStatusMasterModel.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (m_name) => {
    await MaritalStatusMasterModel.findAll({ where: { m_name: m_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const createMaritalStatus = async () => {
    await MaritalStatusMasterModel.create(ms_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateMaritalSatatus = async (id, ms_data) => {
    await MaritalStatusMasterModel.update(ms_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyMaritalSatatus = async (id) => {
    await MaritalStatusMasterModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    createMaritalStatus,
    UpdateMaritalSatatus,
    DestroyMaritalSatatus
};