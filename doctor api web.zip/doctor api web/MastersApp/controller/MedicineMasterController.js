const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const medicine_master_services = require('../services/medicine_master_service');
const medicine_illness_mapping_service = require('../services/medicine_illness_mapping_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchMedicines = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await medicine_master_services.GetbyRelationsId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_medicine_master');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await medicine_master_services.GetbyRelations()
                .then(data => {
                    cache.SET(req.user.id + '_medicine_master', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewMedicine = async (req, res, next) => {
    const medicine_name = req.body.medicine_name;
    const brand_name = req.body.brand_name;
    const illness_type_ids = req.body.illness_type_ids;
    const is_allopathy = req.body.is_allopathy;
    const is_ayurvedic = req.body.is_ayurvedic;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    if (medicine_name && brand_name && illness_type_ids && Array.isArray(illness_type_ids)) {

        m_data = {
            medicine_name: medicine_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by,
            brand_name: brand_name,
            is_allopathy: is_allopathy,
            is_ayurvedic: is_ayurvedic

        }

        await medicine_master_services.GetbyName(medicine_name)
            .then(symptom_data => {
                if (symptom_data.length > 0) {
                    msg = "Medicine Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    medicine_master_services.CreateMedicine(m_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {

                                medicine_data = data.dataValues;
                                medicine_id = medicine_data.id;

                                if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
                                    for (const i of illness_type_ids) { // Use for...of loop
                                        const nt_data = {
                                            medicine_master_id: medicine_id,
                                            illness_type_id: i,
                                            active: true,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        // console.log(nt_data);
                                        medicine_illness_mapping_service.CreateMedicineMap(nt_data);
                                    }
                                }

                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_medicine_master')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })

    } else {
        // msg = "medicine_name and active is required";
        msg = "medicine_name, illness_type_ids and active is required and illness_type_ids should be an array";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateMedicine = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const medicine_name = req.body.medicine_name;
        const brand_name = req.body.brand_name;
        const illness_type_ids = req.body.illness_type_ids;
        const is_allopathy = req.body.is_allopathy;
        const is_ayurvedic = req.body.is_ayurvedic;
        const active = req.body.active;
        const created_by = req.user.id;
        const updated_by = req.user.id;
        if (medicine_name && brand_name && illness_type_ids && Array.isArray(illness_type_ids)) {
            m_data = {
                medicine_name: medicine_name,
                active: active,
                created_by: created_by,
                updated_by: updated_by,
                brand_name: brand_name,
                is_allopathy: is_allopathy,
                is_ayurvedic: is_ayurvedic

            }
            // await medicine_master_services.GetbyName(medicine_name)
            //     .then(symptom_data => {
            //         if (symptom_data.length > 0) {
            //             msg = "Medicine Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            medicine_master_services.UpdateMedicine(id, m_data)
                .then(data => {
                    if (data == 1) {

                        if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
                            medicine_illness_mapping_service.DestroyMedicineMap(id);
                            for (const i of illness_type_ids) { // Use for...of loop
                                const nt_data = {
                                    medicine_master_id: id,
                                    illness_type_id: i,
                                    active: true,
                                    created_by: created_by,
                                    updated_by: updated_by
                                }
                                // console.log(nt_data);
                                medicine_illness_mapping_service.CreateMedicineMap(nt_data);
                            }
                        }

                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_medicine_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            //     }
            // })
        } else {
            msg = "medicine_name, illness_type_ids and active is required and illness_type_ids should be an array";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteMedicine = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        medicine_illness_mapping_service.DestroyMedicineMap(id);
        await medicine_master_services.DestroyMedicine(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_medicine_master')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewMedicine,
    FetchMedicines,
    UpdateMedicine,
    DeleteMedicine
}