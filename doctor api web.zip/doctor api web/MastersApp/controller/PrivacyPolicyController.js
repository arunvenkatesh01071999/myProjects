const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const privacy_policy_service = require('../services/privacy_policy_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchPrivacyPolicies = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await privacy_policy_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_privacy_policy');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await privacy_policy_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_privacy_policy', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewPrivacyPolicy = async (req, res, next) => {
    privacy_policy = req.body.privacy_policy;
    privacy_policy_title = req.body.privacy_policy_title;
    is_for = req.body.is_for;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (privacy_policy && privacy_policy_title) {
        pp_data = {
            privacy_policy: privacy_policy,
            privacy_policy_title: privacy_policy_title,
            is_for: is_for,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await privacy_policy_service.CreatePrivacyPolicy(pp_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_privacy_policy')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "privacy_policy, privacy_policy_title, is_for and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdatePrivacyPolicy = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        privacy_policy = req.body.privacy_policy;
        privacy_policy_title = req.body.privacy_policy_title;
        is_for = req.body.is_for;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (privacy_policy && privacy_policy_title) {
            pp_data = {
                privacy_policy: privacy_policy,
                privacy_policy_title: privacy_policy_title,
                is_for: is_for,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await privacy_policy_service.UpdatePrivacyPolicy(id, pp_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_privacy_policy')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "privacy_policy, privacy_policy_title, is_for and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeletePrivacyPolicy = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await privacy_policy_service.DestroyPrivacyPolicy(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_privacy_policy')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewPrivacyPolicy,
    FetchPrivacyPolicies,
    UpdatePrivacyPolicy,
    DeletePrivacyPolicy
}