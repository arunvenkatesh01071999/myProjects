const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const lab_test_services = require('../services/lab_test_service');
const lab_test_servicesId = require('../services/lab_typeId_service');
const cache = require('../../services/redis_cache_service');
const date = require('../../services/datetime_service');

const FetchLabType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_test_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        await lab_test_services.Get()
            .then(data => {
                //cache.SET(req.user.id + '_lab_test_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}


const NewLabTest = async (req, res, next) => {
    // console.log("data", req.body);
    test_name = req.body.test_name;
    alter_name = req.body.alter_name;
    category_id = req.body.category_id;
    long_descrip = req.body.long_descrip;
    short_descrip = req.body.short_descrip;
    recommend = req.body.recommend;
    sample_collected = req.body.sample_collected;
    pretest_prepare = req.body.pretest_prepare;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (test_name && category_id && Array.isArray(category_id)) {

        const c_data = {
            test_name: test_name,
            alter_name: alter_name,
            long_descrip: long_descrip,
            short_descrip: short_descrip,
            recommend: recommend,
            sample_collected: parseInt(sample_collected),
            pretest_prepare: pretest_prepare,
            active: parseInt(active),
            created_by: created_by,
            updated_by: updated_by
        }

        console.log(c_data, "c_data");
        await lab_test_services.GetbyName(test_name)
            .then(symptom_data => {
                if (symptom_data.length > 0) {
                    msg = "Test Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    lab_test_services.CreateLabTest(c_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                testNameData = data.dataValues;
                                ltid = testNameData.id;
                                if (category_id && Array.isArray(category_id) && category_id.length > 0) {
                                    for (const i of category_id) {
                                        const lt_data = {
                                            test_name_id: ltid,
                                            category_id: parseInt(i),
                                            active: 1,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        lab_test_servicesId.CreateLabTestId(lt_data);
                                    }
                                }

                                msg = "Created Successfully"
                                res.status(200).json(success_func(msg))
                            }
                        })
                }
            })
    }
    else {
        msg = "test_name and active is required and lab test category_id should be an array";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateLabType = async (req, res, next) => {
    const id = req.params.id;
    //  console.log("id",id);
    if (id) {
        test_name = req.body.test_name;
        alter_name = req.body.alter_name;
        category_id = req.body.category_id;
        long_descrip = req.body.long_descrip;
        short_descrip = req.body.short_descrip;
        recommend = req.body.recommend;
        sample_collected = req.body.sample_collected;
        pretest_prepare = req.body.pretest_prepare;
        active = req.body.active;
        created_by = req.user.id;
        updated_by = req.user.id;
        updated_at = date();
        if (test_name) {
            const c_data = {
                test_name: test_name,
                alter_name: alter_name,
                long_descrip: long_descrip,
                short_descrip: short_descrip,
                recommend: recommend,
                sample_collected: parseInt(sample_collected),
                pretest_prepare: pretest_prepare,
                active: parseInt(active),
                updated_by: updated_by,
                updated_at: updated_at
            }
            await lab_test_services.UpdateLabType(id, c_data)
                .then(data => {
                    if (data == 1) {
                        if (category_id && Array.isArray(category_id)) {
                            lab_test_servicesId.DestroyLabTypeId(id);
                            // console.log(category_id);
                            for (const i of category_id) {
                                const lt_data = {
                                    test_name_id: id,
                                    category_id: parseInt(i),
                                    active: 1,
                                    created_by: created_by,
                                    updated_by: updated_by
                                }
                                console.log("lt_data", lt_data);
                                lab_test_servicesId.CreateLabTestId(lt_data);
                            }
                        }
                        msg = "Updated successfully"
                        res.status(200).json(success_func(msg))
                    }
                    else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        else {
            msg = "test_name and category_id is required";
            res.status(400).json(failure_func(msg))
        }
    }
    else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


const DeleteLabType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_test_services.DestroyLabType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    // cache.DEL(req.user.id + '_lab_type_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

module.exports = {
    NewLabTest,
    UpdateLabType,
    DeleteLabType,
    FetchLabType
}
