const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const lab_type_services = require('../services/lab_type_master_service');
const cache = require('../../services/redis_cache_service');
const date = require('../../services/datetime_service');

const FetchLabType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_type_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_city_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await lab_type_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_lab_type_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewLabType = async (req, res, next) => {
    lab_type_name = req.body.lab_type_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (lab_type_name) {
        c_data = {
            lab_type_name: lab_type_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await lab_type_services.GetbyName(lab_type_name)
            .then(acc_data => {
                if (acc_data.length > 0) {
                    msg = " Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    lab_type_services.CreateLabType(c_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_lab_type_services')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "Name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateLabType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        lab_type_name = req.body.lab_type_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (lab_type_name) {
            c_data = {
                lab_type_name: lab_type_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await lab_type_services.UpdateLabType(id, c_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_languages')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(500).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })

        } else {
            msg = "lab_type_name and active is required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeleteLabType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_type_services.DestroyLabType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_lab_type_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

module.exports = {
    FetchLabType,
    NewLabType,
    UpdateLabType,
    DeleteLabType
}