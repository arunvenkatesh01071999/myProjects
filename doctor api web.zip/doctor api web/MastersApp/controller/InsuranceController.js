const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const insurance_services = require('../services/insurance_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchInsurances = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await insurance_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_insurance_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await insurance_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_insurance_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewInsurance = async (req, res, next) => {
    try {
        const insurance_name = req.body.insurance_name;
        const logo_image = req.files.logo_image;
        const active = req.body.active;
        const created_by = req.user.id;
        const updated_by = req.user.id;

        if (!insurance_name) {
            throw new Error("insurance_name is required");
        }

        const datas = {
            insurance_name: insurance_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };

        if (logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = logo_image.name;
            const buffer = logo_image.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            datas.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
        } else {
            datas.logo_image = null; // Set logo_image to null if not provided
        }

        console.log(datas, "insurance_name");

        // Check if insurance name already exists
        const insurance_data = await insurance_services.GetbyName(insurance_name);
        if (insurance_data.length > 0) {
            const msg = "Insurance Name already exists";
            return res.status(200).json(failure_func(msg));
        }

        // Insert portion
        const data = await insurance_services.CreateInsurance(datas);

        if (data.errors) {
            const msg = data.errors[0].message;
            res.status(400).json(failure_func(msg));
        } else {
            const msg = "Created Successfully";
            cache.DEL(req.user.id + '_insurance_services');
            res.status(200).json(success_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};

const UpdateInsurance = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        const insurance_name = req.body.insurance_name;
        let logo_image_data;

        if (req.body.logo_image && req.body.logo_image !== 'undefined') {
            logo_image_data = req.body.logo_image;
        } else {
            const logo_image = req.files.logo_image;

            if (logo_image) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = logo_image.name;
                const buffer = logo_image.data;
                const path = `images/${fileName}`;

                const file = storage.bucket(bucketName).file(path);

                // Upload the image to GCS
                await file.save(buffer);

                logo_image_data = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
        }

        const active = req.body.active;
        const updated_by = req.user.id;
        const updated_at = date();

        if (!insurance_name) {
            const msg = "insurance_name and active are required";
            return res.status(400).json(failure_func(msg));
        }

        const i_data = {
            insurance_name: insurance_name,
            logo_image: logo_image_data,
            active: active,
            updated_by: updated_by,
            updated_at: updated_at
        };

        const data = await insurance_services.UpdateInsurance(id, i_data);

        if (data === 1) {
            const msg = "Updated successfully";
            cache.DEL(req.user.id + '_insurance_services');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "ID doesn't exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};

const DeleteInsurance = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        // Fetch insurance data by ID
        const insuranceData = await insurance_services.GetbyId(id);

        if (!insuranceData) {
            const msg = "ID doesn't exist";
            return res.status(400).json(failure_func(msg));
        }

        // Delete the image from GCS
        if (insuranceData.logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = insuranceData.logo_image.split('/').pop(); // Extract file name from URL
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Delete the image from GCS
            await file.delete();
        }

        // Delete insurance entry
        const deletedRows = await insurance_services.DestroyInsurance(id);

        if (deletedRows === 1) {
            const msg = "Deleted successfully";
            cache.DEL(req.user.id + '_insurance_services');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "Failed to delete. ID may not exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};


module.exports = {
    NewInsurance,
    FetchInsurances,
    UpdateInsurance,
    DeleteInsurance
}

// const NewInsurance = async (req, res, next) => {
//     // console.log(req,"req.files");
//     // console.log(req.files.logo_image,"req.files.logo_image");

//     insurance_name = req.body.insurance_name;
//     try {
//         logo_image = req.files.logo_image;
//     } catch {
//         logo_image = null
//     }
//     active = req.body.active;
//     created_by = 2;
//     updated_by = 2;

//     if (insurance_name) {
//         datas = {
//             insurance_name:insurance_name,
//             active: 1,
//             created_by: 2,
//             updated_by: 2
//         }

//         if (logo_image) {
//             datas.logo_image = logo_image.name;
//             buffer = logo_image.data
//             path = './media/' + logo_image.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         // console.log(logo_image,"req.files.logo_image");
//         console.log(datas,"insurance_name");
//         await insurance_services.GetbyName(insurance_name)
//             .then(insurance_data => {
//                 if (insurance_data.length > 0) {
//                     msg = "Insurance Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     //insert portion
//                     insurance_services.CreateInsurance(datas)
//                         .then(data => {
//                             console.log(data,"data");
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_insurance_services')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     }
//     else {
//         msg = "insurance_name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteInsurance = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await insurance_services.DestroyInsurance(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_insurance_services')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateInsurance = async (req, res, next) => {
//     img_data = req.body.logo_image
//     id = req.params.id;
//     if (id) {
//         insurance_name = req.body.insurance_name;
//         if (img_data && img_data != 'undefined') {
//             logo_image_data = img_data
//         }
//         else {
//             logo_image = req.files.logo_image;
//             if (logo_image) {
//                 logo_image_data = logo_image.name;
//                 buffer = logo_image.data
//                 path = './media/' + logo_image.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             }
//         }
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (insurance_name) {
//             i_data = {
//                 insurance_name: insurance_name,
//                 logo_image: logo_image_data,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             insurance_services.UpdateInsurance(id, i_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_insurance_services')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })

//         } else {
//             msg = "insurance_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }
