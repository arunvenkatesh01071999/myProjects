const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const our_services = require('../services/our_services_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchOurServices = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await our_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_our_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await our_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_our_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

// const NewOurServices = async (req, res, next) => {
//     const services_name = req.body.services_name;
//     const link = req.body.link;
//     try {
//         image_path = req.files.image_path;
//     } catch {
//         image_path = null
//     }
//     const active = req.body.active;
//     const created_by = req.user.id;
//     const updated_by = req.user.id;
//     if (services_name) {
//         datas = {
//             services_name: services_name,
//             link: link,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         if (image_path) {
//             datas.image_path = image_path.name;
//             buffer = image_path.data
//             path = './media/ourservices/' + image_path.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         await our_services.GetbyName(services_name)
//             .then(services_data => {
//                 if (services_data.length > 0) {
//                     msg = "Service Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     our_services.CreateOurServices(datas)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_our_services')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     } else {
//         msg = "image_path and link is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateOurServices = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         services_name = req.body.services_name;
//         link = req.body.link;
//         try {
//             image_path = req.files.image_path;
//         } catch {
//             image_path = null
//         }
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (services_name) {
//             datas = {
//                 services_name: services_name,
//                 link: link,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             if (image_path) {
//                 datas.image_path = image_path.name;
//                 buffer = image_path.data
//                 path = './media/ourservices/' + image_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             }
//             // await our_services.GetbyName(services_name)
//             //     .then(services_data => {
//             //         if (services_data.length > 0) {
//             //             msg = "Service Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             our_services.UpdateOurServices(id, datas)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_our_services')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//             //     }
//             // })
//         } else {
//             msg = "image_path and link is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const NewOurServices = async (req, res, next) => {
    const services_name = req.body.services_name;
    const link = req.body.link;
    const image_path = req.files ? req.files.image_path : null;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    if (services_name) {
        const datas = {
            services_name: services_name,
            link: link,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };
        if (image_path) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = image_path.name;
            const buffer = image_path.data;
            const path = `images/${fileName}`;
            const file = storage.bucket(bucketName).file(path);
            // Upload the image to GCS
            await file.save(buffer);
            datas.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            // If no image is provided, you may want to handle null or default values
            datas.image_path = null; // or set a default image URL
        }
        await our_services.GetbyName(services_name)
            .then(services_data => {
                if (services_data.length > 0) {
                    msg = "Service Name already exists";
                    return res.status(200).json(failure_func(msg));
                } else {
                    our_services.CreateOurServices(datas)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg));
                            } else {
                                msg = "Created Successfully";
                                cache.DEL(req.user.id + '_our_services');
                                res.status(200).json(success_func(msg));
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err));
                        });
                }
            });
    } else {
        msg = "services_name, link, and image_path are required";
        res.status(400).json(failure_func(msg));
    }
};
const UpdateOurServices = async (req, res, next) => {
    try {
        id = req.params.id;
        if (id) {
            services_name = req.body.services_name;
            link = req.body.link;
            let image_path = req.files ? req.files.image_path : null;
            // try {
            //     image_path = req.files.image_path;
            // } catch {
            //     image_path = null
            // }
            active = req.body.active;
            updated_by = req.user.id;
            updated_at = date();
            if (services_name) {
                datas = {
                    services_name: services_name,
                    link: link,
                    active: active,
                    updated_by: updated_by,
                    updated_at: updated_at
                }
                // if (image_path) {
                //     datas.image_path = image_path.name;
                //     buffer = image_path.data
                //     path = './media/ourservices/' + image_path.name;
                //     fs.writeFile(path.toString(), buffer, function (err) {
                //         if (err) {
                //             return console.log(err);
                //         }
                //     });
                // }
                if (image_path) {
                    const bucketName = process.env.GCP_BUCKET_NAME;
                    const fileName = image_path.name;
                    const buffer = image_path.data;
                    const path = `images/${fileName}`;
                    const file = storage.bucket(bucketName).file(path);
                    await file.save(buffer);
                    datas.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
                }
                else {
                    // If no image is provided, you may want to handle null or default values
                    datas.image_path = null; // or set a default image URL
                }
                our_services.UpdateOurServices(id, datas)
                    .then(data => {
                        if (data == 1) {
                            msg = "Updated successfully"
                            cache.DEL(req.user.id + '_our_services')
                            res.status(200).json(success_func(msg))
                        } else {
                            msg = "ID doesn't exist"
                            res.status(400).json(failure_func(msg))
                        }
                    })
                    .catch(err => {
                        res.status(400).json(failure_func(err))
                    })
                //     }
                // })
            } else {
                msg = "image_path and link is required";
                res.status(400).json(failure_func(msg))
            }
        } else {
            msg = "ID is required";
            res.status(400).json(failure_func(msg))
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
}

const DeleteOurServices = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await our_services.DestroyOurServices(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_our_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    NewOurServices,
    FetchOurServices,
    UpdateOurServices,
    DeleteOurServices
}