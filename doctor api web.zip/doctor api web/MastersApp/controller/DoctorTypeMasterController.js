const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const doctor_type_master_service = require('../services/doctor_type_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchDoctorTypes = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await doctor_type_master_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_doctor_type_master_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
            await doctor_type_master_service.Get()
                .then(data => {
                    // cache.SET(req.user.id + '_doctor_type_master_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
// }

const NewDoctorType = async (req, res, next) => {
    doctor_type_name = req.body.doctor_type_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (doctor_type_name) {
        ht_data = {
            doctor_type_name: doctor_type_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await doctor_type_master_service.GetbyName(doctor_type_name)
            .then(doctor_type_data => {
                if (doctor_type_data.length > 0) {
                    msg = "Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    doctor_type_master_service.CreateDoctorType(ht_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_doctor_type_master_service')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "doctor_type_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateDoctorType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_type_name = req.body.doctor_type_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (doctor_type_name) {
            ht_data = {
                doctor_type_name: doctor_type_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            doctor_type_master_service.UpdateDoctorType(id, ht_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_doctor_type_master_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "doctor_type_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteDoctorType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await doctor_type_master_service.DestroyDoctorType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_doctor_type_master_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewDoctorType,
    FetchDoctorTypes,
    UpdateDoctorType,
    DeleteDoctorType
}