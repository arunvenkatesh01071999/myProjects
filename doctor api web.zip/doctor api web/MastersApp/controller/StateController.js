const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const state_services = require('../services/state_service');
const cache = require('../../services/redis_cache_service');


const FetchState = async (req, res, next) => {
    // id = req.params.id;
    // if (id) {
    //     await state_services.GetbyId(id)
    //         .then(data => {
    //             res.status(200).json(success_func(data))
    //         })
    //         .catch(err => {
    //             res.status(400).json(failure_func(err))
    //         })
    // } else {
    // data = await cache.GET(req.user.id + '_state_services');
    if (data) {
        res.status(200).json(success_func(JSON.parse(data)))
    } else {
        await state_services.Get()
            .then(data => {
                // cache.SET(req.user.id + '_state_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
// }
}

const FetchByCountryId = async (req, res, next) => {
    country_id = req.params.country_id;
    console.log(country_id,"country_id");
    if (country_id) {
        await state_services.FetchByCountryId(country_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {

        msg = "ID Not found";
        res.status(401).json(failure_func(msg))

    }
}

module.exports = {
    FetchState,
    FetchByCountryId
}