const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const illness_symptoms_services = require('../services/illness_symptoms_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchIllnessSymptoms = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_symptoms_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_illness_symptoms');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await illness_symptoms_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_illness_symptoms', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewIllnessSymptom = async (req, res, next) => {
    illness_symptom_id = req.body.illness_symptom_id;
    illness_type_id = req.body.illness_type_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (illness_symptom_id && illness_type_id) {
        i_data = {
            illness_symptom_id: illness_symptom_id,
            illness_type_id: illness_type_id,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await illness_symptoms_services.CreateIllnessSymptom(i_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_illness_symptoms')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "illness_symptom_id, illness_type_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateIllnessSymptom = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        illness_symptom_id = req.body.illness_symptom_id;
        illness_type_id = req.body.illness_type_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (illness_symptom_id) {
            i_data = {
                illness_symptom_id: illness_symptom_id,
                illness_type_id: illness_type_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await illness_symptoms_services.UpdateIllnessSymptom(id, i_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_illness_symptoms')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "illness_symptom_id, illness_type_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteIllnessSymptom = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_symptoms_services.DestroyIllnessSymptom(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_illness_symptoms')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewIllnessSymptom,
    FetchIllnessSymptoms,
    UpdateIllnessSymptom,
    DeleteIllnessSymptom
}