const success_func = require('../api_responser').success_func;
const failure_func = require('../api_responser').failure_func;
const date = require('../services/datetime_service');
const crypto = require('crypto');
const generate_otp = require('../services/generate_otp');
const fs = require('fs');
const { add_to_queue } = require('../queues/email_queue');
const { send_otp } = require('../services/send_mobile_otp');
const user_services = require('../services/user_service');
const notification_mapping_services = require('../MastersApp/services/notification_mapping_service');
const cache = require('../services/redis_cache_service');


const FetchUsers = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await user_services.GetbyId(id)
            .then(user => {
                res.status(200).json(success_func(user))
            })
            .catch(err => {
                res.status(401).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_users');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await user_services.Get()
                .then(user => {
                    cache.SET(req.user.id + '_users', user)
                    res.status(200).json(success_func(user))
                })
                .catch(err => {
                    res.status(401).json(failure_func(err))
                })
        }
    }
}
const NewUser = async (req, res, next) => {
    email = req.body.email;
    username = req.body.username;
    password = req.body.password;
    mobile = req.body.mobile;
    created_by = req.user.id;
    updated_by = req.user.id;
    notification_ids = req.body.notification_ids.split(",");
    roles_id = req.body.roles_id;
    active = req.body.active;
    otp = 1;


    try {
        profile_image = req.files.profile_image;
    } catch {
        profile_image = null
    }

    if (username && email && password && roles_id && active) {
        //email_check
        console.log(email);
        await user_services.GetbyEmailCheck(email)
            .then(user_data => {
                if (user_data.length != 0) {
                    if (user_data[0].is_verified == 0) {
                        data = {
                            OTP: otp,
                            updated_at: date(),
                        };

                    } else {
                        msg = "Email already exists";
                        return res.status(400).json(failure_func(msg))
                    }
                } else {
                    // p_check = validate_password(password);
                    // if (p_check == false) {
                    //     msg = 'The password must contain at least 8 characters including at least 1 uppercase, 1 lowercase, one number and one special character.'
                    //     return res.status(500).json(failure_func(msg))
                    // }
                    const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
                    datas = {
                        username: username,
                        email: email,
                        password: hashed_password,
                        mobile: mobile,
                        roles_id: roles_id,
                        active: active,
                        OTP: otp,
                        created_by: created_by,
                        updated_by: updated_by,
                        is_verified: 1
                    };


                    if (profile_image) {
                        datas.profile_image = profile_image.name;
                        buffer = profile_image.data
                        path = './media/' + profile_image.name;
                        fs.writeFile(path.toString(), buffer, function (err) {
                            if (err) {
                                return console.log(err);
                            }
                        });

                    }

                    //inserting into db
                    user_services.CreateUser(datas)
                        .then(user => {
                            if (user.errors) {
                                msg = user.errors[0].message;
                                res.status(500).json(failure_func(msg))
                            } else {
                                const userdata = user.dataValues;
                                const userid = userdata.id;


                                if (notification_ids && Array.isArray(notification_ids) && notification_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
                                    // notification_ids = JSON.parse(notification_ids);
                                    console.log(notification_ids);
                                    for (const i of notification_ids) {
                                        const nt_data = {
                                            notification_id: i,
                                            user_id: userid,
                                            active: true,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        notification_mapping_services.CreateNotificationMapping(nt_data)
                                            .then(notify_map => {
                                                if (notify_map.errors) {
                                                    console.log(notify_map.errors);
                                                } else {
                                                    console.log('notification_mapping created for user : ' + userid);
                                                }
                                            })
                                            .catch(err => {
                                                res.status(500).json(failure_func(err))
                                            })
                                    }
                                }

                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_users');
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(500).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "Please fill all the fields";
        res.status(500).json(failure_func(msg))
    }
}
// const NewUser = async (req, res, next) => {
//     email = req.body.email;
//     username = req.body.username;
//     password = req.body.password;
//     mobile = req.body.mobile;
//     try {
//         profile_image = req.files.profile_image;
//     } catch {
//         profile_image = null
//     }
//     roles_id = req.body.roles_id;
//     active = req.body.active;
//     try {
//         otp = generate_otp();
//     } catch {
//         otp = "2323"
//     }
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     notification_ids = req.body.notification_ids;
//     if (username && email && password && roles_id && active) {
//         //email_check
//         await user_services.GetbyEmail(email)
//             .then(user_data => {
//                 if (user_data.length != 0) {
//                     if (user_data[0].is_verified == 0) {
//                         data = {
//                             OTP: otp,
//                             updated_at: date(),
//                         };
//                         user_services.UpdateUser(user_data[0].id, data)
//                             .then(user => {
//                                 if (user == 1) {
//                                     //sending mobile otp
//                                     send_otp(user_data[0].mobile, otp);
//                                     //adding email to queue
//                                     var mailOptions = {
//                                         from: process.env.EMAIL_HOST_USER,
//                                         to: email,
//                                         subject: 'Sending OTP Email using Node.js',
//                                         text: 'Verify your OTP : ' + otp,
//                                     };
//                                     add_to_queue(mailOptions);
//                                     msg = "Pending OTP verification";
//                                     return res.status(200).json(success_func(msg))
//                                 } else {
//                                     msg = "Coudn't verify OTP";
//                                     return res.status(200).json(success_func(msg))
//                                 }
//                             })
//                     } else {
//                         msg = "Email already exists";
//                         return res.status(500).json(failure_func(msg))
//                     }
//                 } else {
//                     p_check = validate_password(password);
//                     if (p_check == false) {
//                         msg = 'The password must contain at least 8 characters including at least 1 uppercase, 1 lowercase, one number and one special character.'
//                         return res.status(500).json(failure_func(msg))
//                     }
//                     const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
//                     data = {
//                         username: username,
//                         email: email,
//                         password: hashed_password,
//                         mobile: mobile,
//                         roles_id: roles_id,
//                         active: active,
//                         OTP: otp,
//                         created_by: created_by,
//                         updated_by: updated_by
//                     };
//                     if (profile_image && profile_image.length != null) {
//                         data.profile_image = profile_image.name;
//                         buffer = profile_image.data
//                         path = './media/' + profile_image.name;
//                         fs.writeFile(path.toString(), buffer, function (err) {
//                             if (err) {
//                                 return console.log(err);
//                             }
//                         });
//                     }
//                     //inserting into db
//                     user_services.CreateUser(data)
//                         .then(user => {
//                             if (user.errors) {
//                                 msg = user.errors[0].message;
//                                 res.status(500).json(failure_func(msg))
//                             } else {
//                                 userdata = user.dataValues;
//                                 userid = userdata.id;
//                                 if (notification_ids & notification_ids.length != 0) {
//                                     notification_ids = JSON.parse(notification_ids);
//                                     for (i of notification_ids) {
//                                         nt_data = {
//                                             notification_id: i,
//                                             user_id: userid,
//                                             active: true,
//                                             created_by: created_by,
//                                             updated_by: updated_by 
//                                         }
//                                         notification_mapping_services.CreateNotificationMapping(nt_data)
//                                             .then(notify_map => {
//                                                 if (notify_map.errors) {
//                                                     console.log(notify_map.errors);
//                                                 } else {
//                                                     console.log('notification_mapping created for user : ' + userid);
//                                                 }
//                                             })
//                                             .catch(err => {
//                                                 res.status(500).json(failure_func(err))
//                                             })
//                                     }
//                                 }
//                                 //sending mobile otp
//                                 send_otp(mobile, otp);
//                                 //adding email to queue
//                                 var mailOptions = {
//                                     from: process.env.EMAIL_HOST_USER,
//                                     to: email,
//                                     subject: 'Sending OTP Email using Node.js',
//                                     text: 'Verify your OTP : ' + otp,
//                                 };
//                                 add_to_queue(mailOptions);
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_users');
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(500).json(failure_func(err))
//                         })
//                 }
//             })
//     } else {
//         msg = "Please fill all the fields";
//         res.status(500).json(failure_func(msg))
//     }
// }

const otp_verification = async (req, res, next) => {
    email = req.body.email;
    otp = req.body.otp;
    if (email && otp) {
        await user_services.GetbyEmail(email)
            .then(user_data => {
                if (user_data.length != 0) {
                    user_otp = user_data[0].OTP;
                    if (user_otp == otp) {
                        data = { is_verified: true, updated_by: user_data[0].id, updated_at: date() }
                        user_services.UpdateUser(user_data[0].id, data)
                            .then(user => {
                                if (user == 1) {
                                    msg = "OTP Verified";
                                    cache.DEL(req.user.id + '_users');
                                    return res.status(200).json(success_func(msg))
                                } else {
                                    msg = "Coudn't verify OTP";
                                    return res.status(200).json(success_func(msg))
                                }
                            })
                    } else {
                        msg = "Invalid OTP";
                        return res.status(500).json(success_func(msg))
                    }
                } else {
                    msg = "User does not exist";
                    return res.status(500).json(failure_func(msg))
                }
            }
            )
    } else {
        msg = "email and otp is required";
        return res.status(500).json(failure_func(msg))
    }
}

const UpdateUser = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        email = req.body.email;
        username = req.body.username;
        // password = req.body.password;
        mobile = req.body.mobile;
        created_by = req.user.id;
        updated_by = req.user.id;
        notification_ids = req.body.notification_ids.split(",");
        roles_id = req.body.roles_id;
        active = req.body.active;
        otp = 1;


        try {
            profile_image = req.files.profile_image;
        } catch {
            profile_image = null
        }
        updated_at = date();

        if (username && email && roles_id && active) {
            //email_check
            await user_services.GetbyId(id)
                .then(user_data => {
                    if (user_data.length != 0) {

                        datas = {
                            username: username,
                            email: email,
                            mobile: mobile,
                            roles_id: roles_id,
                            active: active,
                            updated_by: updated_by,
                            updated_at: updated_at,
                        };
                        // if (password && password.length != 0) {
                        //     p_check = validate_password(password);
                        //     if (p_check == false) {
                        //         msg = 'The password must contain at least 8 characters including at least 1 uppercase, 1 lowercase, one number and one special character.'
                        //         res.status(500).json(failure_func(msg))
                        //     }
                        //     const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
                        //     datas.password = hashed_password;
                        // }
                        if (profile_image) {
                            datas.profile_image = profile_image.name;
                            buffer = profile_image.data
                            path = './media/' + profile_image.name;
                            fs.writeFile(path.toString(), buffer, function (err) {
                                if (err) {
                                    return console.log(err);
                                }
                            });
                        }
                        //updating db
                        user_services.UpdateUser(id, datas)
                            .then(user => {
                                if (user == 1) {
                                    if (notification_ids && Array.isArray(notification_ids) && notification_ids.length > 0) {
                                        notification_mapping_services.GetbyUserid(id)
                                            .then(nt_data => {
                                                if (nt_data.length != 0) {
                                                    for (nt of nt_data) {
                                                        notification_mapping_services.DestroyNotificationMapping(nt.id)
                                                    }
                                                }
                                            })

                                        for (const i of notification_ids) {
                                            const nt_data = {
                                                notification_id: i,
                                                user_id: id,
                                                active: true,
                                                created_by: req.user.id,
                                                updated_by: req.user.id
                                            }
                                            notification_mapping_services.CreateNotificationMapping(nt_data)
                                                .then(notify_map => {
                                                    if (notify_map.errors) {
                                                        console.log(notify_map.errors);
                                                    } else {
                                                        console.log('notification_mapping created for user : ' + id);
                                                    }
                                                })
                                        }
                                    }
                                    msg = "Updated Successfully"
                                    cache.DEL(req.user.id + '_users');
                                    res.status(200).json(success_func(msg))
                                } else {
                                    msg = "ID doesn't exists"
                                    res.status(500).json(failure_func(msg))
                                }
                            }
                            )
                            .catch(err => {
                                res.status(500).json(failure_func(err))
                            })

                    }
                })
        } else {
            msg = "Please fill all the fields";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

// const UpdateUser = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         username = req.body.username;
//         email = req.body.email;
//         password = req.body.password;
//         mobile = req.body.mobile;
//         try {
//             profile_image = req.files.profile_image;
//         } catch {
//             profile_image = null
//         }
//         roles_id = req.body.roles_id;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         notification_ids = req.body.notification_ids;
//         if (username && email && roles_id && active) {
//             //email_check
//             await user_services.GetbyId(id)
//                 .then(user_data => {
//                     if (user_data.length != 0) {
//                         if (user_data[0].email != email) {
//                             msg = "Email already exists";
//                             res.status(500).json(failure_func(msg))
//                         } else {
//                             data = {
//                                 username: username,
//                                 email: email,
//                                 mobile: mobile,
//                                 roles_id: roles_id,
//                                 active: active,
//                                 updated_by: updated_by,
//                                 updated_at: updated_at,
//                             };
//                             if (password && password.length != 0) {
//                                 p_check = validate_password(password);
//                                 if (p_check == false) {
//                                     msg = 'The password must contain at least 8 characters including at least 1 uppercase, 1 lowercase, one number and one special character.'
//                                     res.status(500).json(failure_func(msg))
//                                 }
//                                 const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
//                                 data.password = hashed_password;
//                             }
//                             if (profile_image) {
//                                 data.profile_image = profile_image.name;
//                                 buffer = profile_image.data
//                                 path = './media/' + profile_image.name;
//                                 fs.writeFile(path.toString(), buffer, function (err) {
//                                     if (err) {
//                                         return console.log(err);
//                                     }
//                                 });
//                             }
//                             //updating db
//                             user_services.UpdateUser(id, data)
//                                 .then(user => {
//                                     if (user == 1) {
//                                         if (notification_ids && notification_ids.length != 0) {
//                                             notification_mapping_services.GetbyUserid(id)
//                                                 .then(nt_data => {
//                                                     if (nt_data.length != 0) {
//                                                         for (nt of nt_data) {
//                                                             notification_mapping_services.DestroyNotificationMapping(nt.id)
//                                                         }
//                                                     }
//                                                 })
//                                             notification_ids = JSON.parse(notification_ids);
//                                             for (i of notification_ids) {
//                                                 nt_data = {
//                                                     notification_id: i,
//                                                     user_id: id,
//                                                     active: true,
//                                                     created_by: req.user.id,
//                                                     updated_by: req.user.id
//                                                 }
//                                                 notification_mapping_services.CreateNotificationMapping(nt_data)
//                                                     .then(notify_map => {
//                                                         if (notify_map.errors) {
//                                                             console.log(notify_map.errors);
//                                                         } else {
//                                                             console.log('notification_mapping created for user : ' + id);
//                                                         }
//                                                     })
//                                             }
//                                         }
//                                         msg = "Updated Successfully"
//                                         cache.DEL(req.user.id + '_users');
//                                         res.status(200).json(success_func(msg))
//                                     } else {
//                                         msg = "ID doesn't exists"
//                                         res.status(500).json(failure_func(msg))
//                                     }
//                                 }
//                                 )
//                                 .catch(err => {
//                                     res.status(500).json(failure_func(err))
//                                 })
//                         }
//                     }
//                 })
//         } else {
//             msg = "Please fill all the fields";
//             res.status(500).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(500).json(failure_func(msg))
//     }
// }

const DeleteUser = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await notification_mapping_services.GetbyUserid(id)
            .then(nt_data => {
                if (nt_data.length != 0) {
                    for (nt of nt_data) {
                        notification_mapping_services.DestroyNotificationMapping(nt.id)
                    }
                }
            })
        await user_services.DestroyUser(id)
            .then(user => {
                if (user == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_users');
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

// function validate_password(password) {
//     if (!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password))) {
//         return false;
//     } else {
//         return true;
//     }
// }

module.exports = {
    NewUser,
    FetchUsers,
    UpdateUser,
    DeleteUser,
    otp_verification
}