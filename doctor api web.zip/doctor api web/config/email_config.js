var nodemailer = require('nodemailer');
require('dotenv').config();

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_HOST_USER,
    pass: process.env.EMAIL_HOST_PASSWORD
  }
});

// var mailOptions = {
//   from: 'viswakrishna2001@gmail.com',
//   to: 'viswakrishna2001@gmail.com',
//   subject: 'Sending Email using Node.js',
//   text: 'That was easy! viswa'
// };

// transporter.sendMail(mailOptions, function(error, info){
//   if (error) {
//     console.log(error);
//   } else {
//     console.log('Email sent: ' + info.response);
//   }
// });

module.exports = transporter;