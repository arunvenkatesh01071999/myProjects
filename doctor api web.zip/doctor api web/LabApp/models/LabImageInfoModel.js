// const sequelize = require('../../config/db1');
// const { Sequelize, DataTypes } = require("sequelize");
// const LabInfo = require('../models/LabBasicInfoModel');
// const logger = require('../../config/activity_logger');

// const LabImage = sequelize.define("l_lab_image", {
//     lab_name_id: {
//         type: DataTypes.INTEGER,
//         allowNull: true
//     },
//     lab_image: {
//         type: DataTypes.STRING,
//         allowNull: true
//     },
//     active: {
//         type: DataTypes.INTEGER,
//         allowNull: true
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: true,
//     },
//     updated_at: {
//         type: DataTypes.STRING,
//         allowNull: true,
//     },
//     created_by: {
//         type: DataTypes.INTEGER,
//         allowNull: true,
//     },
//     updated_by: {
//         type: DataTypes.INTEGER,
//         allowNull: true,
//     }
// }, { freezeTableName: true });

// LabImage.addHook('afterUpdate', (data, options) => {
//     resp = JSON.stringify({
//         action: 'create',
//         table_name: 'l_lab_image',
//         record_id: data.id,
//         old_value: JSON.stringify(data._previousDataValues),
//         new_value: JSON.stringify(data)
//     });
//     logger.info(resp)
// });

// LabImage.addHook('afterDestroy', (data, options) => {
//     resp = JSON.stringify({
//         action: 'delete',
//         table_name: 'l_lab_image',
//         record_id: data.id,
//         old_value: JSON.stringify(data),
//         new_value: '',
//     });
//     logger.info(resp)
// });


// module.exports = LabImage;

const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const LabInfo = require('../models/LabBasicInfoModel');
const logger = require('../../config/activity_logger');

const LabImage = sequelize.define("l_lab_image", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    lab_image: {
        type: DataTypes.STRING,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

LabImage.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_image',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabImage.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_image',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = LabImage;