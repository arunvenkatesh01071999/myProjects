const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabInfo = require('../../LabApp/models/LabBasicInfoModel');
// const LabMaster = require('../../MastersApp/models/LabTestCategoryModel');
const LabTestMaster = require('../../MastersApp/models/LabTestModel');



const LabTestPack = sequelize.define("l_lab_test_pack", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    lab_pack_name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    cost: {
        type: DataTypes.STRING,
        allowNull: true
    },
    offer_percent: {
        type: DataTypes.STRING,
        allowNull: true
    },
    vaild_from: {
        type: DataTypes.DATE,
        allowNull: true
    },
    vaild_to: {
        type: DataTypes.DATE,
        allowNull: true
    },
    apply_promo: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    lab_test_id: {
        type: DataTypes.STRING,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

LabTestPack.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });
// LabTestPack.belongsTo(LabTestMaster, { foreignKey: 'lab_test_id' });


LabTestPack.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_test_pack',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabTestPack.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_test_pack',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = LabTestPack;