const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const speciality = require('../../MastersApp/models/SpecialitiesModel');
const LabBasicInfo = require('./LabBasicInfoModel');
const gender = require('../../MastersApp/models/GenderModel');

const LabInChargeInfo = sequelize.define("l_lab_incharge_info", {
    doctor_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    gender_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone_no: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    dob: {
        type: DataTypes.DATE,
        allowNull: true
    },
    age: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    about: {
        type: DataTypes.STRING,
        allowNull: true
    },
    speciality_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    image_path: {
        type: DataTypes.STRING,
        allowNull: true
    },
    signature_path: {
        type: DataTypes.STRING,
        allowNull: false
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

LabInChargeInfo.belongsTo(speciality, { foreignKey: 'speciality_id' });
LabInChargeInfo.belongsTo(gender , {foreignKey : 'gender_id'});
LabInChargeInfo.belongsTo(LabBasicInfo , {foreignKey : 'lab_name_id'});


LabInChargeInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_incharge_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabInChargeInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_incharge_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = LabInChargeInfo;