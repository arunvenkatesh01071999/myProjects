const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const LabInfo = require('./LabBasicInfoModel');
const labModel = require('../../MastersApp/models/LabTestCategoryModel');
const logger = require('../../config/activity_logger');
const LabTestMaster = require('../../MastersApp/models/LabTestModel');


const LabCategory = sequelize.define("l_lab_info", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    lab_test_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    discount:{
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

// LabCategory.belongsTo(labModel, { foreignKey: 'lab_category_id' });
// LabCategory.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });
LabCategory.belongsTo(LabTestMaster, { foreignKey: 'lab_test_id' });



LabCategory.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabCategory.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = LabCategory;