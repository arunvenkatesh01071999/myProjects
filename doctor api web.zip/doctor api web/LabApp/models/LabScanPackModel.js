const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabInfo = require('../../LabApp/models/LabBasicInfoModel');
const ScanMaster = require('../../MastersApp/models/ScanTestMasterModel');


const ScanTestPack = sequelize.define("l_scan_test_pack", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    scan_pack_name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    cost: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    offer_percent: {
        type: DataTypes.STRING,
        allowNull: true
    },
    vaild_from: {
        type: DataTypes.DATE,
        allowNull: true
    },
    vaild_to: {
        type: DataTypes.DATE,
        allowNull: true
    },
    apply_promo: {
        type: DataTypes.STRING,
        allowNull: true
    },
    scan_name_id: {
        type: DataTypes.STRING,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

ScanTestPack.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });
ScanTestPack.belongsTo(ScanMaster, { foreignKey: 'scan_name_id' });


ScanTestPack.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_scan_test_pack',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ScanTestPack.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_scan_test_pack',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = ScanTestPack;