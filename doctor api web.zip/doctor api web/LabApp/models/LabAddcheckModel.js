const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');


const LabBasicInfo = sequelize.define("l_lab_basic_infos", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    }, addCheck: {
        type: DataTypes.INTEGER,
        allowNull: true
    }
}, { freezeTableName: true });


module.exports = LabBasicInfo;