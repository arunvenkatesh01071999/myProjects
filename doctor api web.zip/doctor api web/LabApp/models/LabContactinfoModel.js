const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabInfo = require('../models/LabBasicInfoModel');

const Contactinfo = sequelize.define("l_contact_info", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    telephone: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    mobile_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    emergency_no: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    toll_free_no: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    helpline_no: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    fax_no: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    webiste_URL: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email_address_1: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email_address_2: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    established_in: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
}, { freezeTableName: true });

Contactinfo.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });

Contactinfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_contact_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

Contactinfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_contact_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = Contactinfo;