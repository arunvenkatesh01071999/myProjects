const express = require('express');
const router = express();
const verify_token = require('../../services/verify_token');

const lab_info_pass_control = require('../controller/LabAddCheckController');

router.post('/adding', verify_token, lab_info_pass_control.newAdd);

module.exports = router;