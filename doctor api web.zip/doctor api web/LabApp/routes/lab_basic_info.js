const express = require('express');
const router = express();
const LabBasicInfoController = require('../../LabApp/controller/LabBasicInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabBasicInfoController.FetchLabBasicInfo);
router.get('/:lab_name_id', verify_token, LabBasicInfoController.FetchLabBasicInfo);
router.post('/', verify_token, LabBasicInfoController.NewLabBasicInfo);
router.put('/:id', verify_token, LabBasicInfoController.UpdateLabBasicInfo);
router.put('/approve/:id', verify_token, LabBasicInfoController.LabApprove);
router.put('/approve/update/:id', verify_token, LabBasicInfoController.updateIsapprove);

module.exports = router; 