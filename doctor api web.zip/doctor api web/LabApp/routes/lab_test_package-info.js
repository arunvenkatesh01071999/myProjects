const express = require('express');
const router = express();
const LabTestPackController = require('../../LabApp/controller/LabTestPackageController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabTestPackController.FetchLabTestInfo);
router.get('/:lab_name_id', verify_token, LabTestPackController.FetchLabTestInfo);
router.post('/', verify_token, LabTestPackController.NewLabTestInfo);
router.put('/:lab_name_id', verify_token, LabTestPackController.UpdateLabTestInfo);
router.delete('/:id/:lab_name_id', verify_token, LabTestPackController.DeleteLabTestInfo);


module.exports = router; 