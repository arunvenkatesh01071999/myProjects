const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_info_pass_services = require('../services/lab_addcheck_service');

const AddCheck = require('../../services/lab_addCheck_service');

const newAdd = async (req, res, next) => {

    const query = AddCheck(req.body.lab_name_id)

    msg = "Created Successfully";
    res.status(200).json(success_func(msg))

}

module.exports = {
    newAdd
}