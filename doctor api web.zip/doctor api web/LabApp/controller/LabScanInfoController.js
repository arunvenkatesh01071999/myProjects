const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const scan_service = require('../services/lab_scan_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/lab_addCheck_service');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const FetchScanInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await scan_service.GetbyId(lab_name_id)
            .then(data => {
                // console.log(data.length, "datasdfghjk");
                res.status(200).json(success_func(data))
                // console.log(data,"Data Length Evlo Solunga")
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        await scan_service.Get()
            .then(data => {
                //cache.SET(req.user.id + '_lab_scan_info_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}

//create lap scan info

const NewScanInfo = async (req, res, next) => {
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const { lab_name_id, pack_name, scan_name_id, cost, discount, active } = req.body;

    query = `SELECT COUNT(*) AS count FROM l_lab_scan_info WHERE lab_name_id = ${lab_name_id}`;
    const result_data = await db1.query(query);
    const t = result_data.flat();
    const check = t[0].count;
    if (check === 0) {
        const query = AddCheck(req.body.lab_name_id)
    }
    // const stringScanNameId = scan_name_id.join(',');

    const l_data = {
        lab_name_id: parseInt(lab_name_id),
        pack_name: pack_name,
        scan_name_id: scan_name_id,
        cost: cost,
        discount: discount,
        active: parseInt(active),
        created_by: created_by,
        updated_by: updated_by
    }
    await scan_service.GetbyNameId(scan_name_id, lab_name_id)
        .then(n_data => {
            if (n_data.length > 0) {
                msg = " Scan Name already exists";
                return res.status(200).json(failure_func(msg))
            } else {
                scan_service.CreateScanService(l_data)
                    .then(data => {
                        if (data.errors) {
                            msg = data.errors[0].message;
                            res.status(400).json(failure_func(msg))
                        } else {
                            msg = "Created Successfully"
                            cache.DEL(req.user.id + '_scan_service')
                            res.status(200).json(success_func(msg))
                        }
                    })
                    .catch(err => {
                        res.status(400).json(failure_func(err))
                    })
            }
        })
}
// await scan_service.CreateScanService(l_data)
// .then(data => {
//     if (data.err) {
//         msg = data.err[0].message;

//     } else {
//         msg = "Created Successfully";
//         res.status(200).json(success_func(msg))
//     }
// })
// .catch(err => {
//     res.status(400).json(failure_func(err))
// })

const UpdateScanInfo = async (req, res, next) => {

    lab_name_id = req.params.lab_name_id

    if (lab_name_id) {

        const { pack_name, scan_name_id, cost, discount, active } = req.body;
        const created_by = req.user.id;
        const updated_by = req.user.id;

        // const stringScanNameId = scan_name_id.join(',');

        const l_data = {
            lab_name_id: lab_name_id,
            pack_name: pack_name,
            scan_name_id: scan_name_id,
            cost: cost,
            discount: discount,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }


        await scan_service.UpdateScanService(lab_name_id, l_data)
            .then(data => {
                if (data == 1) {
                    msg = "updated successfully"
                    //cache.DEL(req.user.id + '_scan_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(400).json(failure_func(msg));
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })

    }
    // else {
    //     msg = "ID is required";
    //     res.status(400).json(failure_func(msg))
    // }
}

const DeleteScanInfo = async (req, res, next) => {
    id = req.params.id;
    lab_name_id = req.params.lab_name_id;
    // console.log(req.params.id, 'Enna values?')
    if (id) {
        const dl = await scan_service.DestroyScanService(id)
        // .then(data => {
        if (dl == 1) {
            // console.log('id',id);
            query = `SELECT COUNT(*) AS count FROM l_lab_scan_info WHERE lab_name_id = ${lab_name_id}`;
            const result_data = await db1.query(query);
            const t = result_data.flat();
            const check = t[0].count;
            if (check === 0) {
                const addCheck = 8;
                const query2 = `select addCheck from l_lab_basic_infos where id =${lab_name_id}`;
                var customerFeedback = await db1.query(query2);
                var menu_data = customerFeedback.flat();
                total_add = menu_data[0].addCheck - addCheck;
                const query1 = `UPDATE l_lab_basic_infos SET addCheck = ${total_add} where id =${lab_name_id}`
                var customerFeedback1 = db1.query(query1);
            }

            msg = "Deleted successfully"
            // // cache.DEL(req.user.id + '_scan_service')
            res.status(200).json(success_func(msg))
            // } else {
            //     msg = "ID doesn't exist"
            //     res.status(400).json(failure_func(msg))
        }
        // })
        // .catch(err => {
        //     res.status(400).json(failure_func(err))
        // })
    }
    else {
        msg = "Unsuccessfully to delete";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewScanInfo,
    FetchScanInfo,
    UpdateScanInfo,
    DeleteScanInfo
}