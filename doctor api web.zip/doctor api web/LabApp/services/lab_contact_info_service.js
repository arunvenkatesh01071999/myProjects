const ContactInfo = require('../models/LabContactinfoModel');
const LabInfo = require('../models/LabBasicInfoModel');

const Get = async () => {
    await ContactInfo.findAll({ include :[LabInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (lab_name_id) => {
    await ContactInfo.findAll({where: { lab_name_id: lab_name_id }, include :[LabInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const CreateContact = async (l_data) => {
    await ContactInfo.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateContact = async (id, l_data) => {
    await ContactInfo.update(l_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyContact = async (id) => {
    await ContactInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    CreateContact,
    UpdateContact,
    DestroyContact
};