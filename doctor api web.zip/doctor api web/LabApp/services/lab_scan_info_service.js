const LabScanInfo = require('../models/LabScanInfoModel');
const ScanInfo = require('../../MastersApp/models/ScanTestMasterModel');
// const LabInfo = require('../models/LabBasicInfoModel');

const Get = async () => {
    await LabScanInfo.findAll({include :[ScanInfo]})
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (lab_name_id) => {
    await LabScanInfo.findAll({where: { lab_name_id: lab_name_id }, include :[ScanInfo]})
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyNameId = async (scan_name_id,lab_name_id) => {
    await LabScanInfo.findAll({ where: { scan_name_id: scan_name_id,lab_name_id:lab_name_id }})
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateScanService = async (l_data) => {
    await LabScanInfo.create(l_data)
        .then(data => {
            res = data
            // console.log(res);
        }).catch(err => {
            res = err
        })
    return res;
};

const UpdateScanService = async (lab_name_id, l_data) => {
    await LabScanInfo.update(l_data, { where: { lab_name_id: lab_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyScanService = async (id) => {
    await LabScanInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    CreateScanService,
    UpdateScanService,
    DestroyScanService,
    GetbyNameId
};