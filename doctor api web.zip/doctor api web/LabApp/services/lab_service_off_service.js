const OfferInfo = require('../models/LabOfferServiceModel');
const labInfo = require('../models/LabBasicInfoModel');

const Get = async () => {
    await OfferInfo.findAll({ include: [labInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (lab_name_id) => {
    await OfferInfo.findAll({ where: { lab_name_id: lab_name_id }, include: [labInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await OfferInfo.findAll({ where: { lab_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateOfferInfo = async (off_data) => {
    await OfferInfo.create(off_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateOfferInfo = async (lab_name_id, off_data) => {
    await OfferInfo.update(off_data, { where: { lab_name_id: lab_name_id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyOfferInfo = async (lab_name_id) => {
    await OfferInfo.destroy({ where: { lab_name_id:lab_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateOfferInfo,
    UpdateOfferInfo,
    DestroyOfferInfo
};
