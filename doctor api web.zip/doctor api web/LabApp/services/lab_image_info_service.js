const LabImgInfo = require('../models/LabImageInfoModel');

const CreateLablmgBasicInfo = async (l_data) => {
    await LabImgInfo.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryLabImgBasicInfo = async (lab_id) => {
    await LabImgInfo.destroy({ where: { lab_name_id: lab_id }, raw: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CheckLabImgBasicInfo = async (lab_id) => {
    await LabImgInfo.findAll({ where: { lab_name_id: lab_id }, raw: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyLabImages = async (lab_id) => {
    await LabImgInfo.findAll({ where: { lab_name_id: lab_id }, raw: true })
    // const query = `select hospital_image from h_hospital_image where hospital_name_id = ${hosp_id}`
    // await db1.query(query, { type: Sequelize.QueryTypes })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const DestroyLabImages = async (image) => {
    await LabImgInfo.destroy({ where: {lab_image: image } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err

        })

    return res
}
module.exports = {
    CreateLablmgBasicInfo,
    DestoryLabImgBasicInfo,
    CheckLabImgBasicInfo,
    DestroyLabImages,
    GetbyLabImages
    
};