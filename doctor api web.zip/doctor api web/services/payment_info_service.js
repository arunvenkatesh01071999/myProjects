const DoctorPaymentInfo = require('../DoctorApp/models/PaymentInfoModel');
const HospitalPaymentInfo = require('../HospitalApp/models/HospitalPaymentinfoModel');

const CreatePaymentInfo = async (so_data) => {
    if (so_data.name == 'Doctor') {
        if (so_data.check == 0) {
            payment_data = {
                fees_type_id: so_data.fees_type_id,
                fees_amt: so_data.fees_amt,
                commision: so_data.commision,
                check: so_data.check,
                active: so_data.active,
                N_display_amt: so_data.N_display_amt,
                N_commision: so_data.N_commision,
                N_payout: so_data.N_payout,
                s_display_amt: 0,
                s_commision: 0,
                s_payout: 0,
                doctor_name_id: so_data.doctor_name_id,
                created_by: so_data.created_by,
                updated_by: so_data.updated_by
            }

        }
        else {
            payment_data = {
                fees_type_id: so_data.fees_type_id,
                fees_amt: so_data.fees_amt,
                commision: so_data.commision,
                check: so_data.check,
                active: so_data.active,
                N_display_amt: 0,
                N_commision: 0,
                N_payout: 0,
                s_display_amt: so_data.s_display_amt,
                s_commision: so_data.s_commision,
                s_payout: so_data.s_payout,
                doctor_name_id: so_data.doctor_name_id,
                created_by: so_data.created_by,
                updated_by: so_data.updated_by
            }
        }
        // console.log('payment_data',payment_data);
        await DoctorPaymentInfo.create(payment_data)
            .then(data => {
                res = data.dataValues
            }).catch(err => {
                res = err
            })
        return res

    }
    if (so_data.name == 'Hospital') {

        if (so_data.check == 0) {
            payment_data = {
                fees_type_id: so_data.fees_type_id,
                fees_amt: so_data.fees_amt,
                commision: so_data.commision,
                check: so_data.check,
                active: so_data.active,
                N_display_amt: so_data.N_display_amt,
                N_commision: so_data.N_commision,
                N_payout: so_data.N_payout,
                s_display_amt: 0,
                s_commision: 0,
                s_payout: 0,
                hospital_name_id: so_data.hospital_name_id,
                created_by: so_data.created_by,
                updated_by: so_data.updated_by
            }

        }
        else {
            payment_data = {
                fees_type_id: so_data.fees_type_id,
                fees_amt: so_data.fees_amt,
                commision: so_data.commision,
                check: so_data.check,
                active: so_data.active,
                N_display_amt: 0,
                N_commision: 0,
                N_payout: 0,
                s_display_amt: so_data.s_display_amt,
                s_commision: so_data.s_commision,
                s_payout: so_data.s_payout,
                hospital_name_id: so_data.hospital_name_id,
                created_by: so_data.created_by,
                updated_by: so_data.updated_by
            }
        }
        await HospitalPaymentInfo.create(payment_data)
            .then(data => {
                res = data.dataValues
            }).catch(err => {
                res = err
            })
        return res
    }
};

module.exports = {
    CreatePaymentInfo
}