const cache = require('../config/redis_cache');
require('dotenv').config();


const SET = async (key, data) => {
    await cache.set(process.env.APPNAME + '_' + key, JSON.stringify(data), { EX: process.env.CACHE_EXPIRATION_TIME })
}

const GET = async (key) => {
    return await cache.get(process.env.APPNAME + '_' + key)
}

const DEL = async (key) => {
    await cache.del(process.env.APPNAME + '_' + key)
}


module.exports = {
    SET,
    GET,
    DEL
}