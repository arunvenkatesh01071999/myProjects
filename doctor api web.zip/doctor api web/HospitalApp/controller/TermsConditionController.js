const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const terms_condition_service = require('../services/terms_codition_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');

const FetchTermCondition = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await terms_condition_service.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_terms_condition_service');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await terms_condition_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_terms_condition_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewTermCondition = async (req, res, next) => {
    const hospital_name_id = req.body.hospital_name_id;
    const terms = req.body.terms;
    const condition = req.body.condition;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id);

    if (terms) {
        const tc_data = {
            hospital_name_id: hospital_name_id,
            terms: terms,
            condition: condition,
            addCheck: addCheck,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        console.log(tc_data)
        await terms_condition_service.GetId(hospital_name_id)
            .then(data => {
                if (data.length > 0) {
                    msg = "Hospital Address Already Exist";
                    return res.status(200).json(failure_func(msg))
                } else {
                    terms_condition_service.CreateTermCondition(tc_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                terms_condition_service.GetId(hospital_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_terms_condition_service')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "terms and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateTermCondition = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const hospital_name_id = req.body.hospital_name_id;
        const terms = req.body.terms;
        const condition = req.body.condition;
        const active = req.body.active;
        const updated_by = req.user.id;
        const updated_at = date();
        if (terms) {
            const tc_data = {
                hospital_name_id: hospital_name_id,
                terms: terms,
                condition: condition,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await terms_condition_service.UpdateTermsInfo(id, tc_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_infrastructure_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "No Of Doctor is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteTermCondition = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await terms_condition_service.DestroySpecialityInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_terms_condition_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewTermCondition,
    FetchTermCondition,
    UpdateTermCondition,
    DeleteTermCondition
}