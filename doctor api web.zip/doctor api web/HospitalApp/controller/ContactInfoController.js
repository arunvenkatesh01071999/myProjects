const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const contactInfo_services = require('../services/contact_info_sercice');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');

const FetchContactInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await contactInfo_services.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_contactInfo_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await contactInfo_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_contactInfo_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };

const NewContactInfo = async (req, res, next) => {
    hospital_name_id = req.body.hospital_name_id;
    telephone_no = req.body.telephone_no;
    mobile_no = req.body.mobile_no;
    emergency_no =req.body.emergency_no ?  req.body.emergency_no :"";
    toll_free_no = req.body.toll_free_no ? req.body.toll_free_no : "";
    helpline_no = req.body.helpline_no ? req.body.helpline_no : "";
    fax_no = req.body.fax_no ? req.body.fax_no : "";
    ambulance_no = req.body.ambulance_no ? req.body.ambulance_no : "";
    blood_bank_no = req.body.blood_bank_no ? req.body.blood_bank_no : "";
    foreign_international_wing = req.body.foreign_international_wing ? req.body.foreign_international_wing : "";
    webiste_URL = req.body.webiste_URL ? req.body.webiste_URL : "";
    email_address_1 = req.body.email_address_1;
    email_address_2 = req.body.email_address_2 ? req.body.email_address_2 : "";
    established_in = req.body.established_in ? req.body.established_in : "";
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id)


    if (mobile_no) {
        c_data = {
            hospital_name_id: parseInt(hospital_name_id),
            telephone_no: telephone_no,
            mobile_no: mobile_no,
            emergency_no: emergency_no,
            toll_free_no: toll_free_no,
            helpline_no: helpline_no,
            fax_no: fax_no,
            ambulance_no: ambulance_no,
            blood_bank_no: blood_bank_no,
            foreign_international_wing: foreign_international_wing,
            webiste_URL: webiste_URL,
            email_address_1: email_address_1,
            email_address_2: email_address_2,
            established_in: established_in,
            addCheck: addCheck,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };
        console.log(c_data);
        await contactInfo_services.GetId(hospital_name_id)
            .then(data => {
                if (data.length > 0) {
                    msg = "Hospital Address Already Exist";
                    return res.status(200).json(failure_func(msg))
                } else {
                    contactInfo_services.CreateContact(c_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                contactInfo_services.GetId(hospital_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_contactInfo_services')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "Mobile Number is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateContactInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        hospital_name_id = req.body.hospital_name_id;
        telephone_no = req.body.telephone_no;
        mobile_no = req.body.mobile_no;
        emergency_no =req.body.emergency_no ?  req.body.emergency_no :"";
        toll_free_no = req.body.toll_free_no ? req.body.toll_free_no : "";
        helpline_no = req.body.helpline_no ? req.body.helpline_no : "";
        fax_no = req.body.fax_no ? req.body.fax_no : "";
        ambulance_no = req.body.ambulance_no ? req.body.ambulance_no : "";
        blood_bank_no = req.body.blood_bank_no ? req.body.blood_bank_no : "";
        foreign_international_wing = req.body.foreign_international_wing ? req.body.foreign_international_wing : "";
        webiste_URL = req.body.webiste_URL ? req.body.webiste_URL : "";
        email_address_1 = req.body.email_address_1;
        email_address_2 = req.body.email_address_2 ? req.body.email_address_2 : "";
        established_in = req.body.established_in ? req.body.established_in : "";
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (mobile_no) {
            c_data = {
                hospital_name_id: hospital_name_id,
                telephone_no: telephone_no,
                mobile_no: mobile_no,
                emergency_no: emergency_no,
                toll_free_no: toll_free_no,
                helpline_no: helpline_no,
                fax_no: fax_no,
                ambulance_no: ambulance_no,
                blood_bank_no: blood_bank_no,
                foreign_international_wing: foreign_international_wing,
                webiste_URL: webiste_URL,
                email_address_1: email_address_1,
                email_address_2: email_address_2,
                established_in: established_in,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await contactInfo_services.UpdateContact(id, c_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_contactInfo_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "Contact Number is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteContactInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await contactInfo_services.DestroyContact(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_contactInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchContactInfo,
    NewContactInfo,
    UpdateContactInfo,
    DeleteContactInfo
}