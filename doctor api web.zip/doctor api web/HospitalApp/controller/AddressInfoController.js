const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const address_info_services = require('../services/address_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');

const FetchAddressInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await address_info_services.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_address_info_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await address_info_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_address_info_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };

const NewAddressInfo = async (req, res, next) => {
    const hospital_name_id = req.body.hospital_name_id;
    const address1 = req.body.address1;
    const address2 = req.body.address2;
    const city_id = req.body.city_id;
    const state_id = req.body.state_id;
    const country_id = req.body.country_id;
    const pincode = req.body.pincode;
    const location = req.body.location;
    const longitude = req.body.longitude;
    const latitude = req.body.latitude;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id)

    if (address1) {
        const a_data = {
            hospital_name_id: parseInt(hospital_name_id),
            address1: address1,
            address2: address2,
            city_id: parseInt(city_id),
            state_id: parseInt(state_id),
            country_id: country_id,
            pincode: pincode,
            location: location,
            longitude: longitude,
            latitude: latitude,
            addCheck: addCheck,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };
        console.log(a_data);

        await address_info_services.GetId(hospital_name_id)
            .then(data => {
                if (data.length > 0) {
                    msg = "Hospital Address Already Exist";
                    return res.status(200).json(failure_func(msg))
                } else {
                    address_info_services.CreateAddress(a_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                address_info_services.GetId(hospital_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_address_info_services')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "No Of Doctor is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateAddressInfo = async (req, res, next) => {
    const hospital_name_id = req.params.id;
    if (hospital_name_id) {
        const hospital_name_id = req.body.hospital_name_id;
        const address1 = req.body.address1;
        const address2 = req.body.address2;
        const city_id = req.body.city_id;
        const state_id = req.body.state_id;
        const country_id = req.body.country_id;
        const pincode = req.body.pincode;
        const location = req.body.location;
        const longitude = req.body.longitude;
        const latitude = req.body.latitude
        const active = req.body.active;
        const updated_by = req.user.id;
        const updated_at = date();
        if (address1) {
            const a_data = {
                hospital_name_id: hospital_name_id,
                address1: address1,
                address2: address2,
                city_id: parseInt(city_id),
                state_id: parseInt(state_id),
                country_id: parseInt(country_id),
                pincode: pincode,
                location: location,
                longitude: longitude,
                latitude: latitude,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            console.log(a_data)
            address_info_services.UpdateAddress(hospital_name_id, a_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_address_info_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "No Of Doctor is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

// const DeleteAddressInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await address_info_services.DestroyAddress(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_address_info_services')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

module.exports = {
    FetchAddressInfo,
    NewAddressInfo,
    UpdateAddressInfo,
    // DeleteAddressInfo
}