const UpdateHospitalBasicInfo = async (req, res, next) => {
    const id = req.params.id;
  
    if (!id) {
      const msg = "ID is required";
      return res.status(400).json(failure_func(msg));
    }
  
    const hospital_name = req.body.hospital_name;
    const hospital_type_id = req.body.hospital_type_id;
    const sector_id = req.body.sector_id;
    const accredation_id = req.body.accredation_id;
    const regNo = req.body.regNo;
    const about = req.body.about;
  
    if (!regNo || !hospital_name) {
      const msg = "hospital_name and regNo are required";
      return res.status(400).json(failure_func(msg));
    }
  
    certicate_path = req.files ? req.files.certicate_path : null;
  
    var hospital_image = req.files ? req.files.hospital_image : null;
  
    console.log(hospital_image,"hospital_image");
  
    var hospital_image_string_Array;
  
    var hospital_image_string = req.body ? req.body.hospital_image : null;
  
  console.log(hospital_image_string,"hospital_image_string");
  
    if (hospital_image_string != null && !Array.isArray(hospital_image_string)) {
      hospital_image_string_Array = hospital_image_string.split(',')
    }
  
  
    const active = req.body.active;
    const updated_by = 1;
    const updated_at = date();
  
    const i_data = {
      hospital_name: hospital_name,
      hospital_type_id: parseInt(hospital_type_id),
      sector_id: parseInt(sector_id),
      accredation_id: parseInt(accredation_id),
      regNo: regNo,
      about: about,
      active: active,
      updated_by: updated_by,
      updated_at: updated_at
    };
  
    var currentDate = new Date();
    var year = currentDate.getFullYear();
    var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    var day = currentDate.getDate().toString().padStart(2, '0');
    var hours = currentDate.getHours().toString().padStart(2, '0');
    var minutes = currentDate.getMinutes().toString().padStart(2, '0');
    var seconds = currentDate.getSeconds().toString().padStart(2, '0');
  
    var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  
    if (certicate_path != null) {
      const bucketName = process.env.GCP_BUCKET_NAME;
      const fileName = `${formattedDateTime}_${certicate_path.name}`
      const buffer = certicate_path.data;
      const path = `images/${fileName}`;
      const file = storage.bucket(bucketName).file(path);
      await file.save(buffer);
      i_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
    }
  
    await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
      .then(async (data) => {
        if (data == 1) {
  
          var hosp_id = req.params.id;
  
          if (hospital_image != null) {
            if (hospital_image.name) {
              const bucketName = process.env.GCP_BUCKET_NAME;
              const value = [];
              value.push(hospital_image);
              const uploadImagePromises = value.map(async (element) => {
                const fileName = `${formattedDateTime}_${element.name}`
                const buffer = element.data;
                const file = storage.bucket(bucketName).file(`images/${fileName}`);
                await file.save(buffer);
                const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
                const i_data_img = {
                  hospital_name_id: hosp_id,
                  hospital_image: imageUrl,
                  active: active,
                  created_by: 2,
                  updated_by: 2,
                };
                await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
              });
              Promise.all(uploadImagePromises);
  
            }
            else {
              const bucketName = process.env.GCP_BUCKET_NAME;
  
              const uploadImagePromises = hospital_image.map(async (element) => {
                const fileName = `${formattedDateTime}_${element.name}`
                const buffer = element.data;
                const file = storage.bucket(bucketName).file(`images/${fileName}`);
                await file.save(buffer);
                const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
  
                const i_data_img = {
                  hospital_name_id: hosp_id,
                  hospital_image: imageUrl,
                  active: active,
                  created_by: 2,
                  updated_by: 2,
                };
                await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
              });
              Promise.all(uploadImagePromises);
            }
          }
  
          if (hospital_image_string != null) {
  
            await hospital_img_services.GetbyHospitalImages(hosp_id)
  
              .then(async (data) => {
  
                if (hospital_image_string_Array) {
  
                  var thirdArrayIs = data.filter(function (item) {
                    return !hospital_image_string_Array.includes(item.hospital_image);
                  }).map(function (item) {
                    return item.hospital_image;
                  });
  
                  for (const image of thirdArrayIs) {
  
                    await hospital_img_services.DestroyHospitalImages(image);
                  }
                }
  
                if (hospital_image_string) {
                  var fourthArrayIs = data.filter(function (item) {
                    return !hospital_image_string.includes(item.hospital_image);
                  }).map(function (item) {
                    return item.hospital_image;
                  });
  
                  for (const image of fourthArrayIs) {
  
                    await hospital_img_services.DestroyHospitalImages(image);
                  }
                }
  
              })
  
          }else{
  
          }
  
          if (hospital_image_string != null) {
            await hospital_img_services.GetbyHospitalImages(hosp_id)
              .then(async (data) => {
                if (hospital_image_string_Array) {
                  var thirdArrayIs = data.filter(function (item) {
                    return !hospital_image_string_Array.includes(item.hospital_image);
                  }).map(function (item) {
                    return item.hospital_image;
                  });
          
                 
                }
  
            if (hospital_image_string != null) {
  
            await hospital_img_services.GetbyHospitalImages(hosp_id)
  
              .then(async (data) => {
  
                if (hospital_image_string_Array) {
  
                  var thirdArrayIs = data.filter(function (item) {
                    return !hospital_image_string_Array.includes(item.hospital_image);
                  }).map(function (item) {
                    return item.hospital_image;
                  });
  
                  for (const image of thirdArrayIs) {
  
                    await hospital_img_services.DestroyHospitalImages(image);
                  }
                }
  
                if (hospital_image_string) {
                  var fourthArrayIs = data.filter(function (item) {
                    return !hospital_image_string.includes(item.hospital_image);
                  }).map(function (item) {
                    return item.hospital_image;
                  });
  
                  for (const image of fourthArrayIs) {
  
                    await hospital_img_services.DestroyHospitalImages(image);
                  }
                }
  
              })
  
          }
  
          if (hospital_image_string == undefined) {
  
            await hospital_img_services.DestroyHospitalImagesALL(hosp_id)
  
          }
  
                
              });
          }
        }
      })
  
      .catch(err => {
        console.error("Error updating hospital basic info:", err);
      });
    msg = "Updated successfully"
    res.status(200).json(success_func(msg))
    }  