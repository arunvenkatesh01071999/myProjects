const express = require('express');
const router = express();
const RoomInfoController = require('../controller/RoomInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, RoomInfoController.FetchRoomInfo);
router.get('/:hospital_name_id', verify_token, RoomInfoController.FetchRoomInfo);
router.post('/', verify_token, RoomInfoController.NewRoomInfo);
router.put('/:id', verify_token, RoomInfoController.UpdateRoomInfo);
router.delete('/:id', verify_token, RoomInfoController.DeleteRoomInfo);

module.exports = router;