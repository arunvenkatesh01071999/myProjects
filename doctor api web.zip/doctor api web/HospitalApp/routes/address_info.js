const express = require('express');
const router = express();
const AddressInfoController = require('../../HospitalApp/controller/AddressInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, AddressInfoController.FetchAddressInfo);
router.get('/:hospital_name_id', verify_token, AddressInfoController.FetchAddressInfo);
router.post('/', verify_token, AddressInfoController.NewAddressInfo);
router.put('/:id', verify_token, AddressInfoController.UpdateAddressInfo);
// router.delete('/:id', verify_token, AddressInfoController.DeleteAddressInfo);


module.exports = router; 