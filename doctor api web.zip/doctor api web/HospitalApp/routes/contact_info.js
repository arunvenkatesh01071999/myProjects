const express = require('express');
const router = express();
const ContactInfoController = require('../../HospitalApp/controller/ContactInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, ContactInfoController.FetchContactInfo);
router.get('/:hospital_name_id', verify_token, ContactInfoController.FetchContactInfo);
router.post('/', verify_token, ContactInfoController.NewContactInfo);
router.put('/:id', verify_token, ContactInfoController.UpdateContactInfo);
// router.delete('/:id', verify_token, ContactInfoController.DeleteContactInfo);


module.exports = router; 