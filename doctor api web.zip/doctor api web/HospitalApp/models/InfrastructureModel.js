const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const RoomTypeMaster = require('../../MastersApp/models/RoomTypeMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const InfraStructure = sequelize.define("h_infrastructure", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        validate: {
            notEmpty: {
                msg: "hospital_name_id is required"
            }
        }
    },
    no_of_doctor: {
        type: DataTypes.NUMBER,
        allowNull: true,
        validate: {
            notEmpty: {
                msg: "No of doctor is required"
            }
        }
    },
    no_of_ambulances: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    anesth_doctor: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    anotomy_doctor: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    cost_per_day:{
        type: DataTypes.INTEGER,
        allowNull: true
    },
    cardio_doctor: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    operation_theatre: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    icu: {
        type: DataTypes.NUMBER,
        allowNull: true
    },
    // room_type_id: {
    //     type: DataTypes.INTEGER,
    //     allowNull: true
    // },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

// InfraStructure.belongsTo(RoomTypeMaster, { foreignKey: 'room_type_id' });
InfraStructure.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

InfraStructure.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_infrastructure',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

InfraStructure.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_infrastructure',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = InfraStructure;