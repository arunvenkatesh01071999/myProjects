const HospitalImgInfo = require('../models/HospitalImgModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const CreateHospitalmgBasicInfo = async (i_data_img) => {
    await HospitalImgInfo.create(i_data_img)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryHospitalmgBasicInfo = async (hosp_id) => {
    await HospitalImgInfo.destroy({ where: { hospital_name_id: hosp_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CheckHospitalmgBasicInfo = async (hosp_id) => {
    await HospitalImgInfo.findAll({ where: { hospital_name_id: hosp_id }, raw: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyHospitalImages = async (hosp_id) => {

    const query = `select hospital_image from h_hospital_image where hospital_name_id = ${hosp_id}`
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalImages = async (image) => {
    
    await HospitalImgInfo.destroy({ where: { hospital_image: image } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err

        })

    return res
}

const DestroyHospitalImagesALL = async (id) => {

    await HospitalImgInfo.destroy({ where: { hospital_name_id: id } })
        .then(data => {
            res = data
            
        }).catch(err => {
            res = err

        })

    return res
}

module.exports = {
    CreateHospitalmgBasicInfo,
    DestoryHospitalmgBasicInfo,
    CheckHospitalmgBasicInfo,
    GetbyHospitalImages,
    DestroyHospitalImages,
    DestroyHospitalImagesALL
};