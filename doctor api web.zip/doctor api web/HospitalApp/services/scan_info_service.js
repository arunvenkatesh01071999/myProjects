const ScanInfo = require('../models/ScanInfoModel');
const ScanTestMasterModel = require('../../MastersApp/models/ScanTestMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await ScanInfo.findAll({ include: [ScanTestMasterModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await ScanInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [ScanTestMasterModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await ScanInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateScanInfo = async (s_data) => {
    await ScanInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateScanInfo = async (id, s_data) => {
//     await ScanInfo.update(s_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const DestroyScanInfo = async (hospital_name_id) => {
    await ScanInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}



module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateScanInfo,
    // UpdateScanInfo,
    DestroyScanInfo
};
