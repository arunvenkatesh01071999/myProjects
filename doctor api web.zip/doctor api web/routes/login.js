const express = require('express');
const router = express();
const LoginController = require('../controller/LoginController');

router.post('/login', LoginController.UserLogin);

module.exports = router;