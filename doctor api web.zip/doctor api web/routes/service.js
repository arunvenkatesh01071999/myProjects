const express = require('express');
const router = express();
const ServiceController = require('../controller/ServiceController');
const verify_token = require('../services/verify_token');

router.get('/service', verify_token, ServiceController.FetchServices);
router.get('/service/:id', verify_token, ServiceController.FetchServices);
router.post('/service', verify_token, ServiceController.NewService);
router.put('/service/:id', verify_token, ServiceController.UpdateService);
router.delete('/service/:id', verify_token, ServiceController.DeleteService);


module.exports = router; 
