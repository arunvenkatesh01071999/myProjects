const express = require('express');
const router = express();
const RoleController = require('../controller/RoleController');
const verify_token = require('../services/verify_token');

router.get('/role', verify_token, RoleController.FetchRoles);
router.get('/role/:id', verify_token, RoleController.FetchRoles);
router.post('/role', verify_token, RoleController.NewRole);
router.put('/role/:id', verify_token, RoleController.UpdateRole);
router.delete('/role/:id', verify_token, RoleController.DeleteRole);
router.get('/role/byModule/:service_id', verify_token, RoleController.FetchRolesByModule);


module.exports = router; 