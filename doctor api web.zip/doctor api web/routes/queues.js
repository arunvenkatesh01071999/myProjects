const express = require('express');
const app = express();
const login_services = require('../services/login_service');
const crypto = require('crypto');

var cookieParser = require('cookie-parser')
var csrf = require('csurf')

var csrfProtection = csrf({ cookie: true })

app.use(cookieParser());

app.set('view engine', 'ejs');

const urlencodedParser = express.urlencoded({ extended: false });

app.get('/', csrfProtection, (req, res, next) => {
    res.render('bull_board_login', { csrfToken: req.csrfToken(), invalid: false });
});

app.post('/', urlencodedParser, csrfProtection, async (req, res, next) => {
    email = req.body.email;
    password = req.body.password;
    req.session.loggedin = true;
    const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
    await login_services.GetUser(email, hashed_password)
        .then(user => {
            if (user.length != 0) {
                if (user[0].roles_id == 1) {
                    req.session.loggedin = true
                } else {
                    req.session.loggedin = false
                }
                res.redirect('/admin/queues');
            } else {
                res.render('bull_board_login', { csrfToken: req.csrfToken(), invalid: true });
            }
        })
        .catch(err => {
            res.send(err)
        })
});

const is_authenticated = (req, res, next) => {
    if (req.session.loggedin) {
        next();
    } else {
        res.redirect('/admin/login');
    }
};


module.exports = {
    app,
    is_authenticated
};