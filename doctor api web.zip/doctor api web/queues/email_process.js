const Job = require('bull');
const emailer = require('../config/email_config');

const queueProcess = async (Job) => {
    // console.log(Job);
    console.log(`Processing job : Sending mail to ${Job.data.to}`)
    await emailer.sendMail(Job.data, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log("Job done");
        }
    });
};

module.exports = queueProcess;