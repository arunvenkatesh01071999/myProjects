const Job = require('bull');
var axios = require('axios');

const MobileOTPqueueProcess = async (Job) => {
    // console.log(Job.data);
    console.log(`Processing job : Sending OTP to ${Job.data.phno}`);
    phno = Job.data.phno;
    otp = Job.data.otp;

    msg = 'Your OTP for Kovai Pazhamudir Nilayam online/Mobile app.registration is ' + otp + ' - Kovai Pazhamudir Nilayam'
    var config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'http://www.bluekode.co.in/Smsserver/sms.aspx?cid=25&mobileno=' + phno + '&message=' + msg,
        headers: {}
    };

    await axios(config)
        .then(function (response) {
            if (response.data) {
                console.log("OTP sent for " + phno);
            }
        })
        .catch(function (error) {
            console.log(error);
        });
};

module.exports = MobileOTPqueueProcess;