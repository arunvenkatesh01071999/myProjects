const CouncilInfo = require('../models/CouncilInfoModel');
const council = require('../../MastersApp/models/CouncilModel');


const Get = async () => {
    await CouncilInfo.findAll({
        include: council
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (doctor_name_id) => {
    await CouncilInfo.findAll({
        where: { doctor_name_id: doctor_name_id }, include: council
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await CouncilInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateCouncilInfo = async (a_data) => {
    await CouncilInfo.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateCouncilInfo = async (id, a_data) => {
    await CouncilInfo.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DeleteCouncilInfo = async (id) => {
    await CouncilInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateCouncilInfo,
    UpdateCouncilInfo,
    DeleteCouncilInfo,
};
