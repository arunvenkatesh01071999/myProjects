const DoctorBasicInfo = require('../models/DoctorBasicInfoModel');
const DoctorAddressInfo = require('../models/DoctorAddressInfoModel');
const ExperienceModel = require('../models/ExperienceModel');
const SpecialityInfo = require('../../MastersApp/models/SpecialitiesModel');
const GenderMaster = require('../../MastersApp/models/GenderModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');
const Get = async () => {

    const query = `select a.id,a.addCheck,a.doctor_name,a.email,a.phone_no,a.image_path,a.signature_path,
    a.created_at,a.isApproved,a.approve_date,a.approved_by,a.rating,
    a.reason,b.doctor_name_id,b.address1,b.address2,b.pincode,b.location,c.speciality_name,
    d.gender_name,e.experience,e.upload_certicate
    from d_doctor_basic_info as a
    left join d_address_info as b on b.doctor_name_id=a.id
    left join specialities as c on a.speciality_id=c.id
    left join gender as d on a.gender_id=d.id
    left join d_experience_info as e on e.doctor_name_id=a.id`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res
}

const GetbyId = async (doctor_name_id) => {

    const query = `select a.id,a.addCheck,a.doctor_name,a.email,a.phone_no,a.image_path,a.signature_path,
    a.created_at,a.isApproved,a.approve_date,a.approved_by,a.rating,a.reason,
    b.doctor_name_id,b.address1,b.address2,b.pincode,b.location,c.speciality_name,
    d.gender_name,e.experience,e.upload_certicate
    from d_doctor_basic_info as a
    left join d_address_info as b on b.doctor_name_id=a.id
    left join specialities as c on a.speciality_id=c.id
    left join gender as d on a.gender_id=d.id
    left join d_experience_info as e on e.doctor_name_id=a.id where a.id=${doctor_name_id}`;
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res

}

module.exports = {
    Get,
    GetbyId
};