const SlotBookingInfo = require('../models/SlotBookingModel');
const SlotWalking = require('../models/SlotBookingModel');
const SlotOnline = require('../models/SlotBookingModel')
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const Get = async () => {
    try {
        const all_data = [];
        const all_data_walking = [];
        var newArray = [];


        const query = `select * from d_slot_virtual `;
        await db1.query(query, { type: Sequelize.QueryTypes })
            .then((result) => {
                res = result
                all_data.push(res);
            })
            .catch((err) => {
                res = err
            });

        const query1 = `select * from d_slot_walking `;
        await db1.query(query1, { type: Sequelize.QueryTypes })
            .then((result) => {
                res = result
                all_data_walking.push(res);
                newArray = all_data.concat(all_data_walking);
                res = newArray;
            })
            .catch((err) => {
                res = err
            });

    }
    catch (err) {
        // Log Errors
        throw Error('Error while getting slot virtual and slot walking data', err);
    }
    return res;
};

const GetbyId = async (doctor_name_id) => {
    try {
        const all_data = [];
        const all_data_walking = [];
        var newArray = [];

        if (doctor_name_id) {
            const query = `select * from d_slot_virtual  where doctor_name_id=${doctor_name_id}`;
            await db1.query(query, { type: Sequelize.QueryTypes })
                .then((result) => {
                    res = result
                    all_data.push(res);
                })
                .catch((err) => {
                    res = err
                });

            const query1 = `select * from d_slot_walking  where doctor_name_id=${doctor_name_id}`;
            await db1.query(query1, { type: Sequelize.QueryTypes })
                .then((result) => {
                    res = result
                    all_data_walking.push(res);
                    newArray = all_data.concat(all_data_walking);
                    res = newArray;
                })
                .catch((err) => {
                    res = err
                });
        }
    }
    catch (err) {
        // Log Errors
        throw Error('Error while getting slot virtual and slot walking data', err);
    }
    return res;
}

const GetId = async (id) => {
    await SlotBookingInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSlotBookingInfo = async (sl_data) => {

    try {
        // Save the slot data to the database
        console.log(sl_data);
        if (sl_data.virtual == 1) {
            const newSlot = await SlotBookingInfo.SlotOnline.create(sl_data);
            console.log(newSlot);
            // Return the newly created slot or an appropriate success response
            return newSlot;
        }
        else {
            const newSlot = await SlotBookingInfo.SlotWalking.create(sl_data);
            // Return the newly created slot or an appropriate success response
            return newSlot;
        }

    } catch (err) {
        // Handle the error appropriately
        console.error('Error saving slot to the database:', err);
        throw err; // Throw the error to be caught and handled by the caller
    }
};

const UpdateSlotBookingInfo = async (doctor_name_id, sl_data) => {
    // await SlotBookingInfo.update(sl_data, { where: { id: id } })
    //     .then(data => {
    //         res = data[0]
    //     }).catch(err => {
    //         res = err
    //     })
    // return res

    
    try {
        // Save the slot data to the database
        if (sl_data.virtual == 1) {
            console.log('mmmm',doctor_name_id);
            const newSlot = await SlotBookingInfo.SlotOnline.update(sl_data, { where: { doctor_name_id: doctor_name_id } })
            // // Return the newly created slot or an appropriate success response
            // return newSlot;
        }
        else {
            console.log('ssss');
            const newSlot = await SlotBookingInfo.SlotWalking.update(sl_data, { where: { doctor_name_id: doctor_name_id } })
            // Return the newly created slot or an appropriate success response
            return newSlot;
        }

    } catch (err) {
        // Handle the error appropriately
        console.error('Error saving slot to the database:', err);
        throw err; // Throw the error to be caught and handled by the caller
    }
};

const DestroySlotBooking = async (doctor_name_id) => {
    await SlotBookingInfo.destroy({ where: { doctor_name_id: doctor_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

// const DestroySlot = async (doctor_name_id) => {

    
//     // await SlotBookingInfo.destroy({ where: { doctor_name_id: doctor_name_id } })
//     //     .then(data => {
//     //         res = data
//     //     }).catch(err => {
//     //         res = err
//     //     })
//     // return res
// }

const DestroySlot = async (doctor_name_id) => {
    const check=`select * from d_slot_virtual where doctor_name_id = ${doctor_name_id}`;
    var chk_vir = await db1.query(check);
    if(chk_vir){
            const query1 = `delete from d_slot_virtual where doctor_name_id = ${doctor_name_id}`
            var customerFeedback1 = await db1.query(query1);
    }
    const check1=`select * from d_slot_walking where doctor_name_id = ${doctor_name_id}`;
    var chk_vir1 = await db1.query(check1);
    if(chk_vir1){
        const query2 = `delete from d_slot_walking where doctor_name_id = ${doctor_name_id}`
        var customerFeedback2 = await db1.query(query2);
      }
    // console.log('ji',customerFeedback1);
    // // await SlotOnline.destroy({ where: { doctor_name_id: doctor_name_id } });
    //     .then(data => {
    //         res = data
    //     }).catch(err => {
    //         res = err
    //     })
    return customerFeedback2
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateSlotBookingInfo,
    UpdateSlotBookingInfo,
    DestroySlotBooking,
    DestroySlot
};