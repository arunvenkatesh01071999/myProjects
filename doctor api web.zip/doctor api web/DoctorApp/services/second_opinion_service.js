const SecondOpinionInfo = require('../models/SecondOpinionModel');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const PeriodModel = require('../../MastersApp/models/PeriodMasterModel');


const Get = async () => {
    await SecondOpinionInfo.findAll({
        include: [ PeriodModel]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (doctor_name_id) => {
    await SecondOpinionInfo.findAll({
        where: { doctor_name_id: doctor_name_id },
        include: [PeriodModel]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await SecondOpinionInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSecondOpinionInfo = async (so_data) => {
    await SecondOpinionInfo.create(so_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateSecondOpinionInfo = async (id, so_data) => {
    await SecondOpinionInfo.update(so_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroySecondOpinion = async (id) => {
    await SecondOpinionInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateSecondOpinionInfo,
    UpdateSecondOpinionInfo,
    DestroySecondOpinion,
};
