const express = require('express');
const router = express();
const EducationInfoController = require('../../DoctorApp/controller/EducationInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, EducationInfoController.FetchQualificationInfo);
router.get('/:doctor_name_id', verify_token, EducationInfoController.FetchQualificationInfo);
router.post('/', verify_token, EducationInfoController.NewQualificationInfo);
router.put('/:id', verify_token, EducationInfoController.UpdateQualificationInfo);
router.delete('/:id', verify_token, EducationInfoController.DeleteQualificationInfo);

module.exports = router;