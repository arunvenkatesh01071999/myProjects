const express = require('express');
const router = express();
const CouncilInfoController = require('../../DoctorApp/controller/CouncilInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, CouncilInfoController.FetchCouncilInfo);
router.get('/:doctor_name_id', verify_token, CouncilInfoController.FetchCouncilInfo);
router.post('/', verify_token, CouncilInfoController.NewCouncilInfo);
router.put('/:id', verify_token, CouncilInfoController.UpdateCouncilInfo);
router.delete('/:id', verify_token, CouncilInfoController.DeleteCouncilInfo);

module.exports = router;