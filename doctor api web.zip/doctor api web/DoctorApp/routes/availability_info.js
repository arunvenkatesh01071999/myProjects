const express = require('express');
const router = express();
const AvailabilityController = require('../../DoctorApp/controller/AvailabilityController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, AvailabilityController.FetchAvailability);
router.get('/:doctor_name_id', verify_token, AvailabilityController.FetchAvailability);
router.post('/', verify_token, AvailabilityController.NewAvailability);
router.put('/:id', verify_token, AvailabilityController.UpdateAvailability);
router.delete('/:id', verify_token, AvailabilityController.DeleteAvailability);

module.exports = router;