const express = require('express');
const router = express();
const DoctorBasicInfoController = require('../../DoctorApp/controller/DoctorBasicInfoController')
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, DoctorBasicInfoController.FetchDoctorBasicInfo);
router.get('/:id', verify_token, DoctorBasicInfoController.FetchDoctorBasicInfo);
router.post('/', verify_token, DoctorBasicInfoController.NewDoctorBasicInfo);
router.put('/:id', verify_token, DoctorBasicInfoController.UpdateDoctorBasicInfo);
router.put('/approve/:id', verify_token, DoctorBasicInfoController.DoctorApprove);
router.put('/approve/update/:id', verify_token, DoctorBasicInfoController.UpdateforApprove);

module.exports = router; 