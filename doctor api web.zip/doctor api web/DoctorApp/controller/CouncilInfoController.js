const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const council_info_service = require('../services/council_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs')
const AddCheck = require('../../services/doctor_addCheck_service');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchCouncilInfo = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await council_info_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_council_info_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await council_info_service.Get()
            .then(data => {
                // cache.SET(req.user.id + '_council_info_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewCouncilInfo = async (req, res, next) => {
    doctor_name_id = req.body.doctor_name_id;
    council_id = req.body.council_id;
    registration_no = req.body.registration_no;
    registration_date = req.body.registration_date ? req.body.registration_date : null;
    renewal_date = req.body.renewal_date ? req.body.renewal_date : null;
    certificate_path = req.files ? req.files.certificate_path : null;
    // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
    // certificate_path = req.files ? req.files.certificate_path : null;;
    // } else {
    //     certificate_path = req.body.certificate_path;
    // }
    active = req.body.active;
    created_at = date();
    updated_at = date();
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 11;
    const query = AddCheck(req.body.doctor_name_id);

    if (council_id) {
        s_data = {
            doctor_name_id: parseInt(doctor_name_id),
            council_id: parseInt(council_id),
            registration_no: registration_no,
            registration_date: registration_date,
            renewal_date: renewal_date,
            active: parseInt(active),
            created_at: created_at,
            updated_at: updated_at,
            created_by: created_by,
            updated_by: updated_by
        }
        // console.log(registration_no,typeof(registration_no),"SDCS");
        // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
        //     s_data.certificate_path = certificate_path.name;
        //     buffer = certificate_path.data
        //     path = './media/' + certificate_path.name;
        //     fs.writeFile(path.toString(), buffer, function (err) {
        //         if (err) {
        //             return console.log(err);
        //         }
        //     });

        // } else {
        // certificate_path = req.body.certificate_path;
        // s_data.certificate_path = certificate_path;
        // }

        if (certificate_path) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = certificate_path.name;
            const buffer = certificate_path.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            s_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            certificate_path = req.body.certificate_path;
            s_data.certificate_path = certificate_path;
        }

        console.log(s_data)
        await council_info_service.CreateCouncilInfo(s_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                    logger.info(msg);
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_council_info_service')
                    res.status(200).json(success_func(msg))

                    // council_info_service.GetId(doctor_name_id)
                    //     .then(datas => {
                    //         datas.msg = "Created Successfully"
                    //         cache.DEL(req.user.id + '_council_info_service')
                    //         res.status(200).json(success_func(datas))
                    //         // logger.info(msg);
                    // })
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })

    } else {
        msg = "doctor_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateCouncilInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_name_id = req.body.doctor_name_id;
        registration_no = req.body.registration_no;
        council_id = req.body.council_id;
        registration_date = req.body.registration_date;
        renewal_date = req.body.renewal_date;
        if (req.files && req.files.certificate_path && req.files.certificate_path.name) {

            certificate_path = req.files.certificate_path;
        } else {
            certificate_path = req.body.certificate_path;
        }
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (council_id) {
            s_data = {
                doctor_name_id: parseInt(doctor_name_id),
                council_id: parseInt(council_id),
                registration_no: registration_no,
                registration_date: registration_date,
                renewal_date: renewal_date,
                certificate_path: certificate_path,
                active: parseInt(active),
                updated_by: updated_by,
                updated_at: updated_at
            }
            // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
            //     s_data.certificate_path = certificate_path.name;
            //     buffer = certificate_path.data
            //     path = './media/' + certificate_path.name;
            //     fs.writeFile(path.toString(), buffer, function (err) {
            //         if (err) {
            //             return console.log(err);
            //         }
            //     });

            // } else {
            //     certificate_path = req.body.certificate_path;
            //     s_data.certificate_path = certificate_path;
            // }

            if (certificate_path) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = certificate_path.name;
                const buffer = certificate_path.data;
                const path = `images/${fileName}`;

                const file = storage.bucket(bucketName).file(path);

                // Upload the image to GCS
                await file.save(buffer);

                s_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
            else {
                certificate_path = req.body.certificate_path;
                s_data.certificate_path = certificate_path;
            }

            console.log(s_data)
            await council_info_service.UpdateCouncilInfo(id, s_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_council_info_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "doctor_name_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteCouncilInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await council_info_service.DeleteCouncilInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_council_info_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewCouncilInfo,
    FetchCouncilInfo,
    UpdateCouncilInfo,
    DeleteCouncilInfo
}