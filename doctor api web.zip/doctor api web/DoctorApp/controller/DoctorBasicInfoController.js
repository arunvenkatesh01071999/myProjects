const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const doctorBasicInfo_services = require('../services/doctor_basic_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchDoctorBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await doctorBasicInfo_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_doctorBasicInfo_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await doctorBasicInfo_services.Get()
            .then(data => {
                // cache.SET(req.user.id + '_doctorBasicInfo_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };

const NewDoctorBasicInfo = async (req, res, next) => {
    doctor_name = req.body.doctor_name;
    gender_id = req.body.gender_id;
    email = req.body.email;
    phone_no = req.body.phone_no;
    about = req.body.about;
    last_otp = req.body.last_otp;
    hospital_name_id = req.body.hospital_name_id;
    image_path = req.files ? req.files.image_path : null;
    // signature_path = req.files ? req.files.signature_path : null;
    // if (req.files && req.files.image_path && req.files.image_path.name) {

    //     image_path = req.files.image_path;

    // } else {
    //     image_path = req.body.image_path;
    // }
    if (req.files && req.files.signature_path && req.files.signature_path.name) {

        signature_path = req.files.signature_path;
    } else {
        signature_path = req.body.signature_path;
    }

    dob = req.body.dob;
    age = req.body.age;
    speciality_id = req.body.speciality_id;
    doctor_type_id = req.body.doctor_type_id;
    active = 1;
    isApproved = 0;
    approved_by = 0;
    // approve_date = '';
    created_at = date();
    updated_at = date();
    created_by =  req.user.id;
    updated_by =  req.user.id;
    addCheck = 11;

    if (doctor_name) {
        d_data = {
            doctor_name: doctor_name,
            gender_id: parseInt(gender_id),
            email: email,
            phone_no: phone_no,
            about: about,
            dob: dob,
            image_path: image_path,
            about: about,
            workplacetype: 0,
            update_on_whatsapp: 0,
            addCheck: addCheck,
            age: parseInt(age),
            isApproved: isApproved,
            approve_date: null,
            approved_by: approved_by,
            speciality_id: parseInt(speciality_id),
            doctor_type_id: parseInt(doctor_type_id),
            hospital_name_id: parseInt(hospital_name_id),
            last_otp: last_otp,
            active: parseInt(active),
            created_at: created_at,
            updated_at: updated_at,
            created_by: created_by,
            updated_by: updated_by
        }

        var currentDate = new Date();
        var year = currentDate.getFullYear();
        var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        var day = currentDate.getDate().toString().padStart(2, '0');
        var hours = currentDate.getHours().toString().padStart(2, '0');
        var minutes = currentDate.getMinutes().toString().padStart(2, '0');
        var seconds = currentDate.getSeconds().toString().padStart(2, '0');
      
        var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

        if (image_path) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = `${formattedDateTime}_${image_path.name}`;
            const buffer = image_path.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        } else {
            d_data.image_path = null; // Set image_path to null if not provided
        }

        // if (signature_path) {
        //     const bucketName = process.env.GCP_BUCKET_NAME;
        //     const fileName = signature_path.name;
        //     const buffer = signature_path.data;
        //     const path = `images/${fileName}`;
        //     const file = storage.bucket(bucketName).file(path);
        //     // Upload the image to GCS
        //     await file.save(buffer);
        //     d_data.signature_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        // }
        // else {
        //     // If no image is provided, you may want to handle null or default values
        //     d_data.signature_path = null; // or set a default image URL
        // }

        // if (req.files && req.files.image_path && req.files.image_path.name) {
        //     d_data.image_path = image_path.name;
        //     buffer = image_path.data
        //     path = './media/' + image_path.name;
        //     fs.writeFile(path.toString(), buffer, function (err) {
        //         if (err) {
        //             return console.log(err);
        //         }
        //     });
        // } else {

        //     image_path = req.body.image_path;
        //     d_data.image_path = image_path;
        // }

        if (req.files && req.files.signature_path && req.files.signature_path.name) {

            d_data.signature_path = signature_path.name;
            buffer = signature_path.data
            path = './media/' + signature_path.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });

        } else {

            signature_path = req.body.signature_path;
            d_data.signature_path = signature_path;

        }
        console.log(d_data);

        await doctorBasicInfo_services.GetbyName(phone_no)
            .then(basic_data => {
                if (basic_data.length > 0) {
                    msg = "Phone Number already registered";
                    return res.status(200).json(failure_func(msg))
                } else {
                    doctorBasicInfo_services.CreateDoctorBasicInfo(d_data)
                        .then(data => {
                            // console.log("dtaaads", data);
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                // console.log('data',data);
                                doctorBasicInfo_services.GetbyName(doctor_name)
                                    .then(datas => {
                                        data.msg = "Created Successfully";
                                        // cache.DEL(req.user.id + '_doctorBasicInfo_services')
                                        res.status(200).json(success_func(data))
                                    })
                                    .catch(err => {
                                        res.status(400).json(failure_func(err))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "doctor_name is required";
        res.status(400).json(failure_func(msg))
    }
}

// const UpdateDoctorBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         doctor_name = req.body.doctor_name;
//         gender_id = req.body.gender_id;
//         email = req.body.email;
//         phone_no = req.body.phone_no;
//         doctor_type_id = req.body.doctor_type_id;
//         about = req.body.about;
//         if (req.files && req.files.image_path && req.files.image_path.name) {

//             image_path = req.files.image_path;

//         } else {
//             image_path = req.body.image_path;
//         }
//         if (req.files && req.files.signature_path && req.files.signature_path.name) {

//             signature_path = req.files.signature_path;
//         } else {
//             signature_path = req.body.signature_path;
//         }
//         dob = req.body.dob;
//         age = req.body.age;
//         speciality_id = req.body.speciality_id;
//         hospital_name_id = req.body.hospital_name_id;
//         about = req.body.about;
//         active = 1;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (doctor_name) {
//             d_data = {
//                 doctor_name: doctor_name,
//                 gender_id: gender_id,
//                 email: email,
//                 phone_no: phone_no,
//                 about: about,
//                 dob: dob,
//                 about: about,
//                 age: age,
//                 speciality_id: speciality_id,
//                 doctor_type_id: doctor_type_id,
//                 hospital_name_id: hospital_name_id,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             if (req.files && req.files.image_path && req.files.image_path.name) {
//                 d_data.image_path = image_path.name;
//                 buffer = image_path.data
//                 path = './media/' + image_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             } else {

//                 image_path = req.body.image_path;
//                 d_data.image_path = image_path;
//             }

//             if (req.files && req.files.signature_path && req.files.signature_path.name) {

//                 d_data.signature_path = signature_path.name;
//                 buffer = signature_path.data
//                 path = './media/' + signature_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });

//             } else {

//                 signature_path = req.body.signature_path;
//                 d_data.signature_path = signature_path;

//             }

//             await doctorBasicInfo_services.GetbyName(phone_no)
//                 .then(basic_data => {
//                     if (basic_data.length > 0) {
//                         msg = "Phone Number already registered";
//                         return res.status(200).json(failure_func(msg))
//                     } else {
//                         doctorBasicInfo_services.UpdateDoctorBasicInfo(id, d_data)
//                             .then(data => {
//                                 if (data == 1) {
//                                     msg = "Updated successfully"
//                                     // cache.DEL(req.user.id + '_doctorBasicInfo_services')
//                                     res.status(200).json(success_func(msg))
//                                 } else {
//                                     msg = "ID doesn't exist"
//                                     res.status(400).json(failure_func(msg))
//                                 }
//                             })
//                             .catch(err => {
//                                 res.status(400).json(failure_func(err))
//                             })
//                     }
//                 })

//         } else {
//             msg = "doctor_name is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateDoctorBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         doctor_name = req.body.doctor_name;
//         gender_id = req.body.gender_id;
//         email = req.body.email;
//         phone_no = req.body.phone_no;
//         doctor_type_id = req.body.doctor_type_id;
//         about = req.body.about;
//         // image_path = req.files ? req.files.image_path : null;
//         // signature_path = req.files ? req.files.signature_path : null;
//         if (req.files && req.files.image_path && req.files.image_path.name) {
//             image_path = req.files.image_path;
//         } else {
//             image_path = req.body.image_path;
//         }
//         if (req.files && req.files.signature_path && req.files.signature_path.name) {
//             signature_path = req.files.signature_path;
//         } else {
//             signature_path = req.body.signature_path;
//         }
//         dob = req.body.dob;
//         age = req.body.age;
//         speciality_id = req.body.speciality_id;
//         hospital_name_id = req.body.hospital_name_id;
//         about = req.body.about;
//         active = 1;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (doctor_name) {
//             d_data = {
//                 doctor_name: doctor_name,
//                 gender_id: gender_id,
//                 email: email,
//                 phone_no: phone_no,
//                 about: about,
//                 dob: dob,
//                 about: about,
//                 age: age,
//                 speciality_id: speciality_id,
//                 doctor_type_id: doctor_type_id,
//                 hospital_name_id: hospital_name_id,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             if (typeof image_path === "string") {
//                 d_data.image_path = image_path;
//             } else {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = image_path.name;
//                 const buffer = image_path.data;
//                 const path = `images/${fileName}`;
//                 const file = storage.bucket(bucketName).file(path);
//                 // Upload the image to GCS
//                 await file.save(buffer);
//                 d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//             }

//             // if (image_path) {
//             //     const bucketName = process.env.GCP_BUCKET_NAME;
//             //     const fileName = image_path.name;
//             //     const buffer = image_path.data;
//             //     const path = `images/${fileName}`;
//             //     const file = storage.bucket(bucketName).file(path);
//             //     // Upload the image to GCS
//             //     await file.save(buffer);
//             //     d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//             // }
//             // else {
//             //     // If no image is provided, you may want to handle null or default values
//             //     image_path = req.body.image_path;
//             //     d_data.image_path = image_path;
//             // }

//             // if (signature_path) {
//             //     const bucketName = process.env.GCP_BUCKET_NAME;
//             //     const fileName = signature_path.name;
//             //     const buffer = signature_path.data;
//             //     const path = `images/${fileName}`;
//             //     const file = storage.bucket(bucketName).file(path);
//             //     // Upload the image to GCS
//             //     await file.save(buffer);
//             //     d_data.signature_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//             // }
//             // else {
//             //     // If no image is provided, you may want to handle null or default values
//             //     d_data.signature_path = null; // or set a default image URL
//             // }

//             if (req.files && req.files.signature_path && req.files.signature_path.name) {
//                 d_data.signature_path = signature_path.name;
//                 buffer = signature_path.data
//                 path = './media/' + signature_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             } else {
//                 signature_path = req.body.signature_path;
//                 d_data.signature_path = signature_path;
//             }
//             doctorBasicInfo_services.GetbyPhoneNumberId(id, phone_no)
//                 .then(data => {
//                     if (data.length > 0) {
//                         doctorBasicInfo_services.UpdateDoctorBasicInfo(id, d_data)
//                             .then(data => {
//                                 if (data == 1) {
//                                     msg = "Updated successfully"
//                                     // cache.DEL(req.user.id + '_doctorBasicInfo_services')
//                                     res.status(200).json(success_func(msg))
//                                 } else {
//                                     msg = "ID doesn't exist"
//                                     res.status(400).json(failure_func(msg))
//                                 }
//                             })
//                             .catch(err => {
//                                 res.status(400).json(failure_func(err))
//                             })
//                     }
//                     else {
//                         doctorBasicInfo_services.GetbyPhoneNumberAll(phone_no)
//                             .then(data => {
//                                 if (data.length > 0) {
//                                     msg = "phone number already exists";
//                                     return res.status(200).json(failure_func(msg))
//                                 }
//                                 else {
//                                     doctorBasicInfo_services.UpdateDoctorBasicInfo(id, d_data)
//                                         .then(data => {
//                                             if (data == 1) {
//                                                 msg = "Updated successfully"
//                                                 // cache.DEL(req.user.id + '_doctorBasicInfo_services')
//                                                 res.status(200).json(success_func(msg))
//                                             } else {
//                                                 msg = "ID doesn't exist"
//                                                 res.status(400).json(failure_func(msg))
//                                             }
//                                         })
//                                         .catch(err => {
//                                             res.status(400).json(failure_func(err))
//                                         })
//                                 }
//                             })
//                     }
//                 })
//         }
//         else {
//             msg = "doctor_name is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const UpdateDoctorBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_name = req.body.doctor_name;
        gender_id = req.body.gender_id;
        email = req.body.email;
        phone_no = req.body.phone_no;
        doctor_type_id = req.body.doctor_type_id;
        about = req.body.about;
        // image_path = req.files ? req.files.image_path : null;
        // signature_path = req.files ? req.files.signature_path : null;
        if (req.files && req.files.image_path && req.files.image_path.name) {
            image_path = req.files.image_path;
        } else {
            image_path = req.body.image_path;
        }
        if (req.files && req.files.signature_path && req.files.signature_path.name) {
            signature_path = req.files.signature_path;
        } else {
            signature_path = req.body.signature_path;
        }
        dob = req.body.dob;
        age = req.body.age;
        speciality_id = req.body.speciality_id;
        hospital_name_id = req.body.hospital_name_id;
        about = req.body.about;
        active = 1;
        updated_by = req.user.id;
        updated_at = date();

        var currentDate = new Date();
        var year = currentDate.getFullYear();
        var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        var day = currentDate.getDate().toString().padStart(2, '0');
        var hours = currentDate.getHours().toString().padStart(2, '0');
        var minutes = currentDate.getMinutes().toString().padStart(2, '0');
        var seconds = currentDate.getSeconds().toString().padStart(2, '0');
      
        var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

        if (doctor_name) {
            d_data = {
                doctor_name: doctor_name,
                gender_id: gender_id,
                email: email,
                phone_no: phone_no,
                about: about,
                dob: dob,
                about: about,
                age: age,
                speciality_id: speciality_id,
                doctor_type_id: doctor_type_id,
                hospital_name_id: hospital_name_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            console.log(image_path,"image_path");

            if (typeof image_path === "string") {
                d_data.image_path = image_path;
            } else {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = `${formattedDateTime}_${image_path.name}`;
                const buffer = image_path.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                // Upload the image to GCS
                await file.save(buffer);
                d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            }

            // if (image_path) {
            //     const bucketName = process.env.GCP_BUCKET_NAME;
            //     const fileName = image_path.name;
            //     const buffer = image_path.data;
            //     const path = `images/${fileName}`;
            //     const file = storage.bucket(bucketName).file(path);
            //     // Upload the image to GCS
            //     await file.save(buffer);
            //     d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            // }
            // else {
            //     // If no image is provided, you may want to handle null or default values
            //     image_path = req.body.image_path;
            //     d_data.image_path = image_path;
            // }

            // if (signature_path) {
            //     const bucketName = process.env.GCP_BUCKET_NAME;
            //     const fileName = signature_path.name;
            //     const buffer = signature_path.data;
            //     const path = `images/${fileName}`;
            //     const file = storage.bucket(bucketName).file(path);
            //     // Upload the image to GCS
            //     await file.save(buffer);
            //     d_data.signature_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            // }
            // else {
            //     // If no image is provided, you may want to handle null or default values
            //     d_data.signature_path = null; // or set a default image URL
            // }

            if (req.files && req.files.signature_path && req.files.signature_path.name) {
                d_data.signature_path = signature_path.name;
                buffer = signature_path.data
                path = './media/' + signature_path.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
            } else {
                signature_path = req.body.signature_path;
                d_data.signature_path = signature_path;
            }
            doctorBasicInfo_services.GetbyPhoneNumberId(id, phone_no)
                .then(data => {
                    if (data.length > 0) {
                        doctorBasicInfo_services.UpdateDoctorBasicInfo(id, d_data)
                            .then(data => {
                                if (data == 1) {
                                    msg = "Updated successfully"
                                    // cache.DEL(req.user.id + '_doctorBasicInfo_services')
                                    res.status(200).json(success_func(msg))
                                } else {
                                    msg = "ID doesn't exist"
                                    res.status(400).json(failure_func(msg))
                                }
                            })
                            .catch(err => {
                                res.status(400).json(failure_func(err))
                            })
                    }
                    else {
                        doctorBasicInfo_services.GetbyPhoneNumberAll(phone_no)
                            .then(data => {
                                if (data.length > 0) {
                                    msg = "phone number already exists";
                                    return res.status(200).json(failure_func(msg))
                                }
                                else {
                                    doctorBasicInfo_services.UpdateDoctorBasicInfo(id, d_data)
                                        .then(data => {
                                            if (data == 1) {
                                                msg = "Updated successfully"
                                                // cache.DEL(req.user.id + '_doctorBasicInfo_services')
                                                res.status(200).json(success_func(msg))
                                            } else {
                                                msg = "ID doesn't exist"
                                                res.status(400).json(failure_func(msg))
                                            }
                                        })
                                        .catch(err => {
                                            res.status(400).json(failure_func(err))
                                        })
                                }
                            })
                    }
                })
        }
        else {
            msg = "doctor_name is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DoctorApprove = async (req, res, next) => {
    const id = req.params.id;
    if (id) {
        const { isApproved, approve_date, approved_by, reason, id } = req.body;
        // if (isApproved) {
        if (isApproved === 1) {
            const a_data = {
                id: parseInt(id),
                isApproved: isApproved,
                approve_date: approve_date,
                approved_by: approved_by,
                reason: reason
            }
            await doctorBasicInfo_services.CreateApprove(id, a_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                        res.status(400).json(failure_func(msg))
                    } else {
                        msg = "Approved Successfully"
                        // cache.DEL(req.user.id + '_doctorBasicInfo_services')
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        else {
            const a_data = {
                id: parseInt(id),
                isApproved: isApproved,
                approve_date: approve_date,
                approved_by: approved_by,
                reason: reason
            }

            await doctorBasicInfo_services.CreateApprove(id, a_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                        res.status(400).json(failure_func(msg))
                    } else {
                        msg = "Rejected Successfully"
                        // cache.DEL(req.user.id + '_doctorBasicInfo_services')
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        }
        // }
    }
}

const DeleteDoctorBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await doctorBasicInfo_services.DestroyDoctorBasicInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_doctorBasicInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateforApprove = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await doctorBasicInfo_services.UpdateIsApprove(id)
            .then(data => {
                res.json('created success')
            }).catch(err => {
                res.json('not created')
            })
    }
}

module.exports = {
    FetchDoctorBasicInfo,
    NewDoctorBasicInfo,
    UpdateDoctorBasicInfo,
    DeleteDoctorBasicInfo,
    DoctorApprove,
    UpdateforApprove
}