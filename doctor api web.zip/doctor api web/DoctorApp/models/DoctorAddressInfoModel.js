const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const CityMaster = require('../../MastersApp/models/CityModel');
const StateMaster = require('../../MastersApp/models/StateModel');
const CountryMaster = require('../../MastersApp/models/CountryModel');

const AddressInfo = sequelize.define("d_address_info", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Address is required"
            }
        }
    },
    address1: {
        type: DataTypes.STRING,
        allowNull: false
    },
    address2: {
        type: DataTypes.STRING,
        allowNull: false
    },
    city_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    state_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    country_id: {
        type: DataTypes.STRING,
        allowNull: true
    },
    pincode: {
        type: DataTypes.NUMBER,
        allowNull: false
    },
    location: {
        type: DataTypes.STRING,
        allowNull: true
    },
    longitude: {
        type: DataTypes.DECIMAL(7, 2),
        allowNull: true
    },
    latitude: {
        type: DataTypes.DECIMAL(7, 2),
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

AddressInfo.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });
AddressInfo.belongsTo(CityMaster, { foreignKey: 'city_id' });
AddressInfo.belongsTo(StateMaster, { foreignKey: 'state_id' });
AddressInfo.belongsTo(CountryMaster, { foreignKey: 'country_id' });

AddressInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_address_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

AddressInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_address_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = AddressInfo;