const HOSPITAL_BASIC_INFO = {
  NAME: "h_hospital_basic_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_NAME: "hospital_name",
    HOSPITAL_TYPE_ID: "hospital_type_id",
    SECTOR_ID: "sector_id",
    ACCREDATION_ID: "accredation_id",
    REGNO: "regNo",
    ABOUT: "about",
    CERTIFICATE_PATH: "certicate_path",
    ADDCHECK: "addCheck",
    APPROVED_BY: "approved_by",
    RESASON: "reason",
    APPROVE_DATE: "approve_date",
    ISAPPROVED: "isApproved",
    HOSPITAL_IMAGE: "hospital_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    HOSPITAL_USER: "hospital_user",
    RATING: "rating"
  }
};
const HOSPITAL_REVIEWS = {
  NAME: "h_hospital_reviews",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_id",
    PATIENT_ID: "patient_id",
    COMMENTS: "comments",
    RATING: "rating",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const REGISTERINFO = {
  NAME: "patient_registration",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    DOB: "dob",
    MOBILE: "mobile",
    BLOOD_GROUP_ID: "blood_group_id",
    PROFILE_IMAGE: "profile_image",
    IS_VERIFIED: "is_verified",
    LAST_OTP: "last_otp",
    PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    MARTIAL_STATUS_ID: "martial_status_id",
    LOGITUTE: "logitute",
    LATITUDE: "latitude",
    ACTIVE: "active",
    AGE: "age",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    ADDRESS: "address",
    FULLADDRESS: "fulladdress"
  }
};

module.exports = {
  HOSPITAL_BASIC_INFO,
  HOSPITAL_REVIEWS,
  REGISTERINFO
};
