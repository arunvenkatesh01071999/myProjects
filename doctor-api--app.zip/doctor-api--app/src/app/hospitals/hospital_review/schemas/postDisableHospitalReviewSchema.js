const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postDisableHospitalReviewSchema = {
  tags: ["Hospital REVIEWS"],
  summary: "This API is used to disable reivews",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["hospital_id", "patient_id", "active"],
    additionalProperties: false,
    properties: {
      hospital_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postDisableHospitalReviewSchema;
