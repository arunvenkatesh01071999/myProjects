const postHospitalReviewSchema = require("./postHospitalReviewSchema");
const getHospitalReviewSchema = require("./getHospitalReviewSchema");
const postDisableHospitalReviewSchema = require("./postDisableHospitalReviewSchema");

module.exports = {
  postHospitalReviewSchema,
  getHospitalReviewSchema,
  postDisableHospitalReviewSchema
};
