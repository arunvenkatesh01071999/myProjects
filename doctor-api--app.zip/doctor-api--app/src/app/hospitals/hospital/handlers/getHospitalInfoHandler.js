const hospitalServices = require("../services/getHospitalService");

function getHospitalInfoHandler(fastify) {
  const getHospitalInfo = hospitalServices.getHospitalInfoService(fastify);
  return async (request, reply) => {
    const { body, params, query, logTrace } = request;
    const response = await getHospitalInfo({ body, params, query, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHospitalInfoHandler;
