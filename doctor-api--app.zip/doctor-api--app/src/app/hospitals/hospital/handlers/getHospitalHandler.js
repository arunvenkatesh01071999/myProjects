const hospitalServices = require("../services/getHospitalService");

function getHospitalHandler(fastify) {
  const getHospital = hospitalServices.getHospitalService(fastify);
  return async (request, reply) => {
    const { body, params, query, logTrace } = request;
    const response = await getHospital({ body, params, query, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHospitalHandler;
