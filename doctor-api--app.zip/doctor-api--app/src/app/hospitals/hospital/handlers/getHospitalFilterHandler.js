const hospitalServices = require("../services/getHospitalService");

function getHospitalFilterHandler(fastify) {
  const getHospitalFilter = hospitalServices.getHospitalFilterService(fastify);
  return async (request, reply) => {
    const { body, params, query, logTrace } = request;
    const response = await getHospitalFilter({ body, params, query, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHospitalFilterHandler;
