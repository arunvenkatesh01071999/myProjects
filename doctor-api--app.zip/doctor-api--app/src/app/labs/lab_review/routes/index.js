const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/lab/review",
    schema: schemas.postLabReviewSchema,
    handler: handlers.postLabReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/review/:lab_id",
    schema: schemas.getLabReviewSchema,
    handler: handlers.getLabReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/admin/review/:lab_id",
    schema: schemas.getLabReviewSchema,
    handler: handlers.getLabAdminReviewHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/lab/review/disable",
    schema: schemas.postDisableLabReviewSchema,
    handler: handlers.postDisableLabReviewHandler(fastify)
  });
};
