const postLabReviewSchema = require("./postLabReviewSchema");
const getLabReviewSchema = require("./getLabReviewSchema");
const postDisableLabReviewSchema = require("./postDisableLabReviewSchema");

module.exports = {
  postLabReviewSchema,
  getLabReviewSchema,
  postDisableLabReviewSchema
};
