const getLabReviewServices = require("../services/getLabReviewServices");

function getLabReviewHandler(fastify) {
  const getReview = getLabReviewServices(fastify);
  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getReview({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getLabReviewHandler;
