const getLabAdminReviewServices = require("../services/getLabAdminReviewServices");

function getLabAdminReviewHandler(fastify) {
  const getAdminReview = getLabAdminReviewServices(fastify);
  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getAdminReview({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getLabAdminReviewHandler;
