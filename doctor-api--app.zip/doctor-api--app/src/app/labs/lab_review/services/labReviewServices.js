const labReviewRepo = require("../repository/labReview");
const getLabReviewServices = require("./getLabReviewServices");
function labReviewServices(fastify) {
  const { postReview } = labReviewRepo(fastify);
  const calculateReview = getLabReviewServices(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const { lab_id, patient_id, comments, rating } = body;

    const response = await postReview.call(knex, {
      logTrace,
      input: {
        lab_id,
        patient_id,
        comments,
        rating
      }
    });

    calculateReview({
      logTrace,
      params: {
        lab_id
      }
    });
    return response;
  };
}
module.exports = labReviewServices;
