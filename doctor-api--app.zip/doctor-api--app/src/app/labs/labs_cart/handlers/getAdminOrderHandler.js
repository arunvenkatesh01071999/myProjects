const getOrderService = require("../services/getOrderServices");

function getAdminOrderHandler(fastify) {
  const getAdminOrder = getOrderService.getAdminOrderService(fastify);
  return async (request, reply) => {
    const { body, params, query, logTrace, userDetails } = request;
    const response = await getAdminOrder({
      body,
      params,
      query,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = getAdminOrderHandler;
