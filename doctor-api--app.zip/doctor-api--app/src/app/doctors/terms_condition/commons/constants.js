const TERMSANDCONDITION = {
  NAME: "d_terms_and_condition",
  COLUMNS: {
    ID: "id",
    IS_TERM: "is_term",
    IS_POLCY: "is_policy",
    DESCRIPTION: "description",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  TERMSANDCONDITION
};
