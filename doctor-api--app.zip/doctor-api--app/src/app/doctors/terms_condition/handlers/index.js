const getTermsAndConditionHandler = require("./getTermsAndConditionHandler.js");

module.exports = {
  getTermsAndConditionHandler
};
