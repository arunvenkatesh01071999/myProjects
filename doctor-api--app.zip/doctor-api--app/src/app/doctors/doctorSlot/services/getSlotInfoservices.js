// const SlotInfoRepos = require("../repository/SlotInfoRepos");
// const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");
// const { DOCTORAVILSLOTINFO } = require("../commons/constants");


// function getallSlotService(fastify) {
//   const { getslotall } = SlotInfoRepos.SlotAllRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getslotall.call(knex, {
//       logTrace
//     });
//     const [getslotalldata] = await Promise.all([promise1]);
//     return getslotalldata;
//   };
// }

// function getByIdSlotService(fastify) {
//   const { getslotById } = SlotInfoRepos.SlotGetByIdRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getslotById.call(knex, {
//       logTrace, body, params
//     });
//     const [getslotByIddata] = await Promise.all([promise1]);
//     return getslotByIddata;
//   };
// }


// function getSlotService(fastify) {

//   const { getSlotadd } = SlotInfoRepos.SlotaddRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;

//     var data = body.day;
//     Object.keys(data).forEach(day => {
//       const timings = data[day];
//       const slot_active = timings.slot_active;
//       const slot_1 = timings.slot_1;
//       const slot_2 = timings.slot_2;
//       const slot_3 = timings.slot_3;
//       const is_24hrs = timings.is_24hrs;
//       sl_data = {
//         doctor_name_id: parseInt(body.doctor_name_id),
//         day: `${day}`,
//         slot_1: `${slot_1.join(',')}`,
//         slot_2: `${slot_2.join(',')}`,
//         slot_3: `${slot_3.join(',')}`,
//         slot_active: slot_active,
//         is_24hrs: is_24hrs,
//         check_walking: body.check_walking,
//         duration: body.duration,
//         instant_consulation: body.instant_consulation,
//         video: body.video,
//         walkin: body.walkin,
//         active: body.active,
//         created_by: body.created_by
//       }
//       const promise1 = getSlotadd.call(knex, {
//         logTrace, params,
//         body, sl_data
//       });

//     });
//     return { success: true, message: "Insert successfully" };

//   };
// }


// function getPutRegService(fastify) {
//   const { getslotput } = SlotInfoRepos.SlotputRepo(fastify);

//   return async ({ body, params, logTrace, userDetails, convertedData }) => {
//     const knex = fastify.knexMaster;
//     const { id } = params;


//     const query1 = knex(`${DOCTORAVILSLOTINFO.NAME}`)
//       .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .del();

//     const response1 = await query1;

//     if (response1) {
//       var data = body.day;
//       Object.keys(data).forEach(day => {
//         const timings = data[day];
//         const slot_active = timings.slot_active;
//         const slot_1 = timings.slot_1;
//         const slot_2 = timings.slot_2;
//         const slot_3 = timings.slot_3;
//         const is_24hrs = timings.is_24hrs;
//         sl_data = {
//           doctor_name_id: parseInt(body.doctor_name_id),
//           day: `${day}`,
//           slot_1: `${slot_1.join(',')}`,
//           slot_2: `${slot_2.join(',')}`,
//           slot_3: `${slot_3.join(',')}`,
//           slot_active: slot_active,
//           is_24hrs: is_24hrs,
//           check_walking: body.check_walking,
//           duration: body.duration,
//           instant_consulation: body.instant_consulation,
//           video: body.video,
//           walkin: body.walkin,
//           active: body.active,
//           created_by: body.created_by
//         }
//         // console.log(sl_data, "sl_dataaaaaaaaaa");
//         const promise1 = getslotput.call(knex, {
//           logTrace, params,
//           body, sl_data
//         });

//       });
//     }
//     else {
//       return { success: false, message: "Doctor ID Have Not Exist" };
//     }

//     return { success: true, message: "Updated successfully" };

//   };
// }


// function getallSlotReturnService(fastify) {
//   const { getslotReturn } = SlotInfoRepos.SlotgetReturnRepo(fastify);
//   return async ({ body, logTrace }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getslotReturn.call(knex, {
//       logTrace,
//       body
//     });
//     const [getslotalldata] = await Promise.all([promise1]);
//     return getslotalldata;
//   };
// }

// // function getDeleteRegService(fastify) {
// //   const { getregdelete } =
// //     RegBasicInfo.RegDeleteRepo(fastify);
// //   return async ({ body, params, logTrace, userDetails }) => {
// //     const knex = fastify.knexMaster;
// //     const promise1 = getregdelete.call(knex, {
// //       logTrace,
// //       body,
// //       params,
// //       userDetails
// //     });
// //     const [getregdeletedata] = await Promise.all([promise1]);
// //     return getregdeletedata;
// //   };
// // }

// //       function getGenerateotpService(fastify) {
// //   const { getotp } =
// //     RegBasicInfo.generateotpRepo(fastify);
// //   return async ({ body, params, logTrace, userDetails }) => {
// //     const knex = fastify.knexMaster;
// //     const promise1 = getotp.call(knex, {
// //       // logTrace,
// //       body,
// //       params,
// //       userDetails
// //     });
// //     const phone = body.mobile;
// //     // if (!phone.match(phoneRegex)) {
// //     //   return "invalid phone number";
// //     // }
// //     try {
// //       const [getregdeletedata] = await Promise.all([promise1]);
// //       return getregdeletedata;
// //     } catch (error) {
// //       console.error(error);
// //       res.status(500).json({ message: 'Failed to generate OTP.' });
// //     }
// //   };
// // }

// module.exports = {
//   getallSlotService,
//   getByIdSlotService,
//   getSlotService,
//   getPutRegService,
//   getallSlotReturnService
//   // getDeleteRegService,
//   // getGenerateotpService
// };


const SlotInfoRepos = require("../repository/SlotInfoRepos");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");
const { DOCTORAVILSLOTINFO } = require("../commons/constants");


function getallSlotService(fastify) {
  const { getslotall } = SlotInfoRepos.SlotAllRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getslotall.call(knex, {
      logTrace
    });
    const [getslotalldata] = await Promise.all([promise1]);
    return getslotalldata;
  };
}

function getByIdSlotService(fastify) {
  const { getslotById } = SlotInfoRepos.SlotGetByIdRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getslotById.call(knex, {
      logTrace, body, params
    });
    const [getslotByIddata] = await Promise.all([promise1]);
    return getslotByIddata;
  };
}


// function getSlotService(fastify) {

//   const { getSlotadd } = SlotInfoRepos.SlotaddRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;

//     var data = body.day;
//     Object.keys(data).forEach(day => {
//       const timings = data[day];
//       const slot_active = timings.slot_active;
//       const slot_1 = timings.slot_1;
//       const slot_2 = timings.slot_2;
//       const slot_3 = timings.slot_3;
//       const is_24hrs = timings.is_24hrs;
//       sl_data = {
//         doctor_name_id: parseInt(body.doctor_name_id),
//         day: `${day}`,
//         slot_1: `${slot_1.join(',')}`,
//         slot_2: `${slot_2.join(',')}`,
//         slot_3: `${slot_3.join(',')}`,
//         slot_active: slot_active,
//         is_24hrs: is_24hrs,
//         check_walking: body.check_walking,
//         duration: body.duration,
//         instant_consulation: body.instant_consulation,
//         video: body.video,
//         walkin: body.walkin,
//         active: body.active,
//         created_by: body.created_by
//       }
//       const promise1 = getSlotadd.call(knex, {
//         logTrace, params,
//         body, sl_data
//       });

//     });
//     return { success: true, message: "Insert successfully" };

//   };
// }


// function getPutRegService(fastify) {
//   const { getslotput } = SlotInfoRepos.SlotputRepo(fastify);

//   return async ({ body, params, logTrace, userDetails, convertedData }) => {
//     const knex = fastify.knexMaster;
//     const { id } = params;


//     const query1 = knex(`${DOCTORAVILSLOTINFO.NAME}`)
//       .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .del();

//     const response1 = await query1;

//     if (response1) {
//       var data = body.day;
//       Object.keys(data).forEach(day => {
//         const timings = data[day];
//         const slot_active = timings.slot_active;
//         const slot_1 = timings.slot_1;
//         const slot_2 = timings.slot_2;
//         const slot_3 = timings.slot_3;
//         const is_24hrs = timings.is_24hrs;
//         sl_data = {
//           doctor_name_id: parseInt(body.doctor_name_id),
//           day: `${day}`,
//           slot_1: `${slot_1.join(',')}`,
//           slot_2: `${slot_2.join(',')}`,
//           slot_3: `${slot_3.join(',')}`,
//           slot_active: slot_active,
//           is_24hrs: is_24hrs,
//           check_walking: body.check_walking,
//           duration: body.duration,
//           instant_consulation: body.instant_consulation,
//           video: body.video,
//           walkin: body.walkin,
//           active: body.active,
//           created_by: body.created_by
//         }
//         // console.log(sl_data, "sl_dataaaaaaaaaa");
//         const promise1 = getslotput.call(knex, {
//           logTrace, params,
//           body, sl_data
//         });

//       });
//     }
//     else {
//       return { success: false, message: "Doctor ID Have Not Exist" };
//     }

//     return { success: true, message: "Updated successfully" };

//   };
// }

function getSlotService(fastify) {
  const { getSlotadd } = SlotInfoRepos.SlotaddRepo(fastify);
  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = getSlotadd.call(knex, {
      logTrace, params,
      body
  });
  const [getslotalldata] = await Promise.all([promise1]);
  return getslotalldata;
  };
}

function getPutRegService(fastify) {
  const { getslotput } = SlotInfoRepos.SlotputRepo(fastify);
  return async ({ body, params, logTrace, userDetails, convertedData }) => {
    const knex = fastify.knexMaster;
    const { doctor_name_id } = params;
    const query1 = knex(`${DOCTORAVILSLOTINFO.NAME}`)
      .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, doctor_name_id)
      .del();
    const response1 = await query1;
    if (response1) {
      var data = body.day;
      Object.keys(data).forEach(day => {
        const timings = data[day];
        const slot_active = timings.slot_active;
        const slot_1 = timings.slot_1;
        const slot_2 = timings.slot_2;
        const slot_3 = timings.slot_3;
        const is_24hrs = timings.is_24hrs;
        sl_data = {
          doctor_name_id: parseInt(body.doctor_name_id),
          day: `${day}`,
          slot_1: `${slot_1.join(',')}`,
          slot_2: `${slot_2.join(',')}`,
          slot_3: `${slot_3.join(',')}`,
          slot_active: slot_active,
          is_24hrs: is_24hrs,
          check_walking: body.check_walking,
          duration: body.duration,
          instant_consulation: body.instant_consulation,
          video: body.video,
          walkin: body.walkin,
          active: body.active,
          created_by: body.created_by
        }
        const promise1 = getslotput.call(knex, {
          logTrace, params,
          body, sl_data
        });
      });
    }
    else {
      return { success: false, message: "Doctor ID Does Not Exist" };
    }
    return { success: true, message: "Updated successfully" };
  };
}


function getallSlotReturnService(fastify) {
  const { getslotReturn } = SlotInfoRepos.SlotgetReturnRepo(fastify);
  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = getslotReturn.call(knex, {
      logTrace,
      body
    });
    const [getslotalldata] = await Promise.all([promise1]);
    return getslotalldata;
  };
}

// function getDeleteRegService(fastify) {
//   const { getregdelete } =
//     RegBasicInfo.RegDeleteRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getregdelete.call(knex, {
//       logTrace,
//       body,
//       params,
//       userDetails
//     });
//     const [getregdeletedata] = await Promise.all([promise1]);
//     return getregdeletedata;
//   };
// }

//       function getGenerateotpService(fastify) {
//   const { getotp } =
//     RegBasicInfo.generateotpRepo(fastify);
//   return async ({ body, params, logTrace, userDetails }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getotp.call(knex, {
//       // logTrace,
//       body,
//       params,
//       userDetails
//     });
//     const phone = body.mobile;
//     // if (!phone.match(phoneRegex)) {
//     //   return "invalid phone number";
//     // }
//     try {
//       const [getregdeletedata] = await Promise.all([promise1]);
//       return getregdeletedata;
//     } catch (error) {
//       console.error(error);
//       res.status(500).json({ message: 'Failed to generate OTP.' });
//     }
//   };
// }

module.exports = {
  getallSlotService,
  getByIdSlotService,
  getSlotService,
  getPutRegService,
  getallSlotReturnService
  // getDeleteRegService,
  // getGenerateotpService
};