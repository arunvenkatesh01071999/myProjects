const getCheifComplaintsHandler = require("./getCheifComplaintsHandler.js");

module.exports = {
  getCheifComplaintsHandler
};
