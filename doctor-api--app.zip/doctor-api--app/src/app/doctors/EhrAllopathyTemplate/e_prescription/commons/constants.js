const PRESCRIPTION = {
  NAME: "e_e_prescription",
  COLUMNS: {
    ID: "id",
    MEDICINE_NAME: "medicine_name",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const PRESCRIPTIONMEDICINE = {
  NAME: "e_e_prescription_medicine",
  COLUMNS: {
    ID: "id",
    MEDICINE_ID: "medicine_id",
    QUANTITY: "quantity",
    FREQUENCY: "frequency",
    TIMING: "timing",
    DURATION: "duration",
    INSTRUCTION: "instruction",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const MEDICINE = {
  NAME: "medicine_list",
  COLUMNS: {
    ID: "id",
    MEDICINE_NAME: "medicine_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
  }
}


module.exports = {
 PRESCRIPTION,
 PRESCRIPTIONMEDICINE,
 MEDICINE
};
