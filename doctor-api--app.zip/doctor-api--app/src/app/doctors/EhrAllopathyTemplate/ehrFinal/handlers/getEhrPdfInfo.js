const getEhrPdfService = require("../services/getEhrPdfInfo");

function getEhrPdfInfoHandler(fastify) {

  const getEhrPdfInfo = getEhrPdfService.getEhrPdfInfoService(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getEhrPdfInfo({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

module.exports = {
  getEhrPdfInfoHandler
}