const getPastMedicalHistorySchema = require("./getPastMedicalHistory");

module.exports = {
  getPastMedicalHistorySchema
};
