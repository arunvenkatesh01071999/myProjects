const getPastMedicalHistoryHandler = require("./getPastMedicalHistoryHandler.js");

module.exports = {
  getPastMedicalHistoryHandler
};
