const getClinicalExamSchema = require("./getClinicalExam");

module.exports = {
  getClinicalExamSchema
};
