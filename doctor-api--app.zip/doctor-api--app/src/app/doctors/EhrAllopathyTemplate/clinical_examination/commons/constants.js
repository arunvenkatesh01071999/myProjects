const CLINICALEXAM = {
  NAME: "e_clinical_examination",
  COLUMNS: {
    ID: "id",
    TEMPERATURE: "temperature",
    PULSE : "pulse",
    RESPIRATORY_RATE : "respiratory_rate",
    SP : "sp",
    HEART_RATE : "heart_rate",
    BLOOD_SYSTOLIC : "blood_systolic",
    BLOOD_DIASTOLIC : "blood_diastolic",
    HEIGHT : "height",
    WEIGHT : "weight",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CLINICAL_EXAMINATION : "clinical_examination",
    
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  CLINICALEXAM
};
