const getFinalDiagnosisHandler = require("./getFinalDiagnosisHandler.js");

module.exports = {
  getFinalDiagnosisHandler
};
