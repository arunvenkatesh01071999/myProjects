const getFinalDiagnosisService = require("../services/getFinalDiagnosisService");



function createFinalDiagnosisHandler(fastify) {
  
  const createFinalDiagnosis =
  getFinalDiagnosisService.createFinalDiagnosisServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await createFinalDiagnosis({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function updateFinalDiagnosisHandler(fastify) {
  const updateFinalDiagnosis = getFinalDiagnosisService.updateFinalDiagnosisServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await updateFinalDiagnosis({
      body,
      params,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getFinalDiagnosisHandler(fastify) {

  const getFinalDiagnosis = getFinalDiagnosisService.getFinalDiagnosisInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getFinalDiagnosis({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getFinalDiagnosisHandlerId(fastify) {

  const getFinalDiagnosis = getFinalDiagnosisService.getFinalDiagnosisInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getFinalDiagnosis({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deleteFinalDiagnosisHandler(fastify) {

  const deleteFinalDiagnosis = getFinalDiagnosisService.deleteFinalDiagnosisServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deleteFinalDiagnosis({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createFinalDiagnosisHandler,
  updateFinalDiagnosisHandler,
  getFinalDiagnosisHandler,
  getFinalDiagnosisHandlerId,
  deleteFinalDiagnosisHandler
};
