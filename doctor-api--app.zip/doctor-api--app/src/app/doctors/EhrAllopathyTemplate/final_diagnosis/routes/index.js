const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/final-diagnosis",
    preHandler: fastify.authenticate,
     schema: schemas.getFinalDiagnosisSchema.createFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.createFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/final-diagnosis/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getFinalDiagnosisSchema.updateFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.updateFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/final-diagnosis",
    preHandler: fastify.authenticate,
    schema: schemas.getFinalDiagnosisSchema.getFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.getFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/final-diagnosis/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
   schema: schemas.getFinalDiagnosisSchema.getFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.getFinalDiagnosisHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/final-diagnosis/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
   schema: schemas.getFinalDiagnosisSchema.deleteFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.deleteFinalDiagnosisHandler(fastify)
  });

};
