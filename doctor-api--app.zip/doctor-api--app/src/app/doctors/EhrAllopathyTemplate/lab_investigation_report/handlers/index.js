const getLabInvestigationReportHandler = require("./getLabInvestigationReportHandler.js");

module.exports = {
  getLabInvestigationReportHandler
};
