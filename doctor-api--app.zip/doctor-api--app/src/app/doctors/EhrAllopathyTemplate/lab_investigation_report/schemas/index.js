const getLabInvestigationReportSchema = require("./getLabInvestigationReportSchema");

module.exports = {
  getLabInvestigationReportSchema
};
