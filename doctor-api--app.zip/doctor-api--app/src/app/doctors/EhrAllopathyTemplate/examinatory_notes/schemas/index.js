const getExaminatoryNotesSchema = require("./getExaminatoryNotes");

module.exports = {
  getExaminatoryNotesSchema
};
