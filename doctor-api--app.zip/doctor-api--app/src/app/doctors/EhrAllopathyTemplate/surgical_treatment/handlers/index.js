const getSurgicalTreatmentHandler = require("./getSurgicalTreatmentHandler.js");

module.exports = {
  getSurgicalTreatmentHandler
};
