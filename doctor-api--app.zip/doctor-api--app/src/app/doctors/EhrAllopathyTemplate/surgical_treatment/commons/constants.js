const SURGICAL = {
  NAME: "e_surgical_treatment",
  COLUMNS: {
    ID: "id",
    LIST_NAME: "list_name",
    SURGICAL_HOSPITAL_LINK: "surgical_hospital_link",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  SURGICAL
};
