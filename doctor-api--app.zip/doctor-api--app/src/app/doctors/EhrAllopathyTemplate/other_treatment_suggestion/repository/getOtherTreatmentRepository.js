const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../../../src/app/commons/helpers");
const { OTHERTREATMENT } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");



function getOtherTreatmentRepository(fastify) {
  
  async function OtherTreatmentGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.raw(`SELECT TOP 5 * FROM [dbo].[e_other_treatment] ORDER BY id DESC;`)


    logQuery({
      logger: fastify.log,
      query,
      context: "Get Other Treatment suggestion details",
      logTrace
    });
    const response = await query;
    
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Other Treatment suggestion  not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    OtherTreatmentGetAlls
  };

}




module.exports = {
  
  getOtherTreatmentRepository


};
