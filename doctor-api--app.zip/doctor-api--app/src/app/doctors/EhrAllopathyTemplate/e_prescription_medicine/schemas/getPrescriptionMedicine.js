
const { errorSchemas } = require("../../../../commons/schemas/errorSchemas");


const createPrescriptionSchema = {
  tags: ["POST Prescription"],
  summary: "This API is to Post Prescription ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "medicine_name",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {
      // medicine_name: { type: "string" },
      medicine_name: {
        type: "array",
        items: {
          type: "string"
        }
      },
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updatePrescriptionSchema = {
  tags: ["PUT Prescription"],
  summary: "This API is to Update Prescription ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      patient_id: { type: 'integer' },
    },
    required: ['patient_id'],
  },
  body: {
    type: "object",
    required: [
      "medicine_name",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {
      // medicine_name: { type: "string" },
      medicine_name: {
        type: "array",
        items: {
          type: "string"
        }
      },
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getPrescriptionSchema = {

  tags: ["GET Prescription"],
  summary: "This API is to get Prescription ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          medicine_name: { type: "string" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deletePrescriptionSchema = {
  tags: ["DELETE Prescription"],
  summary: "This API is to delete Prescription ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createPrescriptionSchema,
  updatePrescriptionSchema,
  getPrescriptionSchema,
  deletePrescriptionSchema
};
