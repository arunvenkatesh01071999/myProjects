const PRESCRIPTIONMEDICINE = {
  NAME: "e_e_prescription_medicine",
  COLUMNS: {
    ID: "id",
    MEDICINE_ID: "medicine_id",
    MEDICINE_NAME: "medicine_name",
    FINAL_DIAGNOSIS_ID: "final_diagnosis_id",
    QUANTITY: "quantity",
    FREQUENCY: "frequency",
    FREQUENCYNOTES:"frequencynotes",
    TIMING: "timing",
    TIMINGNOTES:"timingnotes",
    DURATION: "duration",
    INSTRUCTION: "instruction",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};


const EHRUNIQUE = {
  NAME: "e_ehrunique",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  PRESCRIPTIONMEDICINE,
  EHRUNIQUE
};
