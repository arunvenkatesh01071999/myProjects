const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {


  fastify.route({
    method: "POST",
    url: "/e-ehruniqueget",
    // preHandler: fastify.authenticate,
    // schema: schemas.getPrescriptionMedicineSchema.createPrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.ehruniquegetHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/e-prescription-medicine",
    // preHandler: fastify.authenticate,
    // schema: schemas.getPrescriptionMedicineSchema.createPrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.createPrescriptionMedicineHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/e-prescription-medicine/:id",
    // preHandler: fastify.authenticate,
    // schema: schemas.getPrescriptionMedicineSchema.updatePrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.updatePrescriptionMedicineHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/e-prescription-medicine/:final_diagnosis_id",
    // preHandler: fastify.authenticate,
    // schema: schemas.getPrescriptionMedicineSchema.getPrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.getPrescriptionMedicineHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/getOne_e-prescription-medicine/:id",
  //   preHandler: fastify.authenticate,
  //  schema: schemas.getPrescriptionMedicineSchema.getPrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.getPrescriptionMedicineHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/e-prescription-medicine/:id",
  //   preHandler: fastify.authenticate,
  //  schema: schemas.getPrescriptionMedicineSchema.deletePrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.deletePrescriptionMedicineHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/e-prescription-medicine/deleteAll/:final_diagnosis_id",
  //   preHandler: fastify.authenticate,
  //  schema: schemas.getPrescriptionMedicineSchema.deletePrescriptionMedicineSchema,
    handler: handlers.getPrescriptionMedicineHandler.deleteAllPrescriptionMedicineHandler(fastify)
  });

};
