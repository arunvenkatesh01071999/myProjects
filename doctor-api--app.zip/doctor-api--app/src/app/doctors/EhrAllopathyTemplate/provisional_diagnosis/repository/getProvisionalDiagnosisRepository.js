const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../../../src/app/commons/helpers");
const {PROVISIONAL} = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postProvisionalDiagnosisRepositoryBasic(fastify) {
  async function ProvisionalDiagnosisAdd({ logTrace, body }) {
    const knex = this;


    const provisional = body.list_name;
    
    let provisionalResult = provisional.join(",")

    const query = await knex(`${PROVISIONAL.NAME}`).insert({

      [PROVISIONAL.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [PROVISIONAL.COLUMNS.PATIENT_ID]: body.patient_id,
      [PROVISIONAL.COLUMNS.ACTIVE]: body.active,
      [PROVISIONAL.COLUMNS.LIST_NAME]: provisionalResult,
      [PROVISIONAL.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    ProvisionalDiagnosisAdd

  };
}

function updateProvisionalDiagnosisRepository(fastify) {
  async function ProvisionalDiagnosisUpdate({ logTrace, body, params }) {
    const knex = this;
    // const { patient_id } = params;
    const  patient_id = params.patient_id;
    const doctor_id = body.doctor_id

    const clinicalExaminationGetID = await knex.raw(`select top 1 id from e_provisional_diagnosis where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation=0 order By id desc`)
    const id=clinicalExaminationGetID[0].id

    const provisional = body.list_name;
    
    let provisionalResult = provisional.join(",");


    const query = await knex(`${PROVISIONAL.NAME}`)
      .where(`${PROVISIONAL.COLUMNS.ID}`,id)
      .update({
        [PROVISIONAL.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [PROVISIONAL.COLUMNS.PATIENT_ID]: body.patient_id,
      [PROVISIONAL.COLUMNS.ACTIVE]: body.active,
        [PROVISIONAL.COLUMNS.LIST_NAME]: provisionalResult,
        [PROVISIONAL.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    ProvisionalDiagnosisUpdate,
  };
}

function getProvisionalDiagnosisRepository(fastify) {
  
  async function ProvisionalDiagnosisGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${PROVISIONAL.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get provisional_diagnosis details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "provisional_diagnosis info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    ProvisionalDiagnosisGetAlls
  };

}


function getProvisionalDiagnosisRepositoryId(fastify) {
  
  async function ProvisionalDiagnosisGetOne({ logTrace, params }) {
    
    const knex = this;
    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;

    // const query = knex.select('*').from(`${PROVISIONAL.NAME}`).where(`${PROVISIONAL.COLUMNS.PATIENT_ID}`, patient_id);
    const query = knex.raw(`select top 1 * from e_provisional_diagnosis  where patient_id =${patient_id} and doctor_id =${doctor_id} and end_consultation=0 order BY id desc`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get provisional_diagnosis details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "provisional_diagnosis info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    ProvisionalDiagnosisGetOne
  };

}

function deleteProvisionalDiagnosisRepositoryId(fastify) {
  async function ProvisionalDiagnosisDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  patient_id  = params.patient_id;
    const doctor_id  = params.doctor_id;

    const clinicalExaminationGetID = await knex.raw(`select top 1 id from e_provisional_diagnosis where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation=0 order By id desc`)
    const id=clinicalExaminationGetID[0].id

    const query = await knex(`${PROVISIONAL.NAME}`).where(`${PROVISIONAL.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    ProvisionalDiagnosisDelete
  };
}


module.exports = {
  postProvisionalDiagnosisRepositoryBasic,
  updateProvisionalDiagnosisRepository,
  getProvisionalDiagnosisRepository,
  getProvisionalDiagnosisRepositoryId,
  deleteProvisionalDiagnosisRepositoryId

};
