const getProvisionalDiagnosisSchema = require("./getProvisionalDiagnosis");

module.exports = {
  getProvisionalDiagnosisSchema
};
