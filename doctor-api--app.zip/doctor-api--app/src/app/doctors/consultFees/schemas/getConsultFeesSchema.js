const { errorSchemas } = require('../../../../app/commons/schemas/errorSchemas');

const createConsultFeesSchema = {
  tags: ["POST ConsultFees"],
  summary: "This API is to Post ConsultFees ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      
        'doctor_id', 'video_consulting_fee', 'v_display_amt', 'v_platform_charge', 'v_how_mouch_you_get',
        'walk_consulting_fee', 'w_display_amt', 'w_platform_charge', 'w_how_mouch_you_get',
        'instant_consulting_fee', 'i_display_amt', 'i_platform_charge', 'i_how_mouch_you_get',
        'second_opinion_fee', 's_display_amt', 's_platform_charge', 's_how_mouch_you_get',
        'chat_consulting_fee', 'c_display_amt', 'c_platform_charge', 'c_how_mouch_you_get',
        'check', 'active'
    ],
    additionalProperties: false,
    properties: {
        doctor_id: { type: 'integer' },
      video_consulting_fee: { type: 'integer' },
      v_display_amt: { type: 'integer' },
      v_platform_charge: { type: 'integer' },
      v_how_mouch_you_get: { type: 'integer' },
      walk_consulting_fee: { type: 'integer' },
      w_display_amt: { type: 'integer' },
      w_platform_charge: { type: 'integer' },
      w_how_mouch_you_get: { type: 'integer' },
      instant_consulting_fee: { type: 'integer' },
      i_display_amt: { type: 'integer' },
      i_platform_charge: { type: 'integer' },
      i_how_mouch_you_get: { type: 'integer' },
      second_opinion_fee: { type: 'integer' },
      s_display_amt: { type: 'integer' },
      s_platform_charge: { type: 'integer' },
      s_how_mouch_you_get: { type: 'integer' },
      chat_consulting_fee: { type: 'integer' },
      c_display_amt: { type: 'integer' },
      c_platform_charge: { type: 'integer' },
      c_how_mouch_you_get: { type: 'integer' },
      check: { type: 'integer' },
      active: { type: 'integer' }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateConsultFeesSchema = {
  tags: ["PUT ConsultFees"],
  summary: "This API is to Update ConsultFees ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
        doctor_id: { type: 'integer' },
    },
    required: ['doctor_id'],
  },
  body: {
    type: "object",
    required: [
        'doctor_id', 'video_consulting_fee', 'v_display_amt', 'v_platform_charge', 'v_how_mouch_you_get',
        'walk_consulting_fee', 'w_display_amt', 'w_platform_charge', 'w_how_mouch_you_get',
        'instant_consulting_fee', 'i_display_amt', 'i_platform_charge', 'i_how_mouch_you_get',
        'second_opinion_fee', 's_display_amt', 's_platform_charge', 's_how_mouch_you_get',
        'chat_consulting_fee', 'c_display_amt', 'c_platform_charge', 'c_how_mouch_you_get',
        'check', 'active'
    ],
    additionalProperties: false,
    properties: {
        doctor_id: { type: 'integer' },
        video_consulting_fee: { type: 'integer' },
        v_display_amt: { type: 'integer' },
        v_platform_charge: { type: 'integer' },
        v_how_mouch_you_get: { type: 'integer' },
        walk_consulting_fee: { type: 'integer' },
        w_display_amt: { type: 'integer' },
        w_platform_charge: { type: 'integer' },
        w_how_mouch_you_get: { type: 'integer' },
        instant_consulting_fee: { type: 'integer' },
        i_display_amt: { type: 'integer' },
        i_platform_charge: { type: 'integer' },
        i_how_mouch_you_get: { type: 'integer' },
        second_opinion_fee: { type: 'integer' },
        s_display_amt: { type: 'integer' },
        s_platform_charge: { type: 'integer' },
        s_how_mouch_you_get: { type: 'integer' },
        chat_consulting_fee: { type: 'integer' },
        c_display_amt: { type: 'integer' },
        c_platform_charge: { type: 'integer' },
        c_how_mouch_you_get: { type: 'integer' },
        check: { type: 'integer' },
        active: { type: 'integer' }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getConsultFeesSchema = {

  tags: ["GET ConsultFees"],
  summary: "This API is to get ConsultFees ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
            doctor_id: { type: 'integer' },
            video_consulting_fee: { type: 'integer' },
            v_display_amt: { type: 'integer' },
            v_platform_charge: { type: 'integer' },
            v_how_mouch_you_get: { type: 'integer' },
            walk_consulting_fee: { type: 'integer' },
            w_display_amt: { type: 'integer' },
            w_platform_charge: { type: 'integer' },
            w_how_mouch_you_get: { type: 'integer' },
            instant_consulting_fee: { type: 'integer' },
            i_display_amt: { type: 'integer' },
            i_platform_charge: { type: 'integer' },
            i_how_mouch_you_get: { type: 'integer' },
            second_opinion_fee: { type: 'integer' },
            s_display_amt: { type: 'integer' },
            s_platform_charge: { type: 'integer' },
            s_how_mouch_you_get: { type: 'integer' },
            chat_consulting_fee: { type: 'integer' },
            c_display_amt: { type: 'integer' },
            c_platform_charge: { type: 'integer' },
            c_how_mouch_you_get: { type: 'integer' },
            check: { type: 'integer' },
            active: { type: 'integer' }
        }
      }
    },
    ...errorSchemas
  }
};



module.exports = {

  createConsultFeesSchema,
  updateConsultFeesSchema,
  getConsultFeesSchema
};
