const consultInfoRepos = require("../repository/getConsultFeesRepo");

function getConsultPostInfoService(fastify) {

  const { getConsultAdd } = consultInfoRepos.getConsultFeesReposCreate(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getConsultAdd.call(knex, {
      logTrace,
      body
    });
    const [getConsultService] = await Promise.all([promise1]);

    return getConsultService;
  }
}

function getallConsultFeesService(fastify) {
  const { getConsultFeesall } = consultInfoRepos.getConsultFeesReposGet(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getConsultFeesall.call(knex, {
      logTrace
    });
    const [getConsultFeesealldata] = await Promise.all([promise1]);
    return getConsultFeesealldata;
  };
}


function getByIdConsultFeesService(fastify) {
  const { getConsultFeesById } = consultInfoRepos.getConsultFeesReposGetId(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getConsultFeesById.call(knex, {
      logTrace, body, params
    });
    const [getConsultFeesByIddata] = await Promise.all([promise1]);
    return getConsultFeesByIddata;
  };
}




function getConsultPutInfoService(fastify) {

  const { getConsultAdd } = consultInfoRepos.getConsultFeesReposPut(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getConsultAdd.call(knex, {
      logTrace,
      body,
      params
    });
    const [getConsultService] = await Promise.all([promise1]);

    return getConsultService;
  }
}


module.exports = {
  getConsultPostInfoService,
  getallConsultFeesService,
  getByIdConsultFeesService,
  getConsultPutInfoService

}