const getTodayAppintmentDetailsRepository = require("../repository/getTodayAppintmentDetailsRepository");





function getTodayAppintmentDetailsInfoServicePost(fastify) {

  const { TodayAppintmentDetailsGetOne } = getTodayAppintmentDetailsRepository.getTodayAppintmentDetailsRepositoryPost(fastify);

  return async ({ params, logTrace,body }) => {
    const knex = fastify.knexMaster;
    const promise1 = TodayAppintmentDetailsGetOne.call(knex, {
      logTrace,body,
      params
    });
    const [getTodayAppintmentDetailsOnedata] = await Promise.all([promise1]);
    return getTodayAppintmentDetailsOnedata;
  }
}




module.exports = {



  getTodayAppintmentDetailsInfoServicePost
  

};
