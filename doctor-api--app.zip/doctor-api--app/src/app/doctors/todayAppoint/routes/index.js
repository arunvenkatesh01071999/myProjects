const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/today-appointment-details",
    // preHandler: fastify.authenticate,
    //  schema: schemas.getTodayAppintmentDetailsSchema.getTodayAppintmentDetailsSchema,
    handler: handlers.getTodayAppintmentDetailsHandler.getTodayAppintmentDetailsHandlerPost(fastify)
  });







};
