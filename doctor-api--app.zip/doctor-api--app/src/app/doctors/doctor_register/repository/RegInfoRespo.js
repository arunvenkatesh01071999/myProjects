const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { REGISTERINFO } = require("../commons/constants");
const { ADDRESSINFO } = require("../commons/constants");
const { LANGUAGEINFO } = require("../commons/constants");
const sms = require("../../../notification/repository/sms");
const nodemailer = require("nodemailer");
const previewEmail = require("preview-email");
const UploadImageService = require("../../../commons/imageupload");
const { CustomError } = require("../../../errorHandler");
const moment = require("moment/moment");
const addCheck = require("../../../commons/addcheck");

// function RegAllRepo(fastify) {
//   async function getregeall({ logTrace }) {
//     const knex = this;

//     const query = knex.select(`*`).from(`${REGISTERINFO.NAME}`);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get DOC Register details",
//       logTrace
//     });

//     const response = await query;
//     if (!response.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "Register info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return response;
//   }

//   return {
//     getregeall
//   };
// }

// function RegGetByIdRepo(fastify) {
//   async function getregById({ logTrace, body, params }) {
//     const knex = this;
//     const id = params.id;

//     const query = knex.select(`*`).from(`${REGISTERINFO.NAME}`).where(`${REGISTERINFO.COLUMNS.ID}`, id);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get Register details",
//       logTrace
//     });

//     const response = await query;
//     if (!response.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "Register info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return response;
//   }

//   return {
//     getregById
//   };
// }

function RegAllRepo(fastify) {
  async function getregeall({ logTrace }) {
    const knex = this;
    const query =
      knex.raw(`select  a.id,a.doctor_name,a.gender_id,a.speciality_id,a.email,a.phone_no,a.dob,a.image_path,a.about,a.age,
    a.signature_path,a.reason,a.update_on_whatsapp,a.workplacetype,b.address1,b.address2,b.city_id,b.country_id,b.latitude,b.latitude1,
    b.longitude,b.longitude1,b.pincode,b.pincode1,b.state_id,
    STRING_AGG(c.language_name_id, ', ') AS language_name_id from d_doctor_basic_info as a
    left join d_address_info as b on  a.id=b.doctor_name_id
    left join d_language_info as c on c.doctor_name_id=a.id and c.doctor_name_id=b.doctor_name_id
    group By a.id,a.doctor_name,a.gender_id,a.speciality_id,a.email,a.phone_no,a.dob,a.image_path,a.about,a.age,a.workplacetype,
    a.signature_path,a.reason,a.update_on_whatsapp,b.address1,b.address2,b.city_id,b.country_id,b.latitude,b.latitude1,
    b.longitude,b.longitude1,b.pincode,b.pincode1,b.state_id`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get DOC Register details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Register info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getregeall
  };
}

function RegGetByIdRepo(fastify) {
  async function getregById({ logTrace, body, params }) {
    const knex = this;
    const id = params.id;
    const query = knex.raw(`
    select  a.id,a.doctor_name,a.gender_id,a.speciality_id,a.email,a.phone_no,a.dob,a.image_path,a.about,a.age,
    a.signature_path,a.reason,a.update_on_whatsapp,a.workplacetype,b.address1,b.address2,b.city_id,b.country_id,b.latitude,b.latitude1,b.location,
    b.longitude,b.longitude1,b.pincode,b.pincode1,b.state_id,
    STRING_AGG(c.language_name_id, ', ') AS language_name_id from d_doctor_basic_info as a
    left join d_address_info as b on  a.id=b.doctor_name_id
    left join d_language_info as c on c.doctor_name_id=a.id and c.doctor_name_id=b.doctor_name_id
    where a.id=${id}
    group By a.id,a.doctor_name,a.gender_id,a.speciality_id,a.email,a.phone_no,a.dob,a.image_path,a.about,a.age,a.workplacetype,
    a.signature_path,a.reason,a.update_on_whatsapp,b.address1,b.address2,b.city_id,b.country_id,b.latitude,b.latitude1,b.location,
    b.longitude,b.longitude1,b.pincode,b.pincode1,b.state_id`);

    // const query = knex.select(`*`).from(`${REGISTERINFO.NAME}`).where(`${REGISTERINFO.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Register details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Register info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getregById
  };
}

function DocGetByIdRepo(fastify) {
  async function getdocById({ logTrace, body, params }) {
    const knex = this;
    const id = params.id;
    const query = knex.raw(`
    select a.doctor_name,b.speciality_name,a.image_path,a.addcheck
    from d_doctor_basic_info as a
    left join specialities as b on a.speciality_id=b.id
    where a.id=${id}`);

    // const query = knex.select(REGISTERINFO.COLUMNS.DOCTOR_NAME,REGISTERINFO.COLUMNS.IMAGE_PATH)
    // .from(`${REGISTERINFO.NAME}`).where(`${REGISTERINFO.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Doctor details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getdocById
  };
}

function RegPostRepo(fastify) {
  async function getregadd({ logTrace, body, params }) {
    const knex = this;
    const ch_mobile_num = knex
      .select(`*`)
      .from(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.PHONE_NO}`, body.phone_no);

    const ch_mobile_num_response = await ch_mobile_num;

    if (ch_mobile_num_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor Already Exists",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const doc_basic_info_data = {
      doctor_name: body.doctor_name,
      email: body.email,
      gender_id: body.gender_id ? body.gender_id : 0,
      dob: body.dob,
      phone_no: body.phone_no,
      about: body.about,
      workplacetype: body.workplacetype ? body.workplacetype : 0,
      image_path: null,
      speciality_id: parseInt(body.speciality_id)
        ? parseInt(body.speciality_id)
        : null,
      created_by: 2,
      updated_by: 2,
      active: parseInt(body.active),
      update_on_whatsapp: body.update_on_whatsapp ? body.update_on_whatsapp : 0
    };

    const doc_address_info_data = {
      address1: body.address1,
      address2: body.address2,
      pincode: body.pincode,
      longitude: body.longitude,
      latitude: body.latitude,
      country_id: body.country_id ? body.country_id : null,
      state_id: body.state_id ? body.state_id : null,
      city_id: body.city_id ? body.city_id : null,
      created_by: 2,
      updated_by: 2,
      pincode1: body.pincode1,
      longitude1: body.longitude1,
      latitude1: body.latitude1
    };

    const language_data = {
      language_name_id: parseInt(
        body.language_name_id ? body.language_name_id : 0
      ),
      created_by: 2,
      updated_by: 2
    };

    const query = await knex(`${REGISTERINFO.NAME}`)
      .insert({
        [REGISTERINFO.COLUMNS.DOCTOR_NAME]: doc_basic_info_data.doctor_name,
        [REGISTERINFO.COLUMNS.EMAIL]: doc_basic_info_data.email,
        [REGISTERINFO.COLUMNS.GENDER_ID]: doc_basic_info_data.gender_id,
        [REGISTERINFO.COLUMNS.DOB]: doc_basic_info_data.dob,
        [REGISTERINFO.COLUMNS.PHONE_NO]: doc_basic_info_data.phone_no,
        [REGISTERINFO.COLUMNS.CREATED_BY]: doc_basic_info_data.created_by,
        [REGISTERINFO.COLUMNS.UPDATED_BY]: doc_basic_info_data.updated_by,
        [REGISTERINFO.COLUMNS.ACTIVE]: doc_basic_info_data.active,
        [REGISTERINFO.COLUMNS.LAST_OTP]: null,
        [REGISTERINFO.COLUMNS.ABOUT]: doc_basic_info_data.about,
        [REGISTERINFO.COLUMNS.WORKPLACETYPE]: doc_basic_info_data.workplacetype,
        [REGISTERINFO.COLUMNS.SPECIALITY_ID]: doc_basic_info_data.speciality_id,
        [REGISTERINFO.COLUMNS.UPDATE_ON_WHATSAPP]:
          doc_basic_info_data.update_on_whatsapp,
        [REGISTERINFO.COLUMNS.CREATED_AT]: new Date(),
        [REGISTERINFO.COLUMNS.UPDATED_AT]: new Date()
      })
      .returning(REGISTERINFO.COLUMNS.ID);

    const doctor_name_id = query[0].id;
    const query2 = await knex(`${ADDRESSINFO.NAME}`).insert({
      [ADDRESSINFO.COLUMNS.DOCTOR_NAME_ID]: doctor_name_id,
      [ADDRESSINFO.COLUMNS.ADDRESS1]: doc_address_info_data.address1,
      [ADDRESSINFO.COLUMNS.PINCODE]: doc_address_info_data.pincode,
      [ADDRESSINFO.COLUMNS.LONGITUDE]: doc_address_info_data.longitude,
      [ADDRESSINFO.COLUMNS.LOCATION]: doc_address_info_data.location,
      [ADDRESSINFO.COLUMNS.LATITUDE]: doc_address_info_data.latitude,
      [ADDRESSINFO.COLUMNS.ADDRESS2]: doc_address_info_data.address2,
      [ADDRESSINFO.COLUMNS.COUNTRY_ID]: doc_address_info_data.country_id,
      [ADDRESSINFO.COLUMNS.STATE_ID]: doc_address_info_data.state_id,
      [ADDRESSINFO.COLUMNS.CITY_ID]: doc_address_info_data.city_id,
      [ADDRESSINFO.COLUMNS.CREATED_BY]: doc_address_info_data.created_by,
      [ADDRESSINFO.COLUMNS.UPDATED_BY]: doc_address_info_data.updated_by,
      [ADDRESSINFO.COLUMNS.CREATED_AT]: new Date(),
      [ADDRESSINFO.COLUMNS.UPDATED_AT]: new Date(),
      [ADDRESSINFO.COLUMNS.PINCODE1]: doc_address_info_data.pincode1,
      [ADDRESSINFO.COLUMNS.LONGITUDE1]: doc_address_info_data.longitude1,
      [ADDRESSINFO.COLUMNS.LATITUDE1]: doc_address_info_data.latitude1
    });

    const query3 = await knex(`${LANGUAGEINFO.NAME}`).insert({
      [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: doctor_name_id,
      [LANGUAGEINFO.COLUMNS.LANGUAGE_NAME_id]: language_data.language_name_id,
      [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: doctor_name_id,
      [LANGUAGEINFO.COLUMNS.CREATED_BY]: language_data.created_by,
      [LANGUAGEINFO.COLUMNS.UPDATED_BY]: language_data.updated_by,
      [LANGUAGEINFO.COLUMNS.CREATED_AT]: new Date(),
      [LANGUAGEINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const setvalue = 25;
    const addcheck = await addCheck(setvalue, doctor_name_id, fastify);
    const phone_number = body.phone_no;
    const { sendSms } = sms(fastify);
    const query4 = knex(REGISTERINFO.NAME)
      .select(
        REGISTERINFO.COLUMNS.ID,
        REGISTERINFO.COLUMNS.EMAIL,
        REGISTERINFO.COLUMNS.PHONE_NO
      )
      .where(REGISTERINFO.COLUMNS.PHONE_NO, phone_number);

    const response = await query4;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor Info not found",
        property: "",
        code: "NOT_FOUND"
      });
    } else {
      const flattenedArray = response.flat();

      const id = flattenedArray[0].id;
      const otp = Math.floor(1000 + Math.random() * 9000).toString();
      let hash = body.hash;
      if (!body.hash || body.hash == "" || body.hash == undefined) {
        hash = otp;
      }
      const promise1 = sendSms(phone_number, otp, hash);

      const [response2] = await Promise.all([promise1]);

      const query5 = knex(`${REGISTERINFO.NAME}`)
        .where(`${REGISTERINFO.COLUMNS.ID}`, id)
        .update({
          [REGISTERINFO.COLUMNS.LAST_OTP]: otp,
          [REGISTERINFO.COLUMNS.CREATED_AT]: new Date()
        });
      const response_data = await query5;

      return {
        success: true,
        message: "OTP Generated successfully",
        doctor_id: id
      };
    }
  }

  return {
    getregadd
  };
}

// function RegPutRepo(fastify) {
//   async function getregput({ logTrace, body, params, userDetails }) {
//     const knex = this;
//     const { id } = params;

//     const image_path = body.image_path;

//     console.log(image_path);

//     let imgurl = "";
//     if (image_path !== "" && image_path !== undefined) {
//       if (image_path.filename !== undefined && image_path.filename !== "") {
//         const img = await UploadImageService(image_path, fastify);
//         imgurl = img.image_url;
//       } else {
//         imgurl = null;
//       }
//     } else {
//       imgurl = null;
//     }

//     console.log("imgurl-" + imgurl);

//     const lang = body.language_id ? body.language_id.value.split(",") : [];

//     const doc_basic_info_data = {
//       doctor_name: body.doctor_name ? body.doctor_name.value : null,
//       email: body.email ? body.email.value : null,
//       gender_id: body.gender_id.value ? body.gender_id.value : 0,
//       dob: body.dob ? body.dob.value : null,
//       phone_no: body.phone_no ? body.phone_no.value : null,
//       about: body.about ? body.about.value : null,
//       workplacetype: body.workplacetype.value ? body.workplacetype.value : 0,
//       image_path: imgurl,
//       speciality_id: parseInt(body.speciality_id.value)
//         ? parseInt(body.speciality_id.value)
//         : 0,
//       created_by: 2,
//       updated_by: 2,
//       active: parseInt(body.active ? body.active.value : 1),
//       update_on_whatsapp: parseInt(
//         body.update_on_watsapp.value ? body.update_on_watsapp.value : 0
//       ),
//       age: body.age ? body.age.value : 0
//     };

//     const doc_address_info_data = {
//       doctor_name_id: parseInt(id),

//       address1: body.address1 ? body.address1.value : null,
//       address2: body.address2 ? body.address2.value : null,
//       pincode: body.pincode ? body.pincode.value : null,
//       longitude: body.longitude ? body.longitude.value : null,
//       latitude: body.latitude ? body.latitude.value : null,
//       country_id: body.country_id.value ? body.country_id.value : 0,
//       state_id: body.state_id.value ? body.state_id.value : 0,
//       city_id: body.city_id.value ? body.city_id.value : 0,
//       created_by: 2,
//       updated_by: 2,
//       pincode1: body.pincode1 ? body.pincode1.value : null,
//       longitude1: body.longitude1 ? body.longitude1.value : null,
//       latitude1: body.latitude1 ? body.latitude1.value : null
//     };

//     const language_data = {
//       created_by: 2,
//       updated_by: 2
//     };

//     const query = await knex(`${REGISTERINFO.NAME}`)
//       .where(`${REGISTERINFO.COLUMNS.ID}`, id)
//       .update({
//         [REGISTERINFO.COLUMNS.DOCTOR_NAME]: doc_basic_info_data.doctor_name,
//         [REGISTERINFO.COLUMNS.EMAIL]: doc_basic_info_data.email,
//         [REGISTERINFO.COLUMNS.GENDER_ID]: doc_basic_info_data.gender_id,
//         [REGISTERINFO.COLUMNS.DOB]: doc_basic_info_data.dob,
//         [REGISTERINFO.COLUMNS.PHONE_NO]: doc_basic_info_data.phone_no,
//         [REGISTERINFO.COLUMNS.CREATED_BY]: doc_basic_info_data.created_by,
//         [REGISTERINFO.COLUMNS.UPDATED_BY]: doc_basic_info_data.updated_by,
//         [REGISTERINFO.COLUMNS.ACTIVE]: doc_basic_info_data.active,
//         [REGISTERINFO.COLUMNS.AGE]: doc_basic_info_data.age,
//         [REGISTERINFO.COLUMNS.IMAGE_PATH]: doc_basic_info_data.image_path,
//         [REGISTERINFO.COLUMNS.LAST_OTP]: null,
//         [REGISTERINFO.COLUMNS.ABOUT]: doc_basic_info_data.about,
//         [REGISTERINFO.COLUMNS.WORKPLACETYPE]: doc_basic_info_data.workplacetype,
//         [REGISTERINFO.COLUMNS.SPECIALITY_ID]: doc_basic_info_data.speciality_id,
//         [REGISTERINFO.COLUMNS.UPDATE_ON_WHATSAPP]:
//           doc_basic_info_data.update_on_whatsapp,
//         [REGISTERINFO.COLUMNS.CREATED_AT]: new Date(),
//         [REGISTERINFO.COLUMNS.UPDATED_AT]: new Date()
//       });

//     const query2 = await knex(`${ADDRESSINFO.NAME}`)
//       .where(`${ADDRESSINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .update({
//         [ADDRESSINFO.COLUMNS.DOCTOR_NAME_ID]: id,
//         [ADDRESSINFO.COLUMNS.ADDRESS1]: doc_address_info_data.address1,
//         [ADDRESSINFO.COLUMNS.PINCODE]: doc_address_info_data.pincode,
//         [ADDRESSINFO.COLUMNS.LONGITUDE]: doc_address_info_data.longitude,
//         [ADDRESSINFO.COLUMNS.LOCATION]: doc_address_info_data.location,
//         [ADDRESSINFO.COLUMNS.LATITUDE]: doc_address_info_data.latitude,
//         [ADDRESSINFO.COLUMNS.ADDRESS2]: doc_address_info_data.address2,
//         [ADDRESSINFO.COLUMNS.COUNTRY_ID]: doc_address_info_data.country_id,
//         [ADDRESSINFO.COLUMNS.STATE_ID]: doc_address_info_data.state_id,
//         [ADDRESSINFO.COLUMNS.CITY_ID]: doc_address_info_data.city_id,
//         [ADDRESSINFO.COLUMNS.CREATED_BY]: doc_address_info_data.created_by,
//         [ADDRESSINFO.COLUMNS.UPDATED_BY]: doc_address_info_data.updated_by,
//         [ADDRESSINFO.COLUMNS.CREATED_AT]: new Date(),
//         [ADDRESSINFO.COLUMNS.UPDATED_AT]: new Date(),
//         [ADDRESSINFO.COLUMNS.PINCODE1]: doc_address_info_data.pincode1,
//         [ADDRESSINFO.COLUMNS.LONGITUDE1]: doc_address_info_data.longitude1,
//         [ADDRESSINFO.COLUMNS.LATITUDE1]: doc_address_info_data.latitude1
//       });

//     const query3 = await knex(`${LANGUAGEINFO.NAME}`)
//       .where(`${LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .del();

//     if (lang.length > 0) {
//       for (const i of lang) {
//         const query4 = await knex(LANGUAGEINFO.NAME).insert({
//           [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: id,
//           [LANGUAGEINFO.COLUMNS.LANGUAGE_NAME_id]: i,
//           [LANGUAGEINFO.COLUMNS.CREATED_BY]: language_data.created_by,
//           [LANGUAGEINFO.COLUMNS.UPDATED_BY]: language_data.updated_by,
//           [LANGUAGEINFO.COLUMNS.CREATED_AT]: new Date(),
//           [LANGUAGEINFO.COLUMNS.UPDATED_AT]: new Date()
//         });
//       }
//     } else {
//       const query3 = await knex(LANGUAGEINFO.NAME).insert({
//         [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: id,
//         [LANGUAGEINFO.COLUMNS.LANGUAGE_NAME_id]: 0,
//         [LANGUAGEINFO.COLUMNS.CREATED_BY]: language_data.created_by,
//         [LANGUAGEINFO.COLUMNS.UPDATED_BY]: language_data.updated_by,
//         [LANGUAGEINFO.COLUMNS.CREATED_AT]: new Date(),
//         [LANGUAGEINFO.COLUMNS.UPDATED_AT]: new Date()
//       });
//     }

//     const response = await query;

//     return { success: true, message: "Updated successfully" };
//   }

//   return {
//     getregput
//   };
// }

function RegPutRepo(fastify) {
  async function getregput({ logTrace, body, params, userDetails }) {
    const knex = this;
    const { id } = params;
    const image_path = body.image_path;
    let imgurl = "";
    if (image_path !== "" && image_path !== undefined) {
      if (image_path.filename !== undefined && image_path.filename !== "") {
        const img = await UploadImageService(image_path, fastify);
        imgurl = img.image_url;
      } else {
        imgurl = null;
      }
    } else {
      imgurl = null;
    }
    const lang = body.language_id ? body.language_id.value.split(",") : [];
    if (imgurl == null) {
      var doc_basic_info_data = {
        doctor_name: body.doctor_name ? body.doctor_name.value : null,
        email: body.email ? body.email.value : null,
        gender_id: body.gender_id.value ? body.gender_id.value : 0,
        dob: body.dob ? body.dob.value : null,
        phone_no: body.phone_no ? body.phone_no.value : null,
        about: body.about ? body.about.value : null,
        workplacetype: body.workplacetype.value ? body.workplacetype.value : 0,
        // image_path: imgurl,
        speciality_id: parseInt(body.speciality_id.value)
          ? parseInt(body.speciality_id.value)
          : 0,
        created_by: 2,
        updated_by: 2,
        active: parseInt(body.active ? body.active.value : 1),
        update_on_whatsapp: parseInt(
          body.update_on_watsapp.value ? body.update_on_watsapp.value : 0
        ),
        age: body.age ? body.age.value : 0
      };
    } else {
      var doc_basic_info_data = {
        doctor_name: body.doctor_name ? body.doctor_name.value : null,
        email: body.email ? body.email.value : null,
        gender_id: body.gender_id.value ? body.gender_id.value : 0,
        dob: body.dob ? body.dob.value : null,
        phone_no: body.phone_no ? body.phone_no.value : null,
        about: body.about ? body.about.value : null,
        workplacetype: body.workplacetype.value ? body.workplacetype.value : 0,
        image_path: imgurl,
        speciality_id: parseInt(body.speciality_id.value)
          ? parseInt(body.speciality_id.value)
          : 0,
        created_by: 2,
        updated_by: 2,
        active: parseInt(body.active ? body.active.value : 1),
        update_on_whatsapp: parseInt(
          body.update_on_watsapp.value ? body.update_on_watsapp.value : 0
        ),
        age: body.age ? body.age.value : 0
      }
    }
    const doc_address_info_data = {
      doctor_name_id: parseInt(id),
      address1: body.address1 ? body.address1.value : null,
      address2: body.address2 ? body.address2.value : null,
      pincode: body.pincode ? body.pincode.value : null,
      longitude: body.longitude ? body.longitude.value : null,
      latitude: body.latitude ? body.latitude.value : null,
      country_id: body.country_id.value ? body.country_id.value : 0,
      state_id: body.state_id.value ? body.state_id.value : 0,
      city_id: body.city_id.value ? body.city_id.value : 0,
      created_by: 2,
      updated_by: 2,
      pincode1: body.pincode1 ? body.pincode1.value : null,
      longitude1: body.longitude1 ? body.longitude1.value : null,
      latitude1: body.latitude1 ? body.latitude1.value : null
    };
    const language_data = {
      created_by: 2,
      updated_by: 2
    };
    const query = await knex(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, id)
      .update({
        [REGISTERINFO.COLUMNS.DOCTOR_NAME]: doc_basic_info_data.doctor_name,
        [REGISTERINFO.COLUMNS.EMAIL]: doc_basic_info_data.email,
        [REGISTERINFO.COLUMNS.GENDER_ID]: doc_basic_info_data.gender_id,
        [REGISTERINFO.COLUMNS.DOB]: doc_basic_info_data.dob,
        [REGISTERINFO.COLUMNS.PHONE_NO]: doc_basic_info_data.phone_no,
        [REGISTERINFO.COLUMNS.CREATED_BY]: doc_basic_info_data.created_by,
        [REGISTERINFO.COLUMNS.UPDATED_BY]: doc_basic_info_data.updated_by,
        [REGISTERINFO.COLUMNS.ACTIVE]: doc_basic_info_data.active,
        [REGISTERINFO.COLUMNS.AGE]: doc_basic_info_data.age,
        [REGISTERINFO.COLUMNS.IMAGE_PATH]: doc_basic_info_data.image_path,
        [REGISTERINFO.COLUMNS.LAST_OTP]: null,
        [REGISTERINFO.COLUMNS.ABOUT]: doc_basic_info_data.about,
        [REGISTERINFO.COLUMNS.WORKPLACETYPE]: doc_basic_info_data.workplacetype,
        [REGISTERINFO.COLUMNS.SPECIALITY_ID]: doc_basic_info_data.speciality_id,
        [REGISTERINFO.COLUMNS.UPDATE_ON_WHATSAPP]:
          doc_basic_info_data.update_on_whatsapp,
        [REGISTERINFO.COLUMNS.CREATED_AT]: new Date(),
        [REGISTERINFO.COLUMNS.UPDATED_AT]: new Date()
      });
    const query2 = await knex(`${ADDRESSINFO.NAME}`)
      .where(`${ADDRESSINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
      .update({
        [ADDRESSINFO.COLUMNS.DOCTOR_NAME_ID]: id,
        [ADDRESSINFO.COLUMNS.ADDRESS1]: doc_address_info_data.address1,
        [ADDRESSINFO.COLUMNS.PINCODE]: doc_address_info_data.pincode,
        [ADDRESSINFO.COLUMNS.LONGITUDE]: doc_address_info_data.longitude,
        [ADDRESSINFO.COLUMNS.LOCATION]: doc_address_info_data.location,
        [ADDRESSINFO.COLUMNS.LATITUDE]: doc_address_info_data.latitude,
        [ADDRESSINFO.COLUMNS.ADDRESS2]: doc_address_info_data.address2,
        [ADDRESSINFO.COLUMNS.COUNTRY_ID]: doc_address_info_data.country_id,
        [ADDRESSINFO.COLUMNS.STATE_ID]: doc_address_info_data.state_id,
        [ADDRESSINFO.COLUMNS.CITY_ID]: doc_address_info_data.city_id,
        [ADDRESSINFO.COLUMNS.CREATED_BY]: doc_address_info_data.created_by,
        [ADDRESSINFO.COLUMNS.UPDATED_BY]: doc_address_info_data.updated_by,
        [ADDRESSINFO.COLUMNS.CREATED_AT]: new Date(),
        [ADDRESSINFO.COLUMNS.UPDATED_AT]: new Date(),
        [ADDRESSINFO.COLUMNS.PINCODE1]: doc_address_info_data.pincode1,
        [ADDRESSINFO.COLUMNS.LONGITUDE1]: doc_address_info_data.longitude1,
        [ADDRESSINFO.COLUMNS.LATITUDE1]: doc_address_info_data.latitude1
      });
    const query3 = await knex(`${LANGUAGEINFO.NAME}`)
      .where(`${LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
      .del();
    if (lang.length > 0) {
      for (const i of lang) {
        const query4 = await knex(LANGUAGEINFO.NAME).insert({
          [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: id,
          [LANGUAGEINFO.COLUMNS.LANGUAGE_NAME_id]: i,
          [LANGUAGEINFO.COLUMNS.CREATED_BY]: language_data.created_by,
          [LANGUAGEINFO.COLUMNS.UPDATED_BY]: language_data.updated_by,
          [LANGUAGEINFO.COLUMNS.CREATED_AT]: new Date(),
          [LANGUAGEINFO.COLUMNS.UPDATED_AT]: new Date()
        });
      }
    } else {
      const query3 = await knex(LANGUAGEINFO.NAME).insert({
        [LANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID]: id,
        [LANGUAGEINFO.COLUMNS.LANGUAGE_NAME_id]: 0,
        [LANGUAGEINFO.COLUMNS.CREATED_BY]: language_data.created_by,
        [LANGUAGEINFO.COLUMNS.UPDATED_BY]: language_data.updated_by,
        [LANGUAGEINFO.COLUMNS.CREATED_AT]: new Date(),
        [LANGUAGEINFO.COLUMNS.UPDATED_AT]: new Date()
      });
    }
    // const response = await query;
    return { success: true, message: "Updated successfully" };
  }
  return {
    getregput
  };
}

function RegDeleteRepo(fastify) {
  async function getregdelete({ logTrace, body, params, userDetails }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, id)
      .del();

    const response = await query;
    return { success: true, message: "Deleted successfully" };
  }

  return {
    getregdelete
  };
}

function checkotpRepo(fastify) {
  async function getotpcheck({ body, params, userDetails }) {
    const knex = this;

    const doctor_name_id = body.doctor_name_id;
    const otp = body.otp;
    let deviceToken;
    if (!body.deviceToken || body.deviceToken == "" || body.deviceToken == undefined) {
      deviceToken = "";
    } else {
      deviceToken = body.deviceToken;
    }
console.log('deviceToken',deviceToken);
    const query = await knex(`${REGISTERINFO.NAME}`)
      .select(
        REGISTERINFO.COLUMNS.ID,
        REGISTERINFO.COLUMNS.CREATED_AT,
        REGISTERINFO.COLUMNS.LAST_OTP,
        REGISTERINFO.COLUMNS.DOCTOR_NAME,
        REGISTERINFO.COLUMNS.ID,
        REGISTERINFO.COLUMNS.EMAIL
      )
      .where(`${REGISTERINFO.COLUMNS.ID}`, doctor_name_id);

    const otp_check = query[0].last_otp;
    const otp_gen_time = moment(query[0].created_at).format("LTS");
    const otp_check_time = moment(new Date()).format("LTS");

    const genMoment = moment(otp_gen_time, "h:mm:ss A");
    const checkMoment = moment(otp_check_time, "h:mm:ss A");
    const timeDifferenceInSeconds = checkMoment.diff(genMoment, "seconds");
    const query2 = await knex(`${REGISTERINFO.NAME}`)
    .where(`${REGISTERINFO.COLUMNS.ID}`, doctor_name_id)
    .update({
      [REGISTERINFO.COLUMNS.DEVICETOKEN]: deviceToken
    });
    if (timeDifferenceInSeconds > 60) {
      return { success: false, message: "OTP Expired" };
    } else {
      if (otp_check == otp) {
        const token = await fastify.jwt.sign({ query });
        return {
          success: true,
          token: token,
          message: "OTP Verified successfully"
        };
      } else {
        return { success: false, message: "Please Check OTP" };
      }
    }
  }
  return {
    getotpcheck
  };
}

function resendotpRepo(fastify) {
  async function getresendotp({ body, params, userDetails }) {
    const knex = this;
    const { sendSms } = sms(fastify);

    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    let hash = body.hash;
    if (!body.hash || body.hash == "" || body.hash == undefined) {
      hash = otp;
    }
    const id = body.doctor_name_id;
    const query = knex(REGISTERINFO.NAME)
      .select(
        REGISTERINFO.COLUMNS.ID,
        REGISTERINFO.COLUMNS.EMAIL,
        REGISTERINFO.COLUMNS.PHONE_NO
      )
      .where(REGISTERINFO.COLUMNS.ID, id);
    const response = await query;
    const flattenedArray = response.flat();

    const phone_number = flattenedArray[0].phone_no;

    const promise1 = sendSms(phone_number, otp, hash);

    const [response2] = await Promise.all([promise1]);

    const query5 = knex(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, id)
      .update({
        [REGISTERINFO.COLUMNS.LAST_OTP]: otp,
        [REGISTERINFO.COLUMNS.CREATED_AT]: new Date()
      });
    const response_data = await query5;

    return {
      success: true,
      message: "OTP Generated successfully",
      doctor_id: id
    };
  }
  return {
    getresendotp
  };
}

module.exports = {
  RegAllRepo,
  RegGetByIdRepo,
  RegPostRepo,
  RegPutRepo,
  RegDeleteRepo,
  checkotpRepo,
  resendotpRepo,
  DocGetByIdRepo
};
