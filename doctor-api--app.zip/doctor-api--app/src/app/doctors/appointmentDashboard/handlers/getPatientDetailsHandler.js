const getPatientDetailsService = require("../services/getPatientDetailsService");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
const pump = util.promisify(pipeline);


function getPatientDetailsHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};


function getPatientDetailsDateFilterHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsDateFilterInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};


function getPatientDetailsHandlerPostImg(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsInfoServicePostImg(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace,
      params,
      body

    });
    return reply.code(200).send(response);
  };

}

module.exports = {
  getPatientDetailsDateFilterHandlerPost,
  getPatientDetailsHandlerPostImg,
  getPatientDetailsHandlerPost
};
