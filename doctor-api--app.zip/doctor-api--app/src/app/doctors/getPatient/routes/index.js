const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  ///video or walking

  fastify.route({
    method: "POST",
    url: "/patient-detail-dateFilter",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getPatientDetailsDateFilterHandlerPost(
        fastify
      )
  });

  fastify.route({
    method: "POST",
    url: "/patient-detail",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getPatientDetailsHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-detail-with-ehr",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getPatientDetailsWithEhrHandlerPost(
        fastify
      )
  });

  //reschulde

  fastify.route({
    method: "POST",
    url: "/reschedule_get_slot",
    // preHandler: fastify.authenticate,
    handler:
      handlers.getPatientDetailsHandler.reschedulepostHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/reschedule_get_slot_v2",
    // preHandler: fastify.authenticate,
    handler:
      handlers.getPatientDetailsHandler.reschedulepostHandlerv2Post(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/reschedule/post",
    // preHandler: fastify.authenticate,
    handler:
      handlers.getPatientDetailsHandler.reschedulefinalHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/cancel/appoinment",
    // preHandler: fastify.authenticate,
    handler:
      handlers.getPatientDetailsHandler.cancelappoinmentlHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-detail-img",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getPatientDetailsHandlerPostImg(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/cancel-appointment-reason",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getCancelAppointmentwithReasonHandler(
        fastify
      )
  });
  
  fastify.route({
    method: "POST",
    url: "/patient-detail-dateFilter-overAll-complete",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler:
      handlers.getPatientDetailsHandler.getPatientDetailsDateFilterOverallCompleteHandlerPost(
        fastify
      )
  });
};
