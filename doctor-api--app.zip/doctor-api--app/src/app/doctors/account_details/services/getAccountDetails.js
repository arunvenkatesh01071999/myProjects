const accoutDetailInfo = require("../repository/getAccountdetails");
// const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getAccountInfoService(fastify) {
    const { getAllAccount } = accoutDetailInfo.allAccountDetail(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAllAccount.call(knex, {
            logTrace
        });
        const [getAccountAllService] = await Promise.all([promise1]);

        return getAccountAllService;
    };
}

function getAccountInfoByIdService(fastify) {
    const { getAllIdAccount , getBankInfo ,getNbBankInfo} = accoutDetailInfo.allAccountDetailById(fastify);
    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAllIdAccount.call(knex, {
            logTrace,body, params,
        });
        const [getAccountAllIdService] = await Promise.all([promise1]);
        let bank_id =  getAccountAllIdService[0].bank_id
        let nb_bank_id =  getAccountAllIdService[0].nb_bank_id
        const promise2 =await getBankInfo.call(knex, {
            logTrace,body, params,bank_id
        });
        const promise3 =await getNbBankInfo.call(knex, {
            logTrace,body, params,nb_bank_id
        });
        const resultArray = getAccountAllIdService.map(item => ({...item, bankName: promise2,nd_bank_name: promise3}));
        return resultArray
    };
}

function getAccountPostInfoService(fastify) {
    const { getAddAccount } = accoutDetailInfo.accountPostRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAddAccount.call(knex, {
            logTrace,
            body
        });

        const [getAccountAddService] = await Promise.all([promise1]);

        return getAccountAddService;
    };
}
function getAccountInfoPutService(fastify) {
    const { getPutAccount } = accoutDetailInfo.accountPutRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getPutAccount.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getAccountPutService] = await Promise.all([promise1]);

        return getAccountPutService;
    };
}

function getAccountDeleteService(fastify) {
    const { getAccountDelete } =
        accoutDetailInfo.accountDeleteRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAccountDelete.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getDeleteService] = await Promise.all([promise1]);

        return getDeleteService;
    };
}

module.exports = {
    getAccountInfoService,
    getAccountPostInfoService,
    getAccountInfoPutService,
    getAccountDeleteService,
    getAccountInfoByIdService
};
