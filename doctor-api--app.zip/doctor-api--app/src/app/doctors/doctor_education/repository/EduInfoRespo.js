const { StatusCodes } = require("http-status-codes");
const nodemailer = require("nodemailer");
const previewEmail = require("preview-email");
const JSONTransport = require("nodemailer/lib/json-transport");
const { logQuery } = require("../../../commons/helpers");
const { EXPINFO } = require("../commons/constants");
const { EDUCATIONINFO } = require("../commons/constants");
const { COUNCILINFO } = require("../commons/constants");
const sms = require("../../../notification/repository/sms");
const UploadImageService = require("../../../commons/imageupload");
const addCheck = require("../../../commons/addcheck");


const { CustomError } = require("../../../errorHandler");

function EduAllRepo(fastify) {
  async function getedueall({ logTrace }) {
    const knex = this;

    const query =
      knex.raw(`select a.doctor_name_id,a.specialization_id,a.department_id,a.experience,a.specialized_file,
    b.qualification_name_id,b.certificate_path as edu_certificate_path,b.yop,c.council_id,c.registration_no,c.registration_date,
    c.renewal_date,c.certificate_path  as council_certificate_path from d_experience_info as a
    left join d_education_info as b on a.doctor_name_id=b.doctor_name_id
    left join d_council_info as c on c.doctor_name_id=a.doctor_name_id and b.doctor_name_id=c.doctor_name_id`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get DOC Register details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Register info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getedueall
  };
}

function EduGetByIdRepo(fastify) {
  async function geteduById({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    const query =
      knex.raw(`select a.doctor_name_id,a.specialization_id,a.department_id,a.experience,a.specialized_file,
      b.qualification_name_id,b.certificate_path as edu_certificate_path,b.yop,c.council_id,c.registration_no,c.registration_date,
      c.renewal_date,c.certificate_path  as council_certificate_path from d_experience_info as a
      left join d_education_info as b on a.doctor_name_id=b.doctor_name_id
      left join d_council_info as c on c.doctor_name_id=a.doctor_name_id and b.doctor_name_id=c.doctor_name_id
     where a.doctor_name_id=${id}`);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Register details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Register info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    geteduById
  };
}

function EduPostRepo(fastify) {
  async function geteduadd({ logTrace, body, params }) {
    const knex = this;

    let { qua_certificate_path } = body;

    let imgUrls = [];
    let imgurl = "";

    if (!Array.isArray(qua_certificate_path)) {
      qua_certificate_path = [qua_certificate_path]; // Convert to array if it's not already
    }

    if (qua_certificate_path.length > 0) {
      for (const file of qua_certificate_path) {
        if (file.filename !== undefined && file.filename !== "") {
          const img = await UploadImageService(file, fastify);
          imgUrls.push(img.image_url);
        }
      }
      imgurl = imgUrls.join(",");
    }
    console.log("imgurl" + imgurl);

    let { specialized_file } = body;

    let splImgUrls = [];
    let specialized_file_imgurl = "";

    if (!Array.isArray(specialized_file)) {
      specialized_file = [specialized_file]; // Convert to array if it's not already
    }

    if (specialized_file.length > 0) {
      for (const file of specialized_file) {
        if (file.filename !== undefined && file.filename !== "") {
          const splimg = await UploadImageService(file, fastify);
          splImgUrls.push(splimg.image_url);
        }
      }
      specialized_file_imgurl = splImgUrls.join(",");
    }
    console.log("specialized_file_imgurl" + specialized_file_imgurl);

    let { certificate_path } = body;

    let cerImgUrls = [];
    let certificate_path_imgurl = "";

    if (!Array.isArray(certificate_path)) {
      certificate_path = [certificate_path]; // Convert to array if it's not already
    }

    if (certificate_path.length > 0) {
      for (const file of certificate_path) {
        if (file.filename !== undefined && file.filename !== "") {
          const cerimg = await UploadImageService(file, fastify);
          cerImgUrls.push(cerimg.image_url);
        }
      }
      certificate_path_imgurl = cerImgUrls.join(",");
    }
    console.log("certificate_path_imgurl" + certificate_path_imgurl);

    const doc_id = knex
      .select(`*`)
      .from(`${EDUCATIONINFO.NAME}`)
      .where(
        `${EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID}`,
        body.doctor_name_id.value
      );

    const doc_id_response = await doc_id;

    if (doc_id_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Doctor Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const edu_info_data = {
      qualification_name_id: parseInt(body.qualification_name_id.value),
      qua_certificate_path: imgurl,
      doctor_name_id: parseInt(body.doctor_name_id.value),
      yop: body.yop ? body.yop.value : 0,
      created_by: parseInt(body.created_by.value),
      active: parseInt(body.active.value)
    };

    const d_exp_data = {
      experience: body.experience.value,
      speaclity_id: parseInt(body.speaclity_id.value),
      doctor_name_id: parseInt(body.doctor_name_id.value),
      specialized_file: specialized_file_imgurl,
      department_id: parseInt(body.department_id.value),
      active: parseInt(body.active.value),
      created_by: parseInt(body.created_by.value)
    };

    const d_council_data = {
      council_id: parseInt(body.council_id.value),
      doctor_name_id: parseInt(body.doctor_name_id.value),
      registration_no: body.registration_no.value,
      registration_file: certificate_path_imgurl,
      reg_date: body.reg_date.value,
      renewal_date: body.renewal_date.value,
      active: parseInt(body.active.value),
      created_by: parseInt(body.created_by.value),
      updated_by: parseInt(body.created_by.value)
    };

    const query = await knex(`${EDUCATIONINFO.NAME}`).insert({
      [EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID]: edu_info_data.doctor_name_id,
      [EDUCATIONINFO.COLUMNS.QUALIFICATION_NAME_ID]:
        edu_info_data.qualification_name_id,
      [EDUCATIONINFO.COLUMNS.YOP]: edu_info_data.yop,
      [EDUCATIONINFO.COLUMNS.CERTIFICATE_PATH]:
        edu_info_data.qua_certificate_path,
      [EDUCATIONINFO.COLUMNS.CREATED_BY]: edu_info_data.created_by,
      [EDUCATIONINFO.COLUMNS.UPDATED_BY]: edu_info_data.created_by,
      [EDUCATIONINFO.COLUMNS.ACTIVE]: edu_info_data.active,
      [EDUCATIONINFO.COLUMNS.CREATED_AT]: new Date(),
      [EDUCATIONINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const query2 = await knex(`${EXPINFO.NAME}`).insert({
      [EXPINFO.COLUMNS.EXPERIENCE]: d_exp_data.experience,
      [EXPINFO.COLUMNS.DOCTOR_NAME_ID]: d_exp_data.doctor_name_id,
      [EXPINFO.COLUMNS.SPECIALIZATION_ID]: d_exp_data.speaclity_id,
      [EXPINFO.COLUMNS.SPECIALIZED_FILE]: d_exp_data.specialized_file,
      [EXPINFO.COLUMNS.DEPARTMENT_ID]: d_exp_data.department_id,
      [EXPINFO.COLUMNS.CREATED_BY]: d_exp_data.created_by,
      [EXPINFO.COLUMNS.CREATED_AT]: new Date(),
      [EXPINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const query3 = await knex(`${COUNCILINFO.NAME}`).insert({
      [COUNCILINFO.COLUMNS.DOCTOR_NAME_ID]: d_council_data.doctor_name_id,
      [COUNCILINFO.COLUMNS.COUNCIL_ID]: d_council_data.council_id,
      [COUNCILINFO.COLUMNS.REGISTRATION_NO]: d_council_data.registration_no,
      [COUNCILINFO.COLUMNS.CERTIFICATE_PATH]: d_council_data.registration_file,
      [COUNCILINFO.COLUMNS.REGISTRATION_DATE]: d_council_data.reg_date,
      [COUNCILINFO.COLUMNS.RENEWAL_DATE]: d_council_data.renewal_date,
      [COUNCILINFO.COLUMNS.CREATED_BY]: d_council_data.created_by,
      [COUNCILINFO.COLUMNS.UPDATED_BY]: d_council_data.updated_by,
      [COUNCILINFO.COLUMNS.CREATED_AT]: new Date(),
      [COUNCILINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    // const response = await query;
    const setvalue = 25;
    const doctor_name_id = edu_info_data.doctor_name_id;
    const addcheck = await addCheck(setvalue, doctor_name_id, fastify);
    return { success: true, message: "Insert successfully" };
  }

  return {
    geteduadd
  };
}

// function EduPutRepo(fastify) {
//   async function geteduput({ logTrace, body, params, userDetails }) {
//     const knex = this;
//     const { id } = params;

//     let { qua_certificate_path } = body;

//     let imgUrls = [];
//     let imgurl = "";

//     if (!Array.isArray(qua_certificate_path)) {
//       qua_certificate_path = [qua_certificate_path]; // Convert to array if it's not already
//     }

//     if (qua_certificate_path.length > 0) {
//       for (const file of qua_certificate_path) {
//         if (file.filename !== undefined && file.filename !== "") {
//           const img = await UploadImageService(file, fastify);
//           imgUrls.push(img.image_url);
//         }
//       }
//       imgurl = imgUrls.join(",");
//     }
//     console.log("imgurl" + imgurl);

//     let { specialized_file } = body;

//     let splImgUrls = [];
//     let specialized_file_imgurl = "";

//     if (!Array.isArray(specialized_file)) {
//       specialized_file = [specialized_file]; // Convert to array if it's not already
//     }

//     if (specialized_file.length > 0) {
//       for (const file of specialized_file) {
//         if (file.filename !== undefined && file.filename !== "") {
//           const splimg = await UploadImageService(file, fastify);
//           splImgUrls.push(splimg.image_url);
//         }
//       }
//       specialized_file_imgurl = splImgUrls.join(",");
//     }
//     console.log("specialized_file_imgurl" + specialized_file_imgurl);

//     let { certificate_path } = body;

//     let cerImgUrls = [];
//     let certificate_path_imgurl = "";

//     if (!Array.isArray(certificate_path)) {
//       certificate_path = [certificate_path]; // Convert to array if it's not already
//     }

//     if (certificate_path.length > 0) {
//       for (const file of certificate_path) {
//         if (file.filename !== undefined && file.filename !== "") {
//           const cerimg = await UploadImageService(file, fastify);
//           cerImgUrls.push(cerimg.image_url);
//         }
//       }
//       certificate_path_imgurl = cerImgUrls.join(",");
//     }
//     console.log("certificate_path_imgurl" + certificate_path_imgurl);

//     const edu_info_data = {
//       qualification_name_id: parseInt(body.qualification_name_id.value),
//       qua_certificate_path: imgurl,
//       yop: body.yop.value,
//       doctor_name_id: parseInt(body.doctor_name_id.value),
//       created_by: parseInt(body.created_by.value),
//       active: parseInt(body.active.value)
//     };

//     const d_exp_data = {
//       experience: body.experience.value,
//       speaclity_id: parseInt(body.speaclity_id.value),
//       doctor_name_id: parseInt(body.doctor_name_id.value),
//       specialized_file: specialized_file_imgurl,
//       department_id: parseInt(body.department_id.value),
//       active: parseInt(body.active.value),
//       created_by: parseInt(body.created_by.value)
//     };

//     const d_council_data = {
//       council_id: parseInt(body.council_id.value),
//       doctor_name_id: parseInt(body.doctor_name_id.value),
//       registration_no: body.registration_no.value,
//       certificate_path: certificate_path_imgurl,
//       reg_date: body.reg_date.value,
//       renewal_date: body.renewal_date.value,
//       active: parseInt(body.active.value),
//       created_by: parseInt(body.created_by.value)
//     };

//     const query = await knex(`${EDUCATIONINFO.NAME}`)
//       .where(`${EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .update({
//         [EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID]: edu_info_data.doctor_name_id,
//         [EDUCATIONINFO.COLUMNS.QUALIFICATION_NAME_ID]:
//           edu_info_data.qualification_name_id,
//         [EDUCATIONINFO.COLUMNS.YOP]: edu_info_data.yop,
//         [EDUCATIONINFO.COLUMNS.CERTIFICATE_PATH]:
//           edu_info_data.qua_certificate_path,
//         [EDUCATIONINFO.COLUMNS.UPDATED_BY]: edu_info_data.created_by,
//         [EDUCATIONINFO.COLUMNS.ACTIVE]: edu_info_data.active,
//         [EDUCATIONINFO.COLUMNS.UPDATED_AT]: new Date()
//       });

//     const query2 = await knex(`${EXPINFO.NAME}`)
//       .where(`${EXPINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .update({
//         [EXPINFO.COLUMNS.EXPERIENCE]: d_exp_data.experience,
//         [EXPINFO.COLUMNS.DOCTOR_NAME_ID]: d_exp_data.doctor_name_id,
//         [EXPINFO.COLUMNS.SPECIALIZATION_ID]: d_exp_data.speaclity_id,
//         [EXPINFO.COLUMNS.SPECIALIZED_FILE]: d_exp_data.specialized_file,
//         [EXPINFO.COLUMNS.DEPARTMENT_ID]: d_exp_data.department_id,
//         [EXPINFO.COLUMNS.UPDATED_BY]: d_exp_data.created_by,
//         [EXPINFO.COLUMNS.UPDATED_AT]: new Date()
//       });

//     const query3 = await knex(`${COUNCILINFO.NAME}`)
//       .where(`${COUNCILINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
//       .update({
//         [COUNCILINFO.COLUMNS.DOCTOR_NAME_ID]: d_council_data.doctor_name_id,
//         [COUNCILINFO.COLUMNS.COUNCIL_ID]: d_council_data.council_id,
//         [COUNCILINFO.COLUMNS.REGISTRATION_NO]: d_council_data.registration_no,
//         [COUNCILINFO.COLUMNS.CERTIFICATE_PATH]: d_council_data.certificate_path,
//         [COUNCILINFO.COLUMNS.REGISTRATION_DATE]: d_council_data.reg_date,
//         [COUNCILINFO.COLUMNS.RENEWAL_DATE]: d_council_data.renewal_date,
//         [COUNCILINFO.COLUMNS.UPDATED_BY]: d_council_data.created_by,
//         [COUNCILINFO.COLUMNS.UPDATED_AT]: new Date()
//       });

//     // const response = await query;

//     return { success: true, message: "Updated successfully" };
//   }

//   return {
//     geteduput
//   };
// }

function EduPutRepo(fastify) {
  async function geteduput({ logTrace, body, params, userDetails }) {
    const knex = this;
    const { id } = params;
    var qua_certificate_path = body.qua_certificate_path;
    let imgurl = "";
    if (qua_certificate_path !== "" && qua_certificate_path !== undefined) {
      if (qua_certificate_path.filename !== undefined && qua_certificate_path.filename !== "") {
        const img = await UploadImageService(qua_certificate_path, fastify);
        imgurl = img.image_url;
      } else {
        imgurl = null;
      }
    } else {
      imgurl = null;
    }
    if(imgurl == null){
      var edu_info_data = {
        qualification_name_id: parseInt(body.qualification_name_id.value),
        // qua_certificate_path: imgurl,
        yop: body.yop.value,
        doctor_name_id: parseInt(body.doctor_name_id.value),
        created_by: parseInt(body.created_by.value),
        active: parseInt(body.active.value)
      };
    }else{
      var edu_info_data = {
        qualification_name_id: parseInt(body.qualification_name_id.value),
        qua_certificate_path: imgurl,
        yop: body.yop.value,
        doctor_name_id: parseInt(body.doctor_name_id.value),
        created_by: parseInt(body.created_by.value),
        active: parseInt(body.active.value)
      };
    }
    var specialized_file = body.specialized_file;
    let specialized_file_imgurl = "";
    if (specialized_file !== "" && specialized_file !== undefined) {
      if (specialized_file.filename !== undefined && specialized_file.filename !== "") {
        const img = await UploadImageService(specialized_file, fastify);
        specialized_file_imgurl = img.image_url;
      } else {
        specialized_file_imgurl = null;
      }
    } else {
      specialized_file_imgurl = null;
    }
    if(specialized_file_imgurl == null){
      var d_exp_data = {
        experience: body.experience.value,
        speaclity_id: parseInt(body.speaclity_id.value),
        doctor_name_id: parseInt(body.doctor_name_id.value),
        department_id: parseInt(body.department_id.value),
        active: parseInt(body.active.value),
        created_by: parseInt(body.created_by.value)
      };
    }
    else{
      var d_exp_data = {
        experience: body.experience.value,
        speaclity_id: parseInt(body.speaclity_id.value),
        doctor_name_id: parseInt(body.doctor_name_id.value),
        specialized_file: specialized_file_imgurl,
        department_id: parseInt(body.department_id.value),
        active: parseInt(body.active.value),
        created_by: parseInt(body.created_by.value)
      };
    }
    var certificate_path = body.certificate_path;
    let certificate_path_imgurl = "";
    if (certificate_path !== "" && certificate_path !== undefined) {
      if (certificate_path.filename !== undefined && certificate_path.filename !== "") {
        const img = await UploadImageService(certificate_path, fastify);
        certificate_path_imgurl = img.image_url;
      } else {
        certificate_path_imgurl = null;
      }
    } else {
      certificate_path_imgurl = null;
    }
    if(certificate_path_imgurl == null){
      var d_council_data = {
        council_id: parseInt(body.council_id.value),
        doctor_name_id: parseInt(body.doctor_name_id.value),
        registration_no: body.registration_no.value,
        // certificate_path: certificate_path_imgurl,
        reg_date: body.reg_date.value,
        renewal_date: body.renewal_date.value,
        active: parseInt(body.active.value),
        created_by: parseInt(body.created_by.value)
      };
    }else{
      var d_council_data = {
        council_id: parseInt(body.council_id.value),
        doctor_name_id: parseInt(body.doctor_name_id.value),
        registration_no: body.registration_no.value,
        certificate_path: certificate_path_imgurl,
        reg_date: body.reg_date.value,
        renewal_date: body.renewal_date.value,
        active: parseInt(body.active.value),
        created_by: parseInt(body.created_by.value)
      };
    }
    const query = await knex(`${EDUCATIONINFO.NAME}`)
      .where(`${EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
      .update({
        [EDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID]: edu_info_data.doctor_name_id,
        [EDUCATIONINFO.COLUMNS.QUALIFICATION_NAME_ID]:
          edu_info_data.qualification_name_id,
        [EDUCATIONINFO.COLUMNS.YOP]: edu_info_data.yop,
        [EDUCATIONINFO.COLUMNS.CERTIFICATE_PATH]:
          edu_info_data.qua_certificate_path,
        [EDUCATIONINFO.COLUMNS.UPDATED_BY]: edu_info_data.created_by,
        [EDUCATIONINFO.COLUMNS.ACTIVE]: edu_info_data.active,
        [EDUCATIONINFO.COLUMNS.UPDATED_AT]: new Date()
      });
    const query2 = await knex(`${EXPINFO.NAME}`)
      .where(`${EXPINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
      .update({
        [EXPINFO.COLUMNS.EXPERIENCE]: d_exp_data.experience,
        [EXPINFO.COLUMNS.DOCTOR_NAME_ID]: d_exp_data.doctor_name_id,
        [EXPINFO.COLUMNS.SPECIALIZATION_ID]: d_exp_data.speaclity_id,
        [EXPINFO.COLUMNS.SPECIALIZED_FILE]: d_exp_data.specialized_file,
        [EXPINFO.COLUMNS.DEPARTMENT_ID]: d_exp_data.department_id,
        [EXPINFO.COLUMNS.UPDATED_BY]: d_exp_data.created_by,
        [EXPINFO.COLUMNS.UPDATED_AT]: new Date()
      });
    const query3 = await knex(`${COUNCILINFO.NAME}`)
      .where(`${COUNCILINFO.COLUMNS.DOCTOR_NAME_ID}`, id)
      .update({
        [COUNCILINFO.COLUMNS.DOCTOR_NAME_ID]: d_council_data.doctor_name_id,
        [COUNCILINFO.COLUMNS.COUNCIL_ID]: d_council_data.council_id,
        [COUNCILINFO.COLUMNS.REGISTRATION_NO]: d_council_data.registration_no,
        [COUNCILINFO.COLUMNS.CERTIFICATE_PATH]: d_council_data.certificate_path,
        [COUNCILINFO.COLUMNS.REGISTRATION_DATE]: d_council_data.reg_date,
        [COUNCILINFO.COLUMNS.RENEWAL_DATE]: d_council_data.renewal_date,
        [COUNCILINFO.COLUMNS.UPDATED_BY]: d_council_data.created_by,
        [COUNCILINFO.COLUMNS.UPDATED_AT]: new Date()
      });
    return { success: true, message: "Updated successfully" };
  }
  return {
    geteduput
  };
}

function EduDeleteRepo(fastify) {
  async function getedudelete({ logTrace, body, params, userDetails }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getedudelete
  };
}

function generateotpRepo(fastify) {
  const { sendSms } = sms(fastify);
  async function getotp({ body, params, userDetails }) {
    //   const knex = this;
    //   const phone_number  = body.mobile;
    //   const otp = Math.floor(1000 + Math.random() * 9000).toString();
    //   const query = await knex(`${REGISTERINFO.NAME}`).where(`${REGISTERINFO.COLUMNS.PHONE_NO}`, phone_number)
    //   .update({
    //     [REGISTERINFO.COLUMNS.LAST_OTP]:otp,
    //   });
    //   const response = await query;
    //   return otp;
    /// /////////////////////////////
    // const  message=otp;
    // const promise1 = sendSms.call(knex, {
    //   phone_number, message
    // });
    // const transporter = nodemailer.createTransport({
    //   service: 'Gmail',
    //   auth: {
    //     user: 'Pradhapbothan119@gmail.com',
    //     pass: '9524203556'
    //   }
    // });
    // const mailOptions = {
    //   from:'Pradhapbothan119@gmail.com',
    //   to: 'sivanandhini0307@gmail.com',
    //   subject: 'Test Email',
    //   text: 'This is a test email sent from Node.js using nodemailer!'
    // };
    // transporter.sendMail(mailOptions, (error, info) => {
    //   if (error) {
    //     console.error('Error occurred:', error);
    //   } else {
    //     console.log('Email sent:', info.response);
    //   }
    // });
    // const transport = nodemailer.createTransport({
    //   jsonTransport: true
    // });
    // // <https://nodemailer.com/message/>
    // const message = {
    //   from:'Pradhapbothan119@gmail.com',
    //   to: 'sivanandhini0307@gmail.com',
    //   subject: 'Hello world',
    //   html: '<p>Hello world</p>',
    //   text: 'Hello world',
    //   // attachments: [{ filename: 'hello-world.txt', content: 'Hello world' }]
    // };
    // note that `attachments` will not be parsed unless you use
    // `previewEmail` with the results of `transport.sendMail`
    // e.g. `previewEmail(JSON.parse(res.message));` where `res`
    // is `const res = await transport.sendMail(message);`
    // previewEmail(message).then(console.log).catch(console.error);
    // transport.sendMail(message).then(console.log).catch(console.error);
    // D:\prathap\fastify\uno-api-serivces\src\app\notification\repository\sms.js
    // console.log('mobile', mobile);
    // const query = await knex(`${REGISTERINFO.NAME}`)
    //   .where(`${REGISTERINFO.COLUMNS.ID}`, id)
    //   .del();
    // const response = await query;
    // return promise1;
  }

  return {
    getotp
  };
}

function checkotpRepo(fastify) {
  async function getotpcheck({ body, params, userDetails }) {
    const knex = this;

    const { doctor_name_id } = body;
    const { last_otp } = body;

    const query = knex
      .select(`last_otp`)
      .from(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, doctor_name_id);
    const response = await query;
    const check = response[0].last_otp;

    if (last_otp == check) {
      return { success: true, message: "Register successfully" };
    }
    return { success: false, message: "Invalid Otp" };
  }
  return {
    getotpcheck
  };
}

module.exports = {
  EduAllRepo,
  EduGetByIdRepo,
  EduPostRepo,
  EduPutRepo,
  EduDeleteRepo,
  generateotpRepo,
  checkotpRepo
};
