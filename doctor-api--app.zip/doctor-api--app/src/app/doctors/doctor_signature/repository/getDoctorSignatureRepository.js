const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORSIGNATURE } = require("../commons/constants");
const { CustomError } = require("../../../errorHandler");
const UploadImageService = require("../../../commons/imageupload");


// function updateDoctorSignatureRepository(fastify) {
//   async function getDoctorSignatureUpdate({ logTrace, body, params }) {
//     const knex = this;
//     const { id } = params;
//     if (signature_path.filename != '') {
//       const img = UploadImageService(signature_path, fastify);
//       var imgurl = img.image_url;
//     } else {
//       var imgurl = null;
//     }
//     const query = await knex(`${DOCTORSIGNATURE.NAME}`)
//       .where(`${DOCTORSIGNATURE.COLUMNS.ID}`, id)
//       .update({
//         [DOCTORSIGNATURE.COLUMNS.SIGNATURE_PATH]: imgurl,
//         [DOCTORSIGNATURE.COLUMNS.CREATED_BY]: body.created_by.value
//       });

//     return { success: true, message: "Update successfully" };
//   }

//   return {
//     getDoctorSignatureUpdate,
//   };
// }

function updateDoctorSignatureRepository(fastify) {
  async function getDoctorSignatureUpdate({
    logTrace,
    body,
    params,
    userDetails
  }) {
    const knex = this;
    const { id } = params;
    // const signature_path = body.signature_path;
    // if (signature_path.filename != '') {
    //   const img = await UploadImageService(signature_path, fastify);
    //   var imgurl = img.image_url;
    // } else {
    //   var imgurl = null;
    // }

    const signature_path = body.signature_path;

    if (signature_path !== '' && signature_path !== undefined) {
      if (signature_path.filename !== undefined && signature_path.filename !== '') {
        const img = await UploadImageService(signature_path, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;
      }
    }
    else {
      var imgurl = null;
    }

    const query = await knex(`${DOCTORSIGNATURE.NAME}`)
      .where(`${DOCTORSIGNATURE.COLUMNS.ID}`, id)
      .update({
        [DOCTORSIGNATURE.COLUMNS.SIGNATURE_PATH]: imgurl,
        [DOCTORSIGNATURE.COLUMNS.CREATED_BY]: body.created_by.value
      });
    const response = await query;
    return { success: true, message: "Updated successfully" };
  }
  return {
    getDoctorSignatureUpdate
  };
}







module.exports = {

  updateDoctorSignatureRepository


};
