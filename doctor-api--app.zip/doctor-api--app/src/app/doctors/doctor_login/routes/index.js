const schemas = require("../schemas");
const handlers = require("../handlers");
const fastify = require("fastify");

module.exports = async fastify => {
    fastify.route({
        method: "POST",
        url: "/doctor/login/check",
        schemas: schemas.doctorLoginSchemas,
        handler: handlers.doctorLoginHandler.doctorLoginHandler(fastify)
    });

    // fastify.route({
    //     method: "POST",
    //     url: "/doctor/login_verify",
    //     schemas: schemas.doctorLoginSchemas,
    //     handler: handlers.doctorLoginHandler.doctorcheckLoginHandler(fastify)
    // });
};