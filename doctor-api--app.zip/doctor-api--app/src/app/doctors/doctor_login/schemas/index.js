const doctorLoginSchemas = require('./getDoctorLogin')

module.exports = {
    doctorLoginSchemas
}