const DOCTORBASICINFO = {
    NAME: "d_doctor_basic_info",
    COLUMNS: {
        ID: "id",
        DOCTOR_NAME: "doctor_name",
        GENDER_ID: "gender_id",
        SPECIALITY_ID: "speciality_id",
        EMAIL: "email",
        PHONE_NO: "phone_no",
        DOB: "dob",
        AGE: "age",
        ABOUT: "about",
        IMAGE_PATH: "image_path",
        SIGNATURE_PATH: "signature_path",
        LAST_OTP: "last_otp",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

module.exports = {
    DOCTORBASICINFO
}