const doctorLoginHandler = require('./getLoginInfo');

module.exports = {
    doctorLoginHandler
}