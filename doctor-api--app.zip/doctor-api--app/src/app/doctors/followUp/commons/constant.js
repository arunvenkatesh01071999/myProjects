const FOLLOWUP = {
  NAME: "d_follow_up",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    PATIENT_APPOINTMENT_ID: "patient_appointment_id",
    FOLLOWUP_DATE: "followup_date",
    ADDITIONAL_NOTES: "additional_notes",
    ACTIVE: "active"
  }
}

const PATIENTFILEDETAILS = {
  NAME: "patient_record_details",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    PATIENT_FILE_PATH: "patient_file_path",
    FILE_FLAG:"file_flag",
    ACTIVE: "active"
  }
}

const PAITENTBOOKINGINFO = {
  NAME: "patient_booking",
  COLUMNS: {
    ID: "id",
    DOTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    APPOINMENT_DATE: "appointment_date",
    APPOINMENT_DAY: "appointment_day",
    APPOINMENT_FROM_TIME: "appointment_from_time",
    APPOINMENT_TO_TIME: "appointment_to_time",
    APPOINMENT_STATUS: "appointment_status",
    REASON: "reason",
    HOSPITALCONSUl_OR_VIDEOCONSUL: "hospitalcounsul_or_videoconsul",
    APPOINMENT_DURATION: "appointment_duartion",
    CLINICAL_ID: "clinical_id",
    HOSPITAL_ID: "hospital_id",
    CONFIRMATION_STATUS: "confirmation_status",
    IS_FOLLOWUP: "is_followup",
    REASON: "reason",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    RAZOR_PAYMENT_ID: "razor_payment_id",
    DOCTOR_URL: "doctor_url",
    PATIENT_URL: "patient_url",
    BOOKING_AMT:"booking_amt",
    D_PLATFORM_CHARGE:"d_platform_charge",
  }
};

const CHEIFCOMPLAINTS = {
  NAME: "e_cheif_complaints",
  COLUMNS: {
      ID: "id",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      ISALLO_OR_AUYR: "isallo_or_auyr",
      APPOINT_ID: "appoint_id",
      CHEIF_COMPLIENTS: "cheif_complients",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const PASTMEDICALHISTORY = {
  NAME: "e_past_medical_history",
  COLUMNS: {
      ID: "id",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      HEALTH_RECORD_DETAILS: "health_record_details",
      PAST_ILLNESS: "past_illness",
      PAST_MEDICINE: "past_medicine",
      PAST_SURGERIES: "past_surgeries",
      HISTORY_OF_ALLERGY: "history_of_allergy",
      PREVIOUS_VACINATION: "previous_vacination",
      END_CONSULTATION:"end_consultation",
      PREGNANCY: "pregnancy",
      IS_TRIMESTER: "is_trimester",
      IS_LACTATION: "is_lactation",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by",
      ACTIVE: "active"
  }
};

const CLINICALEXAM = {
  NAME: "e_clinical_examination",
  COLUMNS: {
      ID: "id",
      TEMPERATURE: "temperature",
      PULSE: "pulse",
      RESPIRATORY_RATE: "respiratory_rate",
      SP: "sp",
      HEART_RATE: "heart_rate",
      BLOOD_SYSTOLIC: "blood_systolic",
      BLOOD_DIASTOLIC: "blood_diastolic",
      HEIGHT: "height",
      WEIGHT: "weight",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CLINICAL_EXAMINATION: "clinical_examination",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const PRESCRIPTION = {
  NAME: "e_e_prescription",
  COLUMNS: {
      ID: "id",
      MEDICINE_NAME: "medicine_name",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const PRESCRIPTIONMEDICINE = {
  NAME: "e_e_prescription_medicine",
  COLUMNS: {
    ID: "id",
    MEDICINE_ID: "medicine_id",
    MEDICINE_NAME: "medicine_name",
    FINAL_DIAGNOSIS_ID: "final_diagnosis_id",
    QUANTITY: "quantity",
    FREQUENCY: "frequency",
    FREQUENCYNOTES:"frequencynotes",
    END_CONSULTATION:"end_consultation",
    TIMING: "timing",
    TIMINGNOTES:"timingnotes",
    DURATION: "duration",
    INSTRUCTION: "instruction",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const EXAMINATORY = {
  NAME: "e_examinatory_notes",
  COLUMNS: {
      ID: "id",
      EXAMINATORY_NOTES: "examinatory_notes",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const FINALDIAGNOSIS = {
  NAME: "e_final_diagnosis",
  COLUMNS: {
      ID: "id",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      LIST_NAME: "list_name",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const LABINVESTIGATION = {
  NAME: "e_lab_investigation_report",
  COLUMNS: {
      ID: "id",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      ACTIVE: "active",
      LAB_TEST_CATEGORY_NAME: "lab_test_category_name",
      LAB_LINK: "lab_link",
      SCAN_TEST_NAME: "scan_test_name",
      SCAN_CENTER_LINK: "scan_center_link",
      END_CONSULTATION:"end_consultation",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const OTHERTREATMENT = {
  NAME: "e_other_treatment",
  COLUMNS: {
      ID: "id",
      OTHER_TREATMENT: "other_treatment",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const PROVISIONAL = {
  NAME: "e_provisional_diagnosis",
  COLUMNS: {
      ID: "id",
      LIST_NAME: "list_name",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const SURGICAL = {
  NAME: "e_surgical_treatment",
  COLUMNS: {
      ID: "id",
      LIST_NAME: "list_name",
      SURGICAL_HOSPITAL_LINK: "surgical_hospital_link",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      END_CONSULTATION:"end_consultation",
      ACTIVE: "active",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by"
  }
};

const EHRUNIQUE = {
  NAME: "e_ehrunique",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    END_CONSULTATION:"end_consultation",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  FOLLOWUP,
  PAITENTBOOKINGINFO,
  PATIENTFILEDETAILS,
  CHEIFCOMPLAINTS,
  PASTMEDICALHISTORY,
  CLINICALEXAM,
  PRESCRIPTION,
  PRESCRIPTIONMEDICINE,
  EXAMINATORY,
  FINALDIAGNOSIS,
  LABINVESTIGATION,
  OTHERTREATMENT,
  PROVISIONAL,
  SURGICAL,
  EHRUNIQUE
};