const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postDisableDoctorReviewSchema = {
  tags: ["DOCTOR REVIEWS"],
  summary: "This API is used to post reivews",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["doctor_id", "patient_id", "active"],
    additionalProperties: false,
    properties: {
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postDisableDoctorReviewSchema;
