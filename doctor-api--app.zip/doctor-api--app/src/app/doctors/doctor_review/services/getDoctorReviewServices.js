const doctorReviewRepo = require("../repository/doctorReview");

function calculateOverallRating(reviews) {
  let totalRating = 0;
  for (const review of reviews) {
    totalRating += review.rating;
  }
  const overallRating = totalRating / reviews.length;
  return overallRating.toFixed(1); // Round to one decimal place
}
function getDoctorReviewServices(fastify) {
  const { getReview, getPatientInfo, updateDoctorRate } =
    doctorReviewRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    console.log("params" + params);

    const response = await getReview.call(knex, {
      logTrace,
      params
    });
    let overallRating = calculateOverallRating(response); // Assuming 'response' contains the reviews

    const updateDoctor = await updateDoctorRate.call(knex, {
      overallRating,
      params,
      logTrace
    });
    const reviewsWithPatientInfo = await Promise.all(
      response.map(async review => {
        let pid = review.patient_id;
        const patientInfo = await getPatientInfo({ pid, logTrace });
        return {
          ...review,
          patient_info: patientInfo
        };
      })
    );

    return {
      overall_rating: overallRating,
      out_of: response.length,
      reviews: reviewsWithPatientInfo
    };
  };
}
module.exports = getDoctorReviewServices;
