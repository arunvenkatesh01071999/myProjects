const postDoctorReviewHandler = require("./postDoctorReviewHandler");
const getDoctorReviewHandler = require("./getDoctorReviewHandler");
const postDisableDoctorReviewHandler = require("./postDisableDoctorReviewHandler");
const getAdminDoctorReviewHandler = require("./getAdminDoctorReviewHandler");

module.exports = {
  postDoctorReviewHandler,
  getDoctorReviewHandler,
  postDisableDoctorReviewHandler,
  getAdminDoctorReviewHandler
};
