const getAdminDoctorReviewServices = require("../services/getAdminDoctorReviewServices");

function getAdminDoctorReviewHandler(fastify) {
  const getAdminReview = getAdminDoctorReviewServices(fastify);
  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getAdminReview({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getAdminDoctorReviewHandler;
