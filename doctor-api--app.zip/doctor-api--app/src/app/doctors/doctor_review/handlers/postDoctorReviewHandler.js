const doctorReviewServices = require("../services/doctorReviewServices");

function postDoctorReviewHandler(fastify) {
  const postReview = doctorReviewServices(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await postReview({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postDoctorReviewHandler;
