const doctorDisableReviewServices = require("../services/doctorDisableReviewServices");

function postDisableDoctorReviewHandler(fastify) {
  const postDisableReview = doctorDisableReviewServices(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await postDisableReview({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postDisableDoctorReviewHandler;
