const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getDoctorBasicInfoSchema = {
  tags: ["DOCOTOR BASIC INFO"],
  summary: "This API is to get doctor basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        doctor_name: { type: "string" },
        gender_id: { type: "integer" },
        gender_name: { type: "string" },
        speciality_id: { type: "integer" },
        speciality_name: { type: "string" },
        email: { type: "string" },
        phone_no: { type: "string" },
        dob: { type: "string" },
        age: { type: "string" },
        about: { type: "string" },
        image_path: { type: "string" },
        signature_path: { type: "string" },
        active: { type: "boolean" },
        created_at: { type: "string" },
        updated_at: { type: "string" },
        created_by: { type: "integer" },
        updated_by: { type: "integer" },
        education_info: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              qualification_name_id: { type: "integer" },
              qualification: { type: "string" },
              doctor_name_id: { type: "integer" },
              certificate_path: { type: "string" },
              active: { type: "boolean" },
              created_at: { type: "string" },
              updated_at: { type: "string" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" }
            }
          }
        },
        address_info: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              doctor_name_id: { type: "integer" },
              address1: { type: "string" },
              address2: { type: "string" },
              city_id: { type: "integer" },
              city_name: { type: "string" },
              state_id: { type: "integer" },
              state_name: { type: "string" },
              country_id: { type: "integer" },
              phonecode: { type: "string" },
              shortname: { type: "string" },
              country_code: { type: "string" },
              country_name: { type: "string" },
              location: { type: "string" },
              longitude: { type: "string" },
              latitude: { type: "string" },
              active: { type: "boolean" },
              created_at: { type: "string" },
              updated_at: { type: "string" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" }
            }
          }
        },
        languages_info: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              language_name: { type: "string" },
              native_name: { type: "string" },
              active: { type: "boolean" },
              created_at: { type: "string" },
              updated_at: { type: "string" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" }
            }
          }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getDoctorBasicInfoSchema;