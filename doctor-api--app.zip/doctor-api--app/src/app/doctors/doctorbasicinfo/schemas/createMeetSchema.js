const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const createMeetSchema = {
  tags: ["Create Meet"],
  summary: "This API is used to login ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "meet_name",
      "meet_id",
      "hostuser",
      "meet_date",
      "participant_id"
    ],
    additionalProperties: false,
    properties: {
      meet_name: { type: "string" },
      meet_id: { type: "string" },
      hostuser: { type: "string" },
      meet_date: { type: "string", format: "date" },
      participant_id: { type: "string" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        token: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = createMeetSchema;
