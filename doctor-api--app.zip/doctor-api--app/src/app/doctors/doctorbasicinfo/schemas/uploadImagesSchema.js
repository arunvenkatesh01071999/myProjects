const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const uploadImagesSchema = {
  tags: ["LOGIN UPLOAD IMAGES"],
  summary: "This API is used to upload images ",
  headers: { $ref: "request-headers#" },
  consumes: ['multipart/form-data'],
  body: {
    type: "object",
    required: ["file"],
    additionalProperties: false,
    properties: {
      file: {}
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        message: { type: "string" },
        image_url: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = uploadImagesSchema;