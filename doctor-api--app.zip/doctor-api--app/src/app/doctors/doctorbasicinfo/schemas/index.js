const getDoctorBasicInfoSchema = require("./getDoctorBasicInfo");
const doctorLoginSchema = require("./doctorLoginSchema");
const uploadImagesSchema = require("./uploadImagesSchema");
const createMeetSchema = require("./createMeetSchema");

module.exports = {
  getDoctorBasicInfoSchema,
  doctorLoginSchema,
  uploadImagesSchema,
  createMeetSchema
};
