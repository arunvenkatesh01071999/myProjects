const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const doctorLoginSchema = {
  tags: ["LOGIN DOCTORS"],
  summary: "This API is used to login ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["mobile"],
    additionalProperties: false,
    properties: {
      mobile: { type: "string" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        token: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = doctorLoginSchema;