const getDoctorBasicInfo = require("./getDoctorBasicInfo");
const doctorLoginHandler = require("./doctorLoginHandler");
const uploadImagesHandler = require("./uploadImagesHandler");
const createMeetHandler = require("./createMeetHandler");

module.exports = {
  getDoctorBasicInfo,
  doctorLoginHandler,
  uploadImagesHandler,
  createMeetHandler
};
