const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/doctor/login",
    schema: schemas.doctorLoginSchema,
    handler: handlers.doctorLoginHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/doctorsbasicinfo",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.getDoctorBasicInfoSchema,
    handler: handlers.getDoctorBasicInfo(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/uploadImages",
    // preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.uploadImagesSchema,
    handler: handlers.uploadImagesHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/createmeet",
    // preHandler: fastify.authenticate, // Apply JWT authentication decorator
    // schema: schemas.createMeetSchema,
    handler: handlers.createMeetHandler(fastify)
  });
};
