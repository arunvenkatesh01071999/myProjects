const CHEIFCOMPLAINTS = {
    NAME: "e_cheif_complaints",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ISALLO_OR_AUYR: "isallo_or_auyr",
        APPOINT_ID: "appoint_id",
        CHEIF_COMPLIENTS: "cheif_complients",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const PASTMEDICALHISTORY = {
    NAME: "e_past_medical_history",
    COLUMNS: {
      ID: "id",
      DOCTOR_ID: "doctor_id",
      PATIENT_ID: "patient_id",
      HEALTH_RECORD_DETAILS: "health_record_details",
      PAST_ILLNESS: "past_illness",
      PAST_MEDICINE: "past_medicine",
      PAST_SURGERIES: "past_surgeries",
      HISTORY_OF_ALLERGY: "history_of_allergy",
      PREVIOUS_VACINATION: "previous_vacination",
      PREGNANCY: "pregnancy",
      IS_TRIMESTER: "is_trimester",
      IS_LACTATION: "is_lactation",
      CREATED_AT: "created_at",
      UPDATED_AT: "updated_at",
      CREATED_BY: "created_by",
      UPDATED_BY: "updated_by",
      ACTIVE:"active"
    }
  };
  

module.exports = {
    CHEIFCOMPLAINTS,
    PASTMEDICALHISTORY
}