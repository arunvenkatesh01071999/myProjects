const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const ejs = require('ejs');
const path = require('path');
const pdf = require('html-pdf');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const Stream = require('stream');
const { Storage } = require('@google-cloud/storage');
const { CustomError } = require("../../../errorHandler");
const fastify = require('fastify')();
const { CHEIFCOMPLAINTS } = require("../commons/constant");
const { template } = require("handlebars");
const { VarBinary } = require("mssql");


function getPdfInfoRepo(fastify) {
    async function getCheifComplaintsInfo({ logTrace, body,params,reply }) {
        const knex = this;
        const query = knex.raw(`select  * from e_cheif_complaints where doctor_id = ${params.doctor_id} 
        and patient_id = ${params.patient_id} order By id DESC`);
        const data = await query;
        if (!data.length) {
          throw CustomError.create({
            httpCode: StatusCodes.NOT_FOUND,
            message: "Cheif info not found",
            property: "",
            code: "NOT_FOUND"
          });
        }

        var error_detailes=[];
        var path_location_pdf=[];


        
    const storage = new Storage();
    const bucketName = process.env.GCP_BUCKET_NAME;
    const fileName = `output_${Date.now()}.pdf`;
    const media_path = 'images/' + fileName; 
    path_location_pdf.push(media_path)

    const bucket = storage.bucket(bucketName);
    const file = bucket.file(media_path);

    const writeStream = file.createWriteStream({
      metadata: {
        contentType: 'application/pdf', // Set the appropriate content type
      },
    });

ejs.renderFile('views/template.ejs', data, function (err, html) {
  if (err) {
    throw err;
  }

  var options = {
    format: "Letter",
    timeout: 10000,
  }
  

  pdf.create(html, options).toStream(async(err, stream) => {
    if (err) {
      console.error(err);
      return;
    }


    writeStream.on('error', async(err) => {
        error_detailes.push(err);
      console.error('Error uploading PDF:', err);
      return {
        'message': 'Upload Failed',
    };
    });

    writeStream.on('finish', async() => {
      console.log('PDF uploaded successfully');
    });

    stream.pipe(writeStream);
 

  });

});
if(error_detailes.length===0){
  const data=path_location_pdf[0];
  const cloudStorageBaseUrl = process.env.GCS_URL+'/'+process.env.GCP_BUCKET_NAME;
  const fullUrl = `${cloudStorageBaseUrl}/${data}`;
  return {
      'message': 'File uploaded successfully',
      'image_url':fullUrl
  };

}
else{
  return {
      'message': 'Upload Failed',
  };
}


    }
    return {
        getCheifComplaintsInfo
    }
}

module.exports = {
    getPdfInfoRepo
}