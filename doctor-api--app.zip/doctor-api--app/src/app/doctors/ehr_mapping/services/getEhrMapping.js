const ehrMappingInfo = require("../repository/getEhrMapping");
// const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getEhrMappingService(fastify) {
    const { getAllEhr } = ehrMappingInfo.allEhrRepo(fastify);
    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const doctor_id=params.id;
        const promise1 = getAllEhr.call(knex, {
            logTrace,doctor_id
        });
        const [getAllEhrService] = await Promise.all([promise1]);
        return getAllEhrService;
    };
}

function getEhrMappingPostService(fastify) {
    const { getAddEhr } = ehrMappingInfo.ehrPostRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise2 = getAddEhr.call(knex, {
            logTrace,
            body
        });

        const [getPostEhrService] = await Promise.all([promise2]);

        return getPostEhrService;
    };
}

function getEhrMappingPutService(fastify) {
    const { getPutEhr } = ehrMappingInfo.ehrPutRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise3 = getPutEhr.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getPutEhrService] = await Promise.all([promise3]);

        return getPutEhrService;
    };
}

function getEhrMappingDeleteService(fastify) {
    const { getEhrDelete } =
        ehrMappingInfo.ehrDeleteRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise4 = getEhrDelete.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getDeleteEhrService] = await Promise.all([promise4]);

        return getDeleteEhrService;
    };
}

module.exports = {
    getEhrMappingService,
    getEhrMappingPostService,
    getEhrMappingPutService,
    getEhrMappingDeleteService
};
