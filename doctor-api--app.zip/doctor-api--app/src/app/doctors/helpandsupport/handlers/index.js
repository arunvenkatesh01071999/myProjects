const gethelpBasicInfo = require("./getHelpBasicInfo");

module.exports = {
  gethelpBasicInfo
};
