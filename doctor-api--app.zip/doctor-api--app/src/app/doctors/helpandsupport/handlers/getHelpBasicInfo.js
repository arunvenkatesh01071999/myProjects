const getHelpInfos = require("../services/getHelpInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
const pump = util.promisify(pipeline);


function getHelpInfoHandler(fastify) {
  const getHelpInfo =
  getHelpInfos.getallHelpService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getHelpInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getCompanyInfoHandler(fastify) {
  const getCompanyInfo =
  getHelpInfos.getallCompanyService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getCompanyInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getHelpInfopostHandler(fastify) {

  
  const getHelpInfo =
  getHelpInfos.getpostHelpService(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await getHelpInfo({
      body,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getCompanyInfopostHandler(fastify) {
  const getCompanyInfo =
  getHelpInfos.getallCompanypostService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await getCompanyInfo({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
}


function getHelpInfoputHandler(fastify) {

  
  const getHelpInfo =
  getHelpInfos.getputHelpService(fastify);

  return async (request, reply) => {
    const { body,params, logTrace } = request;
    
    const response = await getHelpInfo({
      body,
      logTrace,
      params
      
    });
    return reply.code(200).send(response);
  };
}

function getCompanyInfoputHandler(fastify) {
  const getCompanyInfo =
  getHelpInfos.getallCompanyputService(fastify);
  return async (request, reply) => {
    const { body,params, logTrace } = request;
    
    const response = await getCompanyInfo({
      body,
      logTrace,
      params
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  getHelpInfoHandler,
  getCompanyInfoHandler,
  getHelpInfopostHandler,
  getCompanyInfopostHandler,
  getHelpInfoputHandler,
  getCompanyInfoputHandler
};
