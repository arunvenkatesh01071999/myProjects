const getHandWrittenRepository = require("../repository/getHandWrittenRepository");

function createHandWrittenServiceBasic(fastify) {
  const { HandWrittenAdd } = getHandWrittenRepository.postHandWrittenRepositoryBasic(fastify);

  return async ({ body,userDetails, params,logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = HandWrittenAdd.call(knex, {
      logTrace,
      body,
      params,

      userDetails
    });

    const [HandWrittenAddData] = await Promise.all([promise1]);

    return HandWrittenAddData;
  };
}

function updateHandWrittenServiceBasic(fastify) {
  const { HandWrittenUpdate } = getHandWrittenRepository.updateHandWrittenRepository(fastify);

  return async ({ body,params, logTrace, userDetails }) => {

    const knex = fastify.knexMaster;
    const promise1 = HandWrittenUpdate.call(knex, {
       logTrace,
      body,
      params,
      userDetails
    });

    const [updatedHandWrittenData] = await Promise.all([promise1]);

    return updatedHandWrittenData;
  };
}

function getHandWrittenInfoService(fastify) {
  
  const { HandWrittenGetAlls } = getHandWrittenRepository.getHandWrittenRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = HandWrittenGetAlls.call(knex, {
      logTrace
    });
    const [getHandWrittenAlldata] = await Promise.all([promise1]);
    return getHandWrittenAlldata;
  }
}

function getHandWrittenInfoServiceId(fastify) {
  
  const { HandWrittenGetOne } = getHandWrittenRepository.getHandWrittenRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = HandWrittenGetOne.call(knex, {
      logTrace,
      params
    });
    const [getHandWrittenOnedata] = await Promise.all([promise1]);
    return getHandWrittenOnedata;
  }
}

function deleteHandWrittenServiceId(fastify) {
 
  const { HandWrittenDelete } = getHandWrittenRepository.deleteHandWrittenRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = HandWrittenDelete.call(knex, {
      logTrace,
      params
    });

    const [deleteHandWrittendata] = await Promise.all([promise1]);

    return deleteHandWrittendata;
  };
}


module.exports = {

 createHandWrittenServiceBasic,
 updateHandWrittenServiceBasic,
 getHandWrittenInfoService,
 getHandWrittenInfoServiceId,
 deleteHandWrittenServiceId
};
