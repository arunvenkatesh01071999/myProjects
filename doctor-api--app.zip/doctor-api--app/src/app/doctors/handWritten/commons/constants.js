const HANDWRITTEN = {
  NAME: "e_hand_written",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    HAND_WRITTEN_UPLOAD: "hand_written_upload",
    ADD_FOLLOW_UP: "add_follow_up",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  HANDWRITTEN
};
