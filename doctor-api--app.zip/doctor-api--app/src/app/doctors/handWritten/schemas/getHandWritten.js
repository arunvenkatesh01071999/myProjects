const { errorSchemas } = require('../../../commons/schemas/errorSchemas');

const createHandWrittenSchema = {
  tags: ["POST HandWritten"],
  summary: "This API is to Post HandWritten ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [

      "doctor_id",
      "patient_id",
      "hand_written_upload",
      "add_follow_up",
      "active"

    ],
    // additionalProperties: false,
    // properties: {

    //   doctor_id: { type: "integer" },
    //   patient_id: { type: "integer" },
    //   active: { type: "integer" },
    //   hand_written_upload: { type: "string" },
    //   add_follow_up: { type: "integer" },
    // }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateHandWrittenSchema = {
  tags: ["PUT HandWritten"],
  summary: "This API is to Update HandWritten ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "doctor_id",
      "patient_id",
      "hand_written_upload",
      "add_follow_up",
      "active"
    ],
    // additionalProperties: false,
    // properties: {
    //   doctor_id: { type: "integer" },
    //   patient_id: { type: "integer" },
    //   active: { type: "integer" },
    //   hand_written_upload: { type: "string" },
    //   add_follow_up: { type: "integer" },
    // }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getHandWrittenSchema = {

  tags: ["GET HandWritten"],
  summary: "This API is to get HandWritten ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          active: { type: "integer" },
          hand_written_upload: { type: "string" },
          add_follow_up: { type: "integer" },
        }
      }
    },
    ...errorSchemas
  }
};

const deleteHandWrittenSchema = {
  tags: ["DELETE HandWritten"],
  summary: "This API is to delete HandWritten ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createHandWrittenSchema,
  updateHandWrittenSchema,
  getHandWrittenSchema,
  deleteHandWrittenSchema
};
