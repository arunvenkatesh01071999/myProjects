const getHandWrittenSchema = require("./getHandWritten");

module.exports = {
  getHandWrittenSchema
};
