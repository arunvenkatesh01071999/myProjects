// const { StatusCodes } = require("http-status-codes");
// const { logQuery } = require("../../../commons/helpers");

// const { CustomError } = require("../../../errorHandler");

// function getallBasicInfoRepo(fastify) {
//   async function getalldocInfo({ logTrace, body,userlong,userlat }) {
//     const knex = this;
 

//     const startLat = userlat;
//     const startLon = userlong
//     const query = knex.select(`*`).from(`d_address_info`).where(`active`, 1);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get avilable Doctor details",
//       logTrace
//     });

//     const response = await query;
//     count = response.length;
//     const locationArr = response.map(obj => obj.location);
//     const latitudesArr = response.map(obj => obj.latitude);
//     const longitudeArr = response.map(obj => obj.longitude);
//     const doctor_name_id_arr = response.map(obj => obj.doctor_name_id);

//     function calculateDistance(startLat, startLon, destLatArr, destLonArr) {
//       const R = 6371; // Radius of the earth in kilometers
//       const distances = [];
//       for (let i = 0; i < destLatArr.length; i++) {
//         const dLat = deg2rad(destLatArr[i] - startLat);
//         const dLon = deg2rad(destLonArr[i] - startLon);

//         const a =
//           Math.sin(dLat / 2) * Math.sin(dLat / 2) +
//           Math.cos(deg2rad(startLat)) *
//             Math.cos(deg2rad(destLatArr[i])) *
//             Math.sin(dLon / 2) *
//             Math.sin(dLon / 2);

//         const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//         const distance = R * c; // Distance in kilometers
//         const id=doctor_name_id_arr[i]
//         distances.push({'distance':distance,"doctor_id":id});
//       }

//       return distances;
//     }

//     function deg2rad(deg) {
//       return deg * (Math.PI / 180);
//     }

//     const distances = calculateDistance(
//       startLat,
//       startLon,
//       latitudesArr,
//       longitudeArr
//     );
// console.log('distances',distances);

//     const result_data = distances.map((item, index) => {
//       return {
//         name: locationArr[index],
//         dis: `${item.distance}Km`,
//         doctor_id:item.doctor_id
//       };
//     });

//     result = result_data.sort((a, b) => parseFloat(a.dis) - parseFloat(b.dis));
//     result.push({ count });
//     if (!result.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "avilable Doctor info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return result;
//   }

//   return {
//     getalldocInfo
//   };
// }

// module.exports = {
//   getallBasicInfoRepo
// };

const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { CustomError } = require("../../../errorHandler");
function getallBasicInfoRepo(fastify) {
  async function getalldocInfo({ logTrace, body,userlong,userlat }) {
    const knex = this;
    const startLat = userlat;
    const startLon = userlong
    const query = knex.select(`*`).from(`d_address_info`).where(`active`, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get avilable Doctor details",
      logTrace
    });
    const response = await query;
    count = response.length;
    const locationArr = response.map(obj => obj.location);
    const latitudesArr = response.map(obj => obj.latitude);
    const longitudeArr = response.map(obj => obj.longitude);
    const doctor_name_id_arr = response.map(obj => obj.doctor_name_id);
    function calculateDistance(startLat, startLon, destLatArr, destLonArr) {
      const R = 6371; // Radius of the earth in kilometers
      const distances = [];
      for (let i = 0; i < destLatArr.length; i++) {
        const dLat = deg2rad(destLatArr[i] - startLat);
        const dLon = deg2rad(destLonArr[i] - startLon);
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(deg2rad(startLat)) *
            Math.cos(deg2rad(destLatArr[i])) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c; // Distance in kilometers
        const id=doctor_name_id_arr[i]
        distances.push({'distance':distance,"doctor_id":id});
      }
      return distances;
    }
    function deg2rad(deg) {
      return deg * (Math.PI / 180);
    }
    const distances = calculateDistance(
      startLat,
      startLon,
      latitudesArr,
      longitudeArr
    );
// console.log('distances',distances);
    const result_data = distances.map((item, index) => {
      return {
        name: locationArr[index],
        dis: `${item.distance}Km`,
        doctor_id:item.doctor_id
      };
    });
    result = result_data.sort((a, b) => parseFloat(a.dis) - parseFloat(b.dis));
    result.push({ count });
    if (!result.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "avilable Doctor info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return result;
  }
  return {
    getalldocInfo
  };
}
function getdocslotByid(fastify) {
  async function getalldocInfobyid({ logTrace, d_id,userlong,userlat }) {
    const knex = this;
    const startLat = userlat;
    const startLon = userlong
    const query = knex.select(`*`).from(`d_address_info`).where(`active`, 1).where(`doctor_name_id`,d_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get avilable Doctor details",
      logTrace
    });
    const response = await query;
    console.log('address_info',response);
    count = response.length;
    const locationArr = response.map(obj => obj.location);
    const latitudesArr = response.map(obj => obj.latitude);
    const longitudeArr = response.map(obj => obj.longitude);
    const doctor_name_id_arr = response.map(obj => obj.doctor_name_id);
    function calculateDistance(startLat, startLon, destLatArr, destLonArr) {
      const R = 6371; // Radius of the earth in kilometers
      const distances = [];
      for (let i = 0; i < destLatArr.length; i++) {
        const dLat = deg2rad(destLatArr[i] - startLat);
        const dLon = deg2rad(destLonArr[i] - startLon);
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(deg2rad(startLat)) *
            Math.cos(deg2rad(destLatArr[i])) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c; // Distance in kilometers
        const id=doctor_name_id_arr[i]
        distances.push({'distance':distance,"doctor_id":id});
      }
      return distances;
    }
    function deg2rad(deg) {
      return deg * (Math.PI / 180);
    }
    const distances = calculateDistance(
      startLat,
      startLon,
      latitudesArr,
      longitudeArr
    );
    const result_data = distances.map((item, index) => {
      return {
        name: locationArr[index],
        dis: `${item.distance}Km`,
        doctor_id:item.doctor_id
      };
    });
    result = result_data.sort((a, b) => parseFloat(a.dis) - parseFloat(b.dis));
    // result.push({ count });
    if (!result.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "avilable Doctor info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return result;
  }
  return {
    getalldocInfobyid
  };
}
module.exports = {
  getallBasicInfoRepo,
  getdocslotByid
};
