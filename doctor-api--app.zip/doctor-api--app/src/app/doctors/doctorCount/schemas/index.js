const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getDocAvilBasicInfoSchema = {
  tags: ["GET ACTIVE DOCTOR INFO"],
  summary: "This API is to get Active Doctor basic info ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["userlat", "userlong"],
    additionalProperties: false,
    properties: {
      userlat: { type: "string" },
      userlong: { type: "string" }
    }
  },
  response: {
    200: {
      type: "array"
    },
    ...errorSchemas
  }
};

module.exports = {
  getDocAvilBasicInfoSchema
};
