const { CustomError } = require("../../app/errorHandler");
const { StatusCodes } = require("http-status-codes");
const { REGISTERINFO } = require("../doctors/doctor_register/commons/constants");
  async function addCheck(setvalue,doctor_name_id,fastify) {
        if (!setvalue) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: "ADD CHECK NOT FOUND",
                property: "",
                code: "NOT_FOUND"
            });
        }
        const knex = fastify.knexMaster;
        const exist_add_check=knex.select(REGISTERINFO.COLUMNS.ADDCHECK).from(REGISTERINFO.NAME).where(REGISTERINFO.COLUMNS.ID,`${doctor_name_id}`)
        .then(rows => {
            const exist_value=rows[0].addCheck;
            console.log('exist_value',exist_value);
            const new_value=parseInt(exist_value)+parseInt(setvalue);
            const update_value= knex(REGISTERINFO.NAME)
            .where(REGISTERINFO.COLUMNS.ID,`${doctor_name_id}`)  
            .update(REGISTERINFO.COLUMNS.ADDCHECK,new_value)
            .then(updatedRows => {
                return `updated successfully`
              })
              .catch(error => {
                console.error(error);
              });
           })
        .catch(error => {
          console.error(error);
        });

    };

module.exports = addCheck;