const { CustomError } = require("../../app/errorHandler");
const { StatusCodes } = require("http-status-codes");
  async function UploadImageService(singleimg,fastify) {
    // return  ({ body, logTrace, request, reply }) => {
        const file  = singleimg;


        var currentDate = new Date();

        var year = currentDate.getFullYear();
        var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        var day = currentDate.getDate().toString().padStart(2, '0');
        var hours = currentDate.getHours().toString().padStart(2, '0');
        var minutes = currentDate.getMinutes().toString().padStart(2, '0');
        var seconds = currentDate.getSeconds().toString().padStart(2, '0');
        
        
        var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;


        if (!file) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: "No file uploaded",
                property: "",
                code: "NOT_FOUND"
            });
        }
        const inputBuffer = await file.toBuffer();

        var updatedFileName = `${formattedDateTime}_${file.filename}`
        // console.log('File converted to buffer:', inputBuffer.length, 'bytes');
        const media_path = 'images/' + updatedFileName;
        const result = await fastify.bucketOperations.saveFileBuffer({
            file_path: media_path,
            buffer: inputBuffer
        });
        if (!result) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: console.log(result),
                property: "",
                code: "NOT_FOUND"
            });
        }
        const cloudStorageBaseUrl = process.env.GCS_URL+'/'+process.env.GCP_BUCKET_NAME;
        const fullUrl = `${cloudStorageBaseUrl}/${media_path}`;
        return {
            'message': 'File uploaded successfully',
            'image_url':fullUrl
        };
    };
// }
module.exports = UploadImageService;