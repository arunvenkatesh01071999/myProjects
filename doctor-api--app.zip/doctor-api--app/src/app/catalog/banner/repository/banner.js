const { logQuery } = require("../../../commons/helpers");
const { BANNER } = require("../commons/constants");

function bannerRepo(fastify) {
  async function getBanners({ logTrace }) {
    const knex = this;
    const query = knex(BANNER.NAME)
      .where(BANNER.COLUMNS.IS_ACTIVE, "1")
      .where(BANNER.COLUMNS.BANNER_OFFER, "0");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Banner",
      logTrace
    });
    const response = await query;
    return response;
  }

  return {
    getBanners
  };
}

module.exports = bannerRepo;
