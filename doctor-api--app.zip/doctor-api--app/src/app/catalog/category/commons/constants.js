const MAIN_CATEGORY = {
  NAME: "MainCategory",
  COLUMNS: {
    MCAT_ID: "Mcatid",
    MCAT_NAME: "MCatName",
    ACTIVE: "Active",
    IMG_PATH: "ImgPath",
    M_IM_GPATH: "mImgPath",
    STOCK_CHECK: "StockCheck",
    MENU_POS: "menuPos",
    CAT_ID: "catid"
  }
};

const SUB_CATEGORY = {
  NAME: "SubCategory",
  COLUMNS: {
    SCAT_ID: "Scatid",
    SCAT_NAME: "SCatName",
    MCAT_ID: "Mcatid",
    ACTIVE: "Active",
    SCAT_IMAGE: "scat_image"
  }
};

module.exports = {
  MAIN_CATEGORY,
  SUB_CATEGORY
};
