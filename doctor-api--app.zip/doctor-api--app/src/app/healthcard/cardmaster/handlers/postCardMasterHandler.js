const cardMasterServices = require("../services/cardMasterServices");

function postCardMasterHandler(fastify) {
  const postCardMaster = cardMasterServices.postCardMasterService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await postCardMaster({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postCardMasterHandler;
