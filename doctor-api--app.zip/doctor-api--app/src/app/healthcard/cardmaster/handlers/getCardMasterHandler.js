const cardMasterServices = require("../services/cardMasterServices");

function getCardMasterHandler(fastify) {
  const getCardMaster = cardMasterServices.getCardMasterService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getCardMaster({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getCardMasterHandler;
