const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const deleteCardMasterSchema = {
  tags: ["CARDS"],
  summary: "This API is to delete cards masters",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      card_type_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = deleteCardMasterSchema;
