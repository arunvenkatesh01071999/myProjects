const getCardMasterSchema = require("./getCardMasterSchema");
const postCardMasterSchema = require("./postCardMasterSchema");
const putCardMasterSchema = require("./putCardMasterSchema");
const deleteCardMasterSchema = require("./deleteCardMasterSchema");
const getCardMasterInfoSchema = require("./getCardMasterInfoSchema");

module.exports = {
  getCardMasterSchema,
  postCardMasterSchema,
  putCardMasterSchema,
  deleteCardMasterSchema,
  getCardMasterInfoSchema
};
