const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getCardMasterInfoSchema = {
  tags: ["CARD MASTERS"],
  summary: "This API is to get Card information ",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      card_type_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        card_type: { type: "string" },
        card_value: { type: "number" },
        validity_months: { type: "number" },
        consult_offer: { type: "number" },
        lab_offer: { type: "number" },
        scan_offer: { type: "number" },
        active: { type: "boolean" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getCardMasterInfoSchema;
