const cardMasterRepo = require("../repository/cards");

function getCardMasterService(fastify) {
  const { getCardMaster } = cardMasterRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const response = await getCardMaster.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getCardMasterInfoService(fastify) {
  const { getCardMasterInfo } = cardMasterRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const response = await getCardMasterInfo.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function postCardMasterService(fastify) {
  const { postCardMaster } = cardMasterRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const promise1 = postCardMaster.call(knex, {
      params,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putCardMasterService(fastify) {
  const { putCardMaster } = cardMasterRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const { card_type_id } = params;
    const promise1 = putCardMaster.call(knex, {
      card_type_id,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function deleteCardMasterService(fastify) {
  const { deleteCardMaster } = cardMasterRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const { card_type_id } = params;
    const promise1 = deleteCardMaster.call(knex, {
      card_type_id,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

module.exports = {
  getCardMasterService,
  postCardMasterService,
  putCardMasterService,
  deleteCardMasterService,
  getCardMasterInfoService
};
