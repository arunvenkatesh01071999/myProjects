const purchaseHealthCardSchema = require("./purchaseHealthCardSchema");
const getHealthCardSchema = require("./getHealthCardSchema");
const renewelHealthCardSchema = require("./renewelHealthCardSchema");

module.exports = {
  purchaseHealthCardSchema,
  getHealthCardSchema,
  renewelHealthCardSchema
};
