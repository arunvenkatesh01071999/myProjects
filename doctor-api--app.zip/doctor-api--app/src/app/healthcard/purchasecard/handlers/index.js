const purchaseHealthCardHandler = require("./purchaseHealthCardHandler");
const upgradeHealthCardHandler = require("./upgradeHealthCardHandler");
const getHealthCardHandler = require("./getHealthCardHandler");
const renewelHealthCardHandler = require("./renewelHealthCardHandler");

module.exports = {
  purchaseHealthCardHandler,
  upgradeHealthCardHandler,
  getHealthCardHandler,
  renewelHealthCardHandler
};
