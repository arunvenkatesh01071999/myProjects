const healthCardServices = require("../services/healthCardServices");

function purchaseHealthCardHandler(fastify) {
  const purchaseHealthCard =
    healthCardServices.purchaseHealthCardService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await purchaseHealthCard({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = purchaseHealthCardHandler;
