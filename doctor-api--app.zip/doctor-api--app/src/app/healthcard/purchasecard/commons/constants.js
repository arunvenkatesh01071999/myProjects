const CARD_MASTERS = {
  NAME: "card_masters",
  COLUMNS: {
    ID: "id",
    CARD_TYPE: "card_type",
    CARD_VALUE: "card_value",
    VALIDITY_MONTHS: "validity_months",
    CONSULT_OFFER: "consult_offer",
    LAB_OFFER: "lab_offer",
    SCAN_OFFER: "scan_offer",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const PATIENT_INFO = {
  NAME: "patient_registration",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    DOB: "dob",
    MOBILE: "mobile",
    BLOOD_GROUP_ID: "blood_group_id",
    PROFILE_IMAGE: "profile_image",
    IS_VERIFIED: "is_verified",
    LAST_OTP: "last_otp",
    PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    MARTIAL_STATUS_ID: "martial_status_id",
    LOGITUTE: "logitute",
    LATITUDE: "latitude",
    ACTIVE: "active",
    AGE: "age",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    ADDRESS: "address",
    FULLADDRESS: "fulladdress",
    DEVICETOKEN: "deviceToken",
    CARD_BALANCE: "card_balance"
  }
};
const PATIENT_RECORD = {
  NAME: "patient_record_details",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    DOCTOR_ID: "doctor_id",
    FILE_PATH: "patient_file_path",
    FILE_FLAG: "file_flag",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HEALTH_CARDS = {
  NAME: "health_cards",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    VALID_FROM: "valid_from",
    VALID_TO: "valid_to",
    CARD_TYPE: "card_type",
    CARD_NUMBER: "card_number",
    CARD_PIN: "card_pin",
    CARD_VALUE: "card_value",
    VALIDITY_MONTHS: "validity_months",
    CONSULT_OFFER: "consult_offer",
    LAB_OFFER: "lab_offer",
    SCAN_OFFER: "scan_offer",
    RAZOR_PAYMENT_ID: "razor_payment_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};

module.exports = {
  CARD_MASTERS,
  PATIENT_INFO,
  PATIENT_RECORD,
  HEALTH_CARDS
};
