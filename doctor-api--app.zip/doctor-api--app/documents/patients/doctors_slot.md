## DOCTORS SLOT

## Flow:

1. Fetch availabe slot for current and future date.
2. check the slots already boooked or not

## Feild:

Patient_docotors_slot

1. patient_id
2. booking_date
3. from_time
4. to_time
5. doctor_id
6. consult_status
