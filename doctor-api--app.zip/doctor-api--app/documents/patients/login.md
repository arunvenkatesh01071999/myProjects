## Patiens

## Table fields:

1. name
2. email
3. mobile
4. gender
5. dob
6. martial_status
7. blood_group
8. profile_image
9. active
10. is_verified
11. created_at
12. update_at
13. verified_at
14. last_otp
15. profile_completion_percentage
16. logitute
17. latitdue

## Login FLow:

1. Enter mobile number
2. send otp to verify mobile no.
3. once otp is verfied .
4. generate JWT token.
5. capture longitue and latitdue automatically

## Login module API:

1. login
2. otp verification

## Patient Register module API:

1. Basic SignUp
2. Patient registartion API
   . profile image optional
3. profile image upload API

## Masters

1.  Blood Group
2.  Material Status
