## Labs Test Logic

1. Test Name (Single)

   1. SGOT
   2. SGPT
   3. Bilirubin

2. Alternative Test Name (Multiple)

   1.
   2.

3. Category (Multiple)
   1.Liver
   2.Lung
   3.Kidney
   4.Bone

4. Long Description
5. Short Description
6. Recommendations
7. Sample Collected
8. Pretest Preparation

## Symtomps

1. Yellowish Eye
2. Itching
3. Jaundice
4. Yellow Urine

## Illness Types (Diseases)

1. Liver Problem

## Packages

Liver function test (Packages)

1.  SGOT
2.  SGPT
3.  Bilirubin
