## Login - Mobile

Table 
doctor_basic_info

## Login module API:

1. login
2. otp verification
3. allow to dashboard

## Registration module API:

1. name
2. mobile
3. specalization
4. notification check
5. terms

otp verification to be done on register.

## Third party login
 - google
 - facebook
 - instagram

 If otp is not sent , to be resent again

 OTP to auto verifiication
 