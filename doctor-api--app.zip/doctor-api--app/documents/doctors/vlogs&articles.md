## VLOGS & ARTICALS

Table - vlogs_articles
1. id
2. heading
3. link
4. is_vlog_or_artcle
5. created_at
6. updated_at
7. created_by
8. updated_by